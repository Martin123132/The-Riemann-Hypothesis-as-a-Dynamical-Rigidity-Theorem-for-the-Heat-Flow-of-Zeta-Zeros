"""Enclose only the reference phase decision on complete inherited cells.
No zeta, Gamma, auxiliary-function or coefficient-value evaluator is called.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import argparse,importlib.util,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
spec=importlib.util.spec_from_file_location('ar',Path(__file__).with_name('RH_Phase_Arithmetic_2026-09-16_v1.py'));ar=importlib.util.module_from_spec(spec)
import sys;sys.modules['ar']=ar;spec.loader.exec_module(ar)
FULL='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
def fract(t):
    sign,man,e,_=t
    return F((-1 if sign else 1)*man)*(F(2)**e)
def export(v):
    return ar.I(fract(v._mpi_[0]),fract(v._mpi_[1])).quantize().dump()
def ivrat(x):
    x=F(x);return mp.iv.mpf(x.numerator)/x.denominator

def build(path,digits):
    if digits<40:raise ValueError('precision below declared minimum')
    if ar.sha(path)!=FULL:raise ValueError('source hash')
    data=ar.read(path);mp.iv.dps=digits;iv=mp.iv
    br=iv.exp(iv.mpf(1)/4)*iv.cos(iv.pi/16);bi=iv.exp(iv.mpf(1)/4)*iv.sin(iv.pi/16)
    yr=iv.cos(iv.pi/8);yi=iv.sin(iv.pi/8);zr,zi=br-yr,bi-yi
    wins=[]
    for w in data['windows']:
        nu=w['nu'];rows=[]
        for c in w['cells']:
            l,h=map(F,c['r']);rc=(l+h)/2;a=ivrat(64+rc);rad=(h-l)/2;u=iv.mpf([ivrat(-rad).a,ivrat(rad).b])
            th0=2*iv.pi*a*a*iv.log(a)-iv.pi*a*a-iv.pi/8
            tail=2*iv.pi/(3*ivrat(64+l))*ivrat(rad)**3
            theta=th0+4*iv.pi*a*iv.log(a)*u+2*iv.pi*(iv.log(a)+1)*(u**2)+iv.mpf([-tail.b,tail.b])
            v=(-1)**nu*(zr*iv.cos(theta)-zi*iv.sin(theta))
            z=ar.I(*export(v))
            choices=[2] if z.hi<0 else ([5] if z.lo>0 else [2,5])
            rows.append({'i':c['i'],'r':c['r'],'phase_decision':z.dump(),'choices':choices,'theta':export(theta)})
        wins.append({'nu':nu,'r':w['r'],'cells':rows})
    return {'stage':'complete-cell carrier-phase decision','digits':digits,'N':64,'degree':5,'source_sha256':FULL,'phase_decision_formula':'Re(exp(i chi)*(exp(1/4+i*pi/16)-exp(i*pi/8)))','constants':{'bA_re':export(br),'bA_im':export(bi),'bB_re':export(yr),'bB_im':export(yi),'difference_re':export(zr),'difference_im':export(zi)},'windows':wins,'whole_cells':2048,'new_full_source_evaluations':0}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--full',required=True);a.add_argument('--digits',type=int,default=50);a.add_argument('--output',required=True);v=a.parse_args();ar.write(v.output,build(v.full,v.digits))
