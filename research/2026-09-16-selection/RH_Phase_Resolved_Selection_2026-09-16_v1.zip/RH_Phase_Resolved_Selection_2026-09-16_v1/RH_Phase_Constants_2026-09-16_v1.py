"""Rational certification of the reference selector's limiting constants.
No zeta evaluator: finite positive sums and complete integral tails only.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from __future__ import annotations
import argparse,importlib.util,sys,math
from fractions import Fraction as F
from pathlib import Path
s=importlib.util.spec_from_file_location('ar',Path(__file__).with_name('RH_Phase_Arithmetic_2026-09-16_v1.py'));ar=importlib.util.module_from_spec(s);sys.modules['ar']=ar;s.loader.exec_module(ar)
I=ar.I

def atan_rational(x,n=64):
    x=F(x)
    if not 0<x<1:raise ValueError('atan range')
    total=sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(n)),F())
    nxt=(-1)**n*x**(2*n+1)/F(2*n+1)
    return I(min(total,total+nxt),max(total,total+nxt))
def pi_bound():return (16*atan_rational(F(1,5))-4*atan_rational(F(1,239))).quantize(40)
def exp_rational(x,n=48):
    x=F(x)
    if not 0<=x<=1:raise ValueError('exp range')
    a=sum((x**k/F(math.factorial(k)) for k in range(n+1)),F())
    nxt=x**(n+1)/math.factorial(n+1)
    return I(a,a+nxt/(1-x/F(n+2))).quantize(40)
def trig(v,sine=False,n=28):
    v=I(v);out=I()
    if v.lo<0 or v.hi>1:raise ValueError('trig range')
    # The first omitted alternating term bounds the remainder at each point.
    for k in range(n):
        q=2*k+int(sine);power=I(1)
        for _ in range(q):power=power*v
        out+=F((-1)**k,math.factorial(q))*power
    q=2*n+int(sine);err=v.hi**q/math.factorial(q)
    return (out+I(-err,err)).quantize(38)
def zeta_quarters(num,count=65536,digits=32):
    # s=num/4, num=5 or 6; use integer fourth roots for finite n^{-s}.
    if num not in (5,6) or count<1:raise ValueError('series exponent/count')
    S=10**digits;T=S**4;tot=0
    for n in range(1,count+1):
        tot+=math.isqrt(math.isqrt(T//(n**num)))
    partial=I(F(tot,S),F(tot+count,S))
    # Integral from count+1 is lower; integral from count is upper.
    pl=ar.root_interval(I(F(1,(count+1)**(num-4))),4,digits)
    ph=ar.root_interval(I(F(1,count**(num-4))),4,digits)
    tail=I(pl.lo,ph.hi)*F(4,num-4)
    return (partial+tail).quantize(digits)
def build(count=65536):
    pi=pi_bound();ea=exp_rational(F(1,4))
    ar_=ea*trig(pi/16);ai=ea*trig(pi/16,True)
    br=trig(pi/8);bi=trig(pi/8,True)
    zr,zi=ar_-br,ai-bi;R=ar.root_interval(zr.square()+zi.square(),2,36)
    p=I(F(1,2))-4*zr/(3*pi*R)
    gamma=-(zr.square()+4*zi.square())/(9*pi*R)
    za=zeta_quarters(5,count);zb=zeta_quarters(6,count)
    CA=ar_*(za/2+F(1,12));CB=br*(zb/2+F(1,12))
    Csel=p*CA+(1-p)*CB+gamma
    # Compute gamma again through the half-circle moments, retaining complex phases.
    ur,ui=zr/R,-zi/R # exp(-i alpha)
    u3r=ur*ur*ur-3*ur*ui*ui;u3i=3*ur*ur*ui-ui*ui*ui
    m0=I(F(3,4))-2*zr/(pi*R)
    m2r=u3r/(3*pi)-ur/pi+F(1,8);m2i=u3i/(3*pi)-ui/pi
    gamma_alt=(zr*(m2r-m0/6)-zi*m2i)/3
    if not ar.overlap(gamma,gamma_alt):raise ArithmeticError('angular gamma mismatch')
    v={'pi':pi,'bA_real':ar_,'bA_imag':ai,'bB_real':br,'bB_imag':bi,'difference_modulus':R,'probability_A':p,'selection_correction_limit':gamma,'zeta_5_4':za,'zeta_3_2':zb,'fixed_CA':CA,'fixed_CB':CB,'selected_ordinary_limit':Csel,'independent_angular_identity':gamma_alt,'switch_count_constant':I(F(8,25))}
    return {'stage':'phase-only selected arithmetic limit constants','series_cutoff':count,'positive_series_exponents':['5/4','3/2'],'finite_source_values_used':False,'values':{k:z.quantize(32).dump() for k,z in v.items()},'display':{k:z.display() for k,z in v.items()},'all_height_sign':'ordinary selected moment only; neither gate nor full minimum','qualitative_limit_not_finite_bound':True}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--count',type=int,default=65536);p.add_argument('--output',required=True);a=p.parse_args();ar.write(a.output,build(a.count))
