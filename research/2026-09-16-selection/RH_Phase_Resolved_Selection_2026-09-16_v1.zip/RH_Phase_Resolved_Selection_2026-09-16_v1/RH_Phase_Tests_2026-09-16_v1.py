"""Reproducibility, nonvacuous guards and finite algebraic controls.
These tests do not formalize the asymptotic proof.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from pathlib import Path
from fractions import Fraction as F
import ast,copy,gzip,hashlib,importlib.util,itertools,json,sys,tempfile,unittest,zipfile
B=Path(__file__).resolve().parent

def module(name,stem):
    sp=importlib.util.spec_from_file_location(name,B/(stem+'_2026-09-16_v1.py'));m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
primary=module('phaseprimary','RH_Phase_Builder');ar=primary.ar
ind=module('phaseind','RH_Phase_Independent');src=module('phasesrc','RH_Phase_Source');con=module('phasecon','RH_Phase_Constants');sym=module('phasesym','RH_Phase_Symbolic')
FULL=B/'RH_Phase_Full_Source_2026-09-16_v1.json.gz';PILOT=B/'RH_Phase_Eight_Term_Source_2026-09-16_v1.json.gz';PHASE=B/'RH_Phase_Primitives_50d_2026-09-16_v1.json.gz';P80=B/'RH_Phase_Primitives_80d_2026-09-16_v1.json.gz'
f,ph,pi=map(ar.read,(FULL,PHASE,PILOT));res=ar.read(B/'RH_Phase_Results_2026-09-16_v1.json.gz');ir=ar.read(B/'RH_Phase_Independent_Results_2026-09-16_v1.json');cr=ar.read(B/'RH_Phase_Limit_Constants_2026-09-16_v1.json')

class TestPhase(unittest.TestCase):
    def test_01_full_hash(self):self.assertEqual(ar.sha(FULL),primary.FULL)
    def test_02_pilot_hash(self):self.assertEqual(ar.sha(PILOT),primary.PILOT)
    def test_03_parent_manifest(self):
        with zipfile.ZipFile(B/'RH_Phase_Parent_Archive_2026-09-16_v1.zip') as z:
            n=next(n for n in z.namelist() if n.endswith('RH_Switch_Manifest_2026-09-16_v1.json'));m=json.loads(z.read(n));root=n.rsplit('/',1)[0]
            self.assertEqual(len(m['files']),18)
            for q,h in m['files'].items():self.assertEqual(hashlib.sha256(z.read(root+'/'+q)).hexdigest(),h)
    def test_04_precision_fields(self):
        a,b=copy.deepcopy(ph),ar.read(P80);self.assertEqual((a.pop('digits'),b.pop('digits')),(50,80));self.assertEqual(a,b)
    def test_05_fresh_phase_50(self):self.assertEqual(src.build(FULL,50),ph)
    def test_06_fresh_phase_80(self):self.assertEqual(src.build(FULL,80),ar.read(P80))
    def test_07_primary_replay(self):self.assertEqual(primary.build(FULL,PHASE,PILOT),res)
    def test_08_independent_replay(self):self.assertEqual(ind.build(FULL,PHASE),ir)
    def test_09_primary_constants(self):self.assertEqual(con.build(),cr)
    def test_10_independent_constants(self):
        r=ar.read(B/'RH_Phase_Independent_Constants_2026-09-16_v1.json')
        self.assertEqual(len(r['values']),3)
        for k,v in r['values'].items():
            a,b=ar.I(*v),ar.I(*cr['values'][k]);self.assertLessEqual(a.lo,b.lo);self.assertGreaterEqual(a.hi,b.hi)
    def test_11_symbolics(self):
        r=sym.run();self.assertEqual(r,ar.read(B/'RH_Phase_Symbolic_Results_2026-09-16_v1.json'));self.assertEqual(r['named_symbolic_checks'],12)
    def test_12_both_true_surpluses(self):
        self.assertEqual([w['nu'] for w in res['windows']],[0,1])
        for w,floor in zip(res['windows'],['1.0815','1.0512']):self.assertGreater(F(w['values']['restored'][0]),F(floor))
    def test_13_separately_paid(self):
        for w,floor in zip(res['windows'],['1.0553','1.0208']):self.assertGreater(F(w['values']['separately_paid_surplus'][0]),F(floor))
    def test_14_independent_agreement(self):
        for w,v in zip(res['windows'],ir['windows']):
            for k in v['values']:self.assertEqual(w['values'][k],v['values'][k])
    def test_15_ambiguous_cells_retained(self):
        self.assertEqual([w['classification']['ambiguous'] for w in res['windows']],[10,11])
        for w in res['windows']:
            amb=[c for c in w['cells'] if len(c['choices'])==2];self.assertTrue(amb)
            for c in amb:self.assertEqual(c['choices'],[2,5])
    def test_16_original_policy_not_relabelled(self):
        self.assertEqual([w['classification']['definite_changed_from_eight'] for w in res['windows']],[375,414]);self.assertFalse(res['same_original_eight_selector'])
    def test_17_limit_not_a_finite_lower_bound(self):
        low=F(cr['values']['selected_ordinary_limit'][0])
        for w in res['windows']:self.assertLess(F(w['values']['ordinary'][1]),low)
    def test_18_finite_sign_not_filled_from_limit(self):
        g=ar.I(*res['windows'][0]['values']['selection_covariance']);self.assertLess(g.lo,0);self.assertGreater(g.hi,0)
        self.assertLess(F(cr['values']['selection_correction_limit'][1]),0)
    def test_19_probability_and_limit(self):
        p=ar.I(*cr['values']['probability_A']);c=ar.I(*cr['values']['selected_ordinary_limit'])
        self.assertGreater(p.lo,0);self.assertLess(p.hi,1);self.assertGreater(c.lo,F('1.4461'));self.assertLess(c.hi,F('1.4462'))
    def test_20_full_regret_identity(self):
        count=0
        for v in itertools.product([-2,0,3],repeat=6):
            L=min(v[:2]);U=min(v[2:])
            for i in [2,5]:
                r=max([0]+[min(L-v[j],v[i]-v[j]) for j in [2,3,4,5] if j!=i]);self.assertEqual(r,min(L,v[i])-min(L,U))
                for x in [-2,0,3]:
                    self.assertEqual(x*v[i]+max(-x,0)*v[i]-max(x,0)*max(v[i]-L,0)-max(x,0)*r,max(x,0)*min(v));count+=1
        self.assertEqual(count,4374)
    def test_21_gate_countercontrol(self):
        states=[(-2,-10),(1,-1)]
        self.assertGreater(sum(x*y for x,y in states),0);self.assertLess(sum(max(x,0)*y for x,y in states),0)
    def test_22_reference_index_upper_block(self):
        for d in range(5,300):
            j=(11*d+31)//32;self.assertGreaterEqual(j,(d+3)//4);self.assertLess(j,d)
    def test_23_shrinking_mask_error_exponent(self):
        self.assertEqual(F(1,2)+6*F(3,10)-3,-F(7,10))
    def test_24_fejer_square_budget(self):
        for H in range(1,300):self.assertLessEqual(F(H,(H+1)**2)+F(1,H),F(2,H))
    def test_25_policy_transfer_both_signs(self):
        a=ar.I(*res['windows'][0]['values']['signed_eight_minus_phase']);b=ar.I(*res['windows'][1]['values']['signed_eight_minus_phase']);self.assertLess(a.hi,0);self.assertGreater(b.lo,0)
    def test_26_original_policy_paid_from_reference(self):
        for w,floor in zip(res['windows'],['1.0520','1.0079']):self.assertGreater(F(w['values']['old_policy_via_phase'][0]),F(floor))
    def test_27_scale_tamper(self):
        c=copy.deepcopy(f);c['scales'][3]='1';self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_28_payment_tamper(self):
        c=copy.deepcopy(f);c['source_payment']='0';self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_29_missing_coefficient(self):
        c=copy.deepcopy(f);c['windows'][0]['cells'][0]['V'].pop();self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_30_missing_cell(self):
        c=copy.deepcopy(f);c['windows'][1]['cells'].pop();self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_31_shifted_cell(self):
        c=copy.deepcopy(f);c['windows'][0]['cells'][0]['r'][0]='1/4';self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_32_bad_weight(self):
        c=copy.deepcopy(f);c['windows'][0]['cells'][0]['W']=['-1','1'];self.assertRaises(ValueError,primary.validate,c,ph,pi)
    def test_33_changed_phase_rejected(self):
        c=copy.deepcopy(ph);c['windows'][0]['cells'][0]['phase_decision']=['0','1'];self.assertRaises(ValueError,primary.validate,f,c,pi)
    def test_34_single_branch_at_tie_rejected(self):
        c=copy.deepcopy(ph);a=next(x for x in c['windows'][0]['cells'] if len(x['choices'])==2);a['choices']=[5];self.assertRaises(ValueError,primary.validate,f,c,pi)
    def test_35_output_overwrite_guard(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'test.json';ar.write(p,{'a':1});self.assertRaises(FileExistsError,ar.write,p,{'a':2})
    def test_36_zero_denominator(self):self.assertRaises(ValueError,lambda:ar.I(1)/ar.I(-1,1))
    def test_37_independent_no_primary_import(self):
        t=ast.parse((B/'RH_Phase_Independent_2026-09-16_v1.py').read_text());names=[n.module for n in ast.walk(t) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(t) if isinstance(n,ast.Import) for a in n.names]
        self.assertTrue(names);self.assertFalse(any('Phase' in (n or '') or n=='ar' for n in names))
    def test_38_all_intermediate_competitors_retained(self):
        v=[ar.I(3),ar.I(3),ar.I(2),ar.I(-4),ar.I(1),ar.I(5)]
        for i in [2,5]:self.assertEqual(primary.branch(v,ar.I(1),i)['restored'],ar.I(-4))

if __name__=='__main__':unittest.main(verbosity=2)
