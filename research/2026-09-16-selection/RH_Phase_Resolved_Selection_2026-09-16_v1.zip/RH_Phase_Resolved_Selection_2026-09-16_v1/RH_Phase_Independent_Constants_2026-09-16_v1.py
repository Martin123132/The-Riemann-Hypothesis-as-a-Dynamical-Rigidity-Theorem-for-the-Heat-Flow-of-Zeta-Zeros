"""Separate elementary interval constant calculation with a different cutoff.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import argparse,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def export(x):
    def frac(t):
        sign,m,e,_=t;return F((-1 if sign else 1)*m)*F(2)**e
    a,b=map(frac,x._mpi_);S=10**30
    return [str(F((a*S).__floor__(),S)),str(F((b*S).__ceil__(),S))]
def build(n=32768):
    iv=mp.iv;iv.dps=70
    br=iv.exp(iv.mpf(1)/4)*iv.cos(iv.pi/16);bi=iv.exp(iv.mpf(1)/4)*iv.sin(iv.pi/16)
    er,ei=iv.cos(iv.pi/8),iv.sin(iv.pi/8);x,y=br-er,bi-ei;r=iv.sqrt(x*x+y*y);c=x/r;s=y/r
    mu0=iv.mpf(3)/4-2*c/iv.pi
    mu2r=(4*c**3-3*c)/(3*iv.pi)-c/iv.pi+iv.mpf(1)/8
    mu2i=4*s**3/(3*iv.pi)
    gamma=(x*(mu2r-mu0/6)-y*mu2i)/3
    def zeta(p):
        total=iv.mpf(0)
        for k in range(1,n+1):total+=iv.mpf(k)**(-p)
        lo=(iv.mpf(n+1)**(1-p)/(p-1)).a
        hi=(iv.mpf(n)**(1-p)/(p-1)).b
        return total+iv.mpf([lo,hi])
    za,zb=zeta(iv.mpf(5)/4),zeta(iv.mpf(3)/2)
    pa=mu0/(iv.mpf(3)/2);Ca=br*(za/2+iv.mpf(1)/12);Cb=er*(zb/2+iv.mpf(1)/12)
    csel=pa*Ca+(1-pa)*Cb+gamma
    return {'source_oracle_calls':0,'digits':70,'positive_series_cutoff':n,'method':'direct angular moments, finite positive elementary sums and integral tails','values':{'selected_ordinary_limit':export(csel),'selection_correction_limit':export(gamma),'probability_A':export(pa)}}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();o=Path(a.output)
    if o.exists():raise FileExistsError(o)
    o.write_bytes((json.dumps(build(),sort_keys=True,indent=2)+'\n').encode())
