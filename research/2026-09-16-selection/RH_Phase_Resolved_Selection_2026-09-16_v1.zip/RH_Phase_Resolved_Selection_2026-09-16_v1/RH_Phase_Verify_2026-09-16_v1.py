"""Read-only verification of this stage's noncircular SHA-256 manifest."""
import hashlib,json
from pathlib import Path

def verify(root=None):
    root=Path(root) if root else Path(__file__).resolve().parent
    manifest=json.loads((root/'RH_Phase_Manifest_2026-09-16_v1.json').read_text())
    for name,wanted in manifest['files'].items():
        p=root/name
        if p.parent!=root or not p.is_file():raise ValueError('missing or unsafe member '+name)
        if hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:raise ValueError('hash mismatch '+name)
    return {'verified_manifest_members':len(manifest['files']),'algorithm':'sha256','all_match':True}
if __name__=='__main__':print(json.dumps(verify(),sort_keys=True,indent=2))
