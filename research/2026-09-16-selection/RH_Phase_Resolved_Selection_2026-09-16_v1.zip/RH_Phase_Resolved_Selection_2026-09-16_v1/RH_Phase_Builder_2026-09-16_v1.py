"""Full-surplus accounting for an explicit phase-only reference selector.
The eight-term selector is retained as a separate unchanged comparison.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from __future__ import annotations
import argparse,importlib.util,sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial
spec=importlib.util.spec_from_file_location('ar',Path(__file__).with_name('RH_Phase_Arithmetic_2026-09-16_v1.py'));ar=importlib.util.module_from_spec(spec);sys.modules['ar']=ar;spec.loader.exec_module(ar)
I=ar.I; sm=ar.sm;mn=ar.mn;mx=ar.mx;hull=ar.hull
FULL='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
PILOT='5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4'

PHASE_MATH_HASH='f8138895418a7679b0408564855693b75b5dc30fefbf5becbfa92e5b519eb16e'

def validate(f,ph,p):
    payload=dict(ph);payload.pop('digits',None)
    if hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()!=PHASE_MATH_HASH:raise ValueError('phase mathematics hash')
    if (f['N'],f['degree'])!=(64,5):raise ValueError('source dimension')
    scales=[sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    if list(map(F,f['scales']))!=scales:raise ValueError('scales')
    if F(f['source_payment'])!=F('0.271900134725'):raise ValueError('payment')
    if (ph['N'],ph['degree'],ph['source_sha256'],ph['whole_cells'])!=(64,5,FULL,2048):raise ValueError('phase binding')
    if (p['N'],p['d'],p['K'],p['input_sha256'])!=(64,5,8,FULL):raise ValueError('pilot binding')
    if p['upper_indices']!=[2,3,4,5] or not p['whole_cell_evaluation']:raise ValueError('pilot source')
    for obj in (f,ph,p):
        if [w['nu'] for w in obj['windows']]!=[0,1]:raise ValueError('window roster')
    for nu,(fw,hw,pw) in enumerate(zip(f['windows'],ph['windows'],p['windows'])):
        ends=[F(49+100*nu,200),F(51+100*nu,200)]
        if list(map(F,fw['r']))!=ends or list(map(F,hw['r']))!=ends:raise ValueError('bounds')
        if any(len(w['cells'])!=1024 for w in (fw,hw,pw)):raise ValueError('missing cells')
        for k,(c,h,t) in enumerate(zip(fw['cells'],hw['cells'],pw['cells'])):
            r=[ends[0]+F(k,102400),ends[0]+F(k+1,102400)]
            for z in (c,h,t):
                if z['i']!=k or list(map(F,z['r']))!=r:raise ValueError('geometry/order')
            if len(c['V'])!=6 or len(t['Vshort'])!=4:raise ValueError('coefficients missing')
            w=I(*c['W'])
            if w.lo<0 or w.hi>4:raise ValueError('weight')
            a=I(*h['phase_decision']);expected=[2] if a.hi<0 else [5] if a.lo>0 else [2,5]
            if h['choices']!=expected:raise ValueError('phase branches not enclosed')

def branch(v,x,idx):
    P=x.pos();L=mn(v[:2]);T=mn([L,v[idx]])
    # Exact self-competitor is zero; retain all other upper coefficients.
    reg=mx([I()]+[mn([L-v[j],v[idx]-v[j]]) for j in (2,3,4,5) if j!=idx]).pos()
    return {'ordinary':x*v[idx],'gated':P*v[idx], 'gate_correction':(-x).pos()*v[idx],
            'lower_loss':P*(v[idx]-L).pos(),'regret':P*reg,
            'selected_policy_net':P*T,'restored':P*(T-reg),
            'direct_reference':P*mn(v)}

def window(fw,hw,pw):
    names=list(branch([I()]*6,I(),2));acc={k:I() for k in names};Wtot=I();pa=I();masks=[];rows=[];vals=[]
    deltas=I();oldsel=I();oldgate=I();oldlow=I();oldreg=I();oldnet=I()
    counts={'phase_first':0,'phase_last':0,'ambiguous':0,'definite_changed_from_eight':0}
    for c,h,t in zip(fw['cells'],hw['cells'],pw['cells']):
        w=I(*c['W']);x=I(*c['X']);v=[I(*z) for z in c['V']];choices=h['choices'];Wtot+=w
        mask=I(1) if choices==[2] else I(0) if choices==[5] else I(0,1)
        counts['phase_first' if choices==[2] else 'phase_last' if choices==[5] else 'ambiguous']+=1
        masks.append(mask);pa+=w*mask
        old=min(range(4),key=lambda j:(I(*t['Vshort'][j]).mid(),j))+2
        if old not in choices:counts['definite_changed_from_eight']+=1
        models=[branch(v,x,i) for i in choices]
        local={n:hull(z[n] for z in models) for n in names}
        for n in names:acc[n]+=w*local[n]
        od=branch(v,x,old);oldsel+=w*od['ordinary'];oldgate+=w*od['gate_correction'];oldlow+=w*od['lower_loss'];oldreg+=w*od['regret'];oldnet+=w*od['restored']
        diff=hull(I() if i==old else x*(v[old]-v[i]) for i in choices);deltas+=w*diff
        vals.append((w,x,v));rows.append({'i':c['i'],'r':c['r'],'choices':choices,'old_eight_index':old,'indicator':mask.dump(),'branches_enclosed':len(choices), 'values':{k:z.dump() for k,z in local.items()},'eight_minus_phase_signed':diff.dump()})
    if Wtot.lo<=0:raise ValueError('zero weight mass')
    p=pa/Wtot
    Cr=sm(w*x*v[5] for w,x,v in vals)/Wtot
    CD=sm(w*x*(v[2]-v[5]) for w,x,v in vals)/Wtot
    mix=Cr+p*CD
    gam=sm((mask-p)*w*x*(v[2]-v[5]) for mask,(w,x,v) in zip(masks,vals))/Wtot
    out={k:v/Wtot for k,v in acc.items()}
    out['probability_first']=p;out['fixed_index_mixture']=mix;out['selection_covariance']=gam
    out['signed_eight_minus_phase']=deltas/Wtot
    out['eight_term_reference_surplus']=oldnet/Wtot
    out['old_policy_via_phase']=out['ordinary']+deltas/Wtot+oldgate/Wtot-oldlow/Wtot-oldreg/Wtot
    out['separately_paid_surplus']=out['ordinary']+out['gate_correction']-out['lower_loss']-out['regret']
    out['phase_covariance_collected_surplus']=mix+gam+out['gate_correction']-out['lower_loss']-out['regret']
    if not ar.overlap(out['ordinary'],mix+gam):raise ArithmeticError('covariance identity')
    if not ar.overlap(out['restored'],out['direct_reference']):raise ArithmeticError('source identity')
    if not ar.overlap(out['eight_term_reference_surplus'],out['old_policy_via_phase']):raise ArithmeticError('reference transfer')
    return {'nu':fw['nu'],'r':fw['r'],'classification':counts,'cells':rows,'values':{k:z.dump() for k,z in out.items()},'display':{k:z.display() for k,z in out.items()},'positive_restored':out['restored'].lo>0}

def build(full,phase,pilot):
    if ar.sha(full)!=FULL or ar.sha(pilot)!=PILOT:raise ValueError('source hash mismatch')
    f,ph,p=map(ar.read,(full,phase,pilot));validate(f,ph,p)
    return {'stage':'phase-only reference adaptive correlation and full-surplus calibration','date':'2026-09-16','N':64,'d':5,'same_original_eight_selector':False,'original_eight_selector_preserved':True,'full_coefficient_count':6,'new_source_function_evaluations':0,'phase_source_digits':ph['digits'],'whole_cells':2048,'source_hashes':{'full':FULL,'pilot':PILOT,'phase':ar.sha(phase)},'windows':[window(*ws) for ws in zip(f['windows'],ph['windows'],p['windows'])]}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--phase',required=True);p.add_argument('--pilot',required=True);p.add_argument('--output',required=True);a=p.parse_args();ar.write(a.output,build(a.full,a.phase,a.pilot))
