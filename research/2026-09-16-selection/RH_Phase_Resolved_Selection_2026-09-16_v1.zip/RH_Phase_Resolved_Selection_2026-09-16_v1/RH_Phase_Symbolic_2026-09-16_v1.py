"""Finite symbolic identities supporting (not formalizing) the analytic proof.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import sympy as s
import argparse,json
from pathlib import Path

def run():
    c,t,R,p=s.symbols('c t R p',real=True); checks=[]
    def ck(name,expr):
        r=s.rem(s.together(expr).as_numer_denom()[0],t*t+c*c-1,t) if expr.has(t) else s.simplify(expr)
        ok=s.simplify(r)==0
        if not ok:raise AssertionError((name,r))
        checks.append(name)
    mu0=s.Rational(3,4)-2*c/p
    mu2r=(4*c**3-3*c)/(3*p)-c/p+s.Rational(1,8)
    mu2i=4*t**3/(3*p)
    prob=s.Rational(1,2)-4*c/(3*p)
    gamma=R*(c*(mu2r-mu0/6)-t*mu2i)/3
    ck('probability normalization',mu0/s.Rational(3,2)-prob)
    ck('exact signed switching constant',gamma+R*(c*c+4*t*t)/(9*p))
    ck('equivalent cosine formula',R*(3*c*c-4)/(9*p)+R*(c*c+4*t*t)/(9*p))
    ck('mask complement zero harmonic',(s.Rational(3,2)-mu0)+mu0-s.Rational(3,2))
    ck('mask complement second harmonic',(s.Rational(1,4)-mu2r)+mu2r-s.Rational(1,4))
    u=s.symbols('u'); lam=u/2+4*u*u-2*u**3
    ck('spectral index 11/32',lam.subs(u,s.Rational(1,4))-s.Rational(11,32))
    ck('endpoint spectral index',lam.subs(u,s.Rational(1,2))-1)
    ck('mask smoothing exponent',s.Rational(1,2)+6*s.Rational(3,10)-3+s.Rational(7,10))
    ck('upper truncation exponent',6*(s.Rational(1,2)-s.Rational(7,10))+s.Rational(1,2)+s.Rational(7,10))
    ck('switch count coefficient',4*s.Rational(4,50)-s.Rational(8,25))
    q,a,n,h=s.symbols('q a n h',positive=True)
    theta=2*s.pi*a*a*s.log(a)-s.pi*a*a-s.pi/8
    ck('shared-height harmonic derivative',s.diff(h*theta-2*s.pi*a*a*s.log(q),a)-4*s.pi*a*(h*s.log(a)-s.log(q)))
    d1,d2,b1r,b2r,b1i,b2i,w0,w2r,w2i=s.symbols('d1 d2 b1r b2r b1i b2i w0 w2r w2i')
    pr=2*w0/3
    selected=(w0*d1+(s.Rational(3,2)-w0)*d2+b1r*w2r-b1i*w2i+b2r*(s.Rational(1,4)-w2r)+b2i*w2i)/3
    mixture=pr*(d1/2+b1r/12)+(1-pr)*(d2/2+b2r/12)
    correction=((b1r-b2r)*(w2r-w0/6)-(b1i-b2i)*w2i)/3
    ck('diagonal cancellation in masked covariance',selected-mixture-correction)
    return {'named_symbolic_checks':len(checks),'checks':checks,'proof_scope':'algebraic identities only; not proof-assistant verification of asymptotic estimates'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=Path(a.output)
    if out.exists():raise FileExistsError(out)
    out.write_bytes((json.dumps(run(),sort_keys=True,indent=2)+'\n').encode())
