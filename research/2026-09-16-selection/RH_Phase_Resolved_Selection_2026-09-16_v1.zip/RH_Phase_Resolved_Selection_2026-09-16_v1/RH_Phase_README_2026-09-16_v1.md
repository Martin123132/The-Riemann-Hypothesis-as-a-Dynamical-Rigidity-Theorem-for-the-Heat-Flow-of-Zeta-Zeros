# Phase-resolved adaptive selection

16 September 2026. TWO HANDS NETWORK LTD. All rights reserved.

## Main findings

The new written actual-height argument evaluates the full switching correction
for a DECLARED phase-only reference selector. On the degree-edge sequence it
has limit -0.01789414360498004329..., while the selected ordinary product tends
to a positive constant in [1.446119963280524,1.446120051051692]. The number of
reference switches grows like (8/25)N^(2/3)log N; no small-switch-count assumption
is used. The Fourier cutoff increases, and its error against the growing central
factor is explicitly paid.

The old eight-term selector is NOT replaced or claimed solved. An exact
reference-difference identity keeps it available. Neither the reference's
ordinary positive limit nor its computed switching bias proves positivity of
the gated full minimum at unbounded cutoffs.

The finite N=64 reference test keeps all six full coefficients and pays its
larger selection regret. Both original windows have restored surplus >1.0815
and >1.0512. All 2,048 whole cells remain, including both choices on 21 ambiguous
phase cells. The source, central gate, degree, scales and source-error payment
are unchanged. This is a calibration on existing windows, not new territory.

Read `RH_Phase_Resolved_Selection_Derivation_2026-09-16_v1.md` for all formulas,
proof hypotheses, limit order and remaining targets. `RH_Phase_Summary_2026-09-16_v1.json`
records machine-readable scope and results.

## Verification and reproduction

Use Python 3.10 or newer. Finite acceptance and the primary constants use the
standard library. Regenerating phase enclosures uses mpmath; symbolic controls
use SymPy. The two phase builds share mpmath.iv. The independent finite replay
shares the full source and phase enclosures, not the primary arithmetic code.

From this folder run:

```text
python RH_Phase_Verify_2026-09-16_v1.py
python RH_Phase_Tests_2026-09-16_v1.py
```

The tests include full regeneration of both phase precisions, both finite
acceptance calculations and the primary constants. They supplement, but do
not formally verify, the written asymptotic argument.

To create a fresh acceptance output (existing output files are never overwritten):

```text
python RH_Phase_Builder_2026-09-16_v1.py --full RH_Phase_Full_Source_2026-09-16_v1.json.gz --phase RH_Phase_Primitives_50d_2026-09-16_v1.json.gz --pilot RH_Phase_Eight_Term_Source_2026-09-16_v1.json.gz --output fresh_phase_result.json.gz
```

To rebuild phase values, run `RH_Phase_Source_2026-09-16_v1.py` with `--full`,
`--digits 50` (or 80), and a new `--output` path. This evaluates only the explicit
phase decision, not the full source coefficients. To rebuild limiting constants,
use `RH_Phase_Constants_2026-09-16_v1.py --output fresh_constants.json`.
The independent constant program uses a different finite series cutoff and a
different angular formula; it calls no zeta evaluator.

All JSON outputs are canonical UTF-8 with LF line endings; gzip outputs use
mtime=0. The isolated acceptance runtime contains only five files: its program,
exact-arithmetic helper, source cells, original eight-term pilot and new phase
enclosures. It reads no historical acceptance result. The independent runtime
contains only its program, source cells and phase enclosures.

The new seal lists file hashes excluding the manifest itself. The external
clean receipt records fresh extraction and command-line byte comparisons.
Hashes authenticate evidence; they do not prove its analytic inequalities.

Historical packages, desktop, repositories and bookmark are unchanged. No
historical pin audit or laptop operation was performed in this stage. Every
process launched for this delivery has completed. No RH or zero-count closure
is claimed; no publication or general reuse permission is granted.
