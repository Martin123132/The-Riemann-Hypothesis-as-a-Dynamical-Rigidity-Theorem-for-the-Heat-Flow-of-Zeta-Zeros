"""Exact rational interval utilities for this private continuation.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from pathlib import Path
import gzip,hashlib,json,math

@dataclass(frozen=True,init=False)
class I:
    lo:F; hi:F
    def __init__(self,a=0,b=None):
        if isinstance(a,I): l,h=a.lo,a.hi
        else:l,h=F(a),F(a if b is None else b)
        if l>h:raise ValueError('reversed interval')
        object.__setattr__(self,'lo',l);object.__setattr__(self,'hi',h)
    def __add__(self,v):
        v=I(v);return I(self.lo+v.lo,self.hi+v.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,v):return self+-I(v)
    def __rsub__(self,v):return I(v)+-self
    def __mul__(self,v):
        v=I(v);p=[self.lo*v.lo,self.lo*v.hi,self.hi*v.lo,self.hi*v.hi];return I(min(p),max(p))
    __rmul__=__mul__
    def __truediv__(self,v):
        v=I(v)
        if v.lo<=0<=v.hi:raise ValueError('zero denominator')
        return self*I(1/v.hi,1/v.lo)
    def square(self):
        return I(0 if self.lo<=0<=self.hi else min(self.lo**2,self.hi**2),max(self.lo**2,self.hi**2))
    def pos(self):return I(max(F(),self.lo),max(F(),self.hi))
    def abs(self):return I(0 if self.lo<=0<=self.hi else min(abs(self.lo),abs(self.hi)),max(abs(self.lo),abs(self.hi)))
    def mid(self):return (self.lo+self.hi)/2
    def dump(self):return [str(self.lo),str(self.hi)]
    def display(self):return [float(self.lo),float(self.hi)]
    def quantize(self,n=32):
        S=10**n
        return I(F((self.lo*S).__floor__(),S),F((self.hi*S).__ceil__(),S))

def hull(v):
    v=list(v)
    if not v:raise ValueError('empty hull')
    return I(min(x.lo for x in v),max(x.hi for x in v))
def mn(v):
    v=list(v)
    if not v:raise ValueError('empty min')
    return I(min(x.lo for x in v),min(x.hi for x in v))
def mx(v):
    v=list(v)
    if not v:raise ValueError('empty max')
    return I(max(x.lo for x in v),max(x.hi for x in v))
def sm(v):return sum(v,I())
def overlap(a,b):return max(a.lo,b.lo)<=min(a.hi,b.hi)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
    b=Path(p).read_bytes();return json.loads(gzip.decompress(b) if str(p).endswith('.gz') else b)
def write(p,obj):
    p=Path(p)
    if p.exists():raise FileExistsError(str(p))
    b=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
    p.write_bytes(gzip.compress(b,mtime=0) if str(p).endswith('.gz') else b)

def root_interval(v,power=2,digits=32):
    v=I(v)
    if v.lo<0:raise ValueError('negative radicand')
    S=10**digits
    def fl(x):
        a=(x.numerator*S**power)//x.denominator
        if power==2:return math.isqrt(a)
        if power==4:return math.isqrt(math.isqrt(a))
        raise ValueError('unsupported root')
    lo,hi=fl(v.lo),fl(v.hi)
    return I(F(lo,S),F(hi+1,S))
