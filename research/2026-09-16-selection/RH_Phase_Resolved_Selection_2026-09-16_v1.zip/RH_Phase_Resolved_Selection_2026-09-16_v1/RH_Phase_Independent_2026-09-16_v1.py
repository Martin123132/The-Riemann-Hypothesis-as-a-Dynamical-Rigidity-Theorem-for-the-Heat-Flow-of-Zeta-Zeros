"""Independent tuple/Fraction replay. Imports no primary/helper implementation.
Shared inputs are authenticated whole-cell source and phase enclosures.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from fractions import Fraction as F
from pathlib import Path
from math import comb,factorial
import argparse,json,gzip,hashlib
H='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
def iv(x):return (F(x),F(x))
def get(a):
    x=tuple(map(F,a))
    if len(x)!=2 or x[0]>x[1]:raise ValueError('interval')
    return x
def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
    p=[x*y for x in a for y in b];return min(p),max(p)
def div(a,b):
    if b[0]<=0<=b[1]:raise ValueError('mass')
    return mul(a,(1/b[1],1/b[0]))
def pos(a):return max(F(),a[0]),max(F(),a[1])
def neg(a):return -a[1],-a[0]
def mini(xs):return min(x[0] for x in xs),min(x[1] for x in xs)
def maxi(xs):return max(x[0] for x in xs),max(x[1] for x in xs)
def hull(xs):return min(x[0] for x in xs),max(x[1] for x in xs)
def read(p):
    b=Path(p).read_bytes();return json.loads(gzip.decompress(b) if str(p).endswith('.gz') else b)
def write(p,v):
    p=Path(p)
    if p.exists():raise FileExistsError(p)
    p.write_bytes((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def build(full,phase):
    if hashlib.sha256(Path(full).read_bytes()).hexdigest()!=H:raise ValueError('source hash')
    f,h=read(full),read(phase)
    scales=[sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    if (f['N'],f['degree'])!=(64,5) or list(map(F,f['scales']))!=scales or F(f['source_payment'])!=F('0.271900134725'):raise ValueError('source rules')
    if h['source_sha256']!=H or h['N']!=64 or h['degree']!=5:raise ValueError('phase rules')
    if [w['nu'] for w in f['windows']]!=[0,1] or [w['nu'] for w in h['windows']]!=[0,1]:raise ValueError('window roster')
    out=[]
    for nu,(fw,hw) in enumerate(zip(f['windows'],h['windows'])):
        if len(fw['cells'])!=1024 or len(hw['cells'])!=1024:raise ValueError('cells')
        sums={k:iv(0) for k in ['ordinary','gate_correction','lower_loss','regret','restored','direct_reference']};mass=iv(0);amb=0
        for k,(c,t) in enumerate(zip(fw['cells'],hw['cells'])):
            bounds=[F(49+100*nu,200)+F(k,102400),F(49+100*nu,200)+F(k+1,102400)]
            if c['i']!=k or t['i']!=k or list(map(F,c['r']))!=bounds or list(map(F,t['r']))!=bounds:raise ValueError('geometry')
            w,x=get(c['W']),get(c['X']);v=list(map(get,c['V']));q=get(t['phase_decision'])
            if len(v)!=6 or w[0]<0 or w[1]>4:raise ValueError('source fields')
            choices=[2] if q[1]<0 else [5] if q[0]>0 else [2,5]
            if t['choices']!=choices:raise ValueError('missing branch')
            amb+=len(choices)==2; P=pos(x);L=mini(v[:2]);records=[]
            for i in choices:
                # Pairwise upper regret, then bound effective regret by its min with (L-U)_+.
                upperreg=maxi([iv(0)]+[sub(v[i],v[j]) for j in [2,3,4,5] if j!=i])
                source_reg=maxi([iv(0)]+[mini([sub(L,v[j]),sub(v[i],v[j])]) for j in [2,3,4,5] if j!=i])
                if source_reg[1]>upperreg[1]:raise ArithmeticError('screening error')
                rec={'ordinary':mul(x,v[i]),'gate_correction':mul(pos(neg(x)),v[i]),'lower_loss':mul(P,pos(sub(v[i],L))),'regret':mul(P,source_reg),'restored':mul(P,sub(mini([L,v[i]]),source_reg)),'direct_reference':mul(P,mini(v))};records.append(rec)
            for key in sums:sums[key]=add(sums[key],mul(w,hull([r[key] for r in records])))
            mass=add(mass,w)
        vals={k:div(v,mass) for k,v in sums.items()}
        paid=sub(sub(add(vals['ordinary'],vals['gate_correction']),vals['lower_loss']),vals['regret']);vals['separately_paid_surplus']=paid
        out.append({'nu':nu,'ambiguous_cells':amb,'values':{k:list(map(str,v)) for k,v in vals.items()},'display':{k:list(map(float,v)) for k,v in vals.items()},'positive_restored':vals['restored'][0]>0})
    return {'stage':'independent phase-reference full-cell accounting','N':64,'cells':2048,'imports_primary':False,'source_phase_inputs_shared':True,'windows':out}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--phase',required=True);p.add_argument('--output',required=True);a=p.parse_args();write(a.output,build(a.full,a.phase))
