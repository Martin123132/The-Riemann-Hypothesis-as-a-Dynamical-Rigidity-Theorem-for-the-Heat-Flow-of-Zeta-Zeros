# Switching primitives and adaptive correlation

Private research for Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

## Main files

`RH_Switching_Primitive_Derivation_2026-09-16_v1.md` contains the complete analytic derivation, finite scope, inherited assumptions, uniform prefix bound and remaining unbounded obligation.

`RH_Switch_Results_2026-09-16_v1.json` includes all 35 selector changes, individual primitive-jump intervals, the collected signed correction and the complete gate/lower-block/regret budget. The deliberately overwide separately intervalized switch sum is retained.

`RH_Switch_Independent_Results_2026-09-16_v1.json` uses a different paired-group covariance identity and standalone exact interval implementation. It shares the existing source enclosures, not the primary program.

`RH_Switch_Summary_2026-09-16_v1.json` is a human-readable index of those results and their limits.

## Reproduce

Python 3.10 or newer; standard library only. From this directory:

```sh
python RH_Switch_Verify_2026-09-16_v1.py
```

This checks this package's SHA-256 manifest, checks the unchanged parent archive, rebuilds both numerical outputs in separate three-file runtimes, compares their bytes, and executes all 32 new tests. It performs no network request and no source-function evaluation. Temporary files are local and automatically removed.

To run the primary calculation alone:

```sh
python RH_Switch_Builder_2026-09-16_v1.py --full RH_Switch_Full_Source_2026-09-16_v1.json.gz --pilot RH_Switch_Pilot_Source_2026-09-16_v1.json.gz --output new_switch_result.json
```

The output path must not already exist. The independent program accepts the same three arguments. Neither runtime reads historical accepted result files.

## Verification scope

The input arrays are authenticated inherited WHOLE-CELL source enclosures, not fresh values or isolated samples. Their source/approximation/interpolation assumptions remain dependencies. Hash verification establishes byte integrity, not the mathematical validity of a source theorem. The asymptotic primitive estimate is a written proof under those dependencies, not established by finite tests or proof-assistant formalization.

The finite selector is unchanged and cell-constant. Its 35 switch faces are not asserted to be true equality points of the short coefficient functions. A general exact-pilot-argmin selector has a separate asymptotic switch-count/correlation obligation.

No laptop, desktop, repository, bookmark or historical research file is written by this package. Its verification performs no historical-pin audit and grants no new reuse rights.
