# Source-aware central energy and signed correlations with a growing coefficient block

**15 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Results, new dependency, and the distinction between correlation and selection

The incoming interior-spectrum theorem shortens indices j/d >= 3/5 while retaining
the full central gate and all lower coefficients. Its central-norm payment uses
||X_N||_2 = O(N^(1/6) sqrt(log N)). That bound is valid but unnecessarily large
for this particular real arithmetic source.

This continuation imports an **unconditional published mean-square theorem**:
N. Watt (2010), *A note on the mean square of |zeta(1/2+it)|*, Journal of the
London Mathematical Society 82, 279–294, DOI 10.1112/jlms/jdq024. Its bound is
E(T) << T^(131/416) (log(T+2))^phi with phi<4. We use the weaker log^4 form.
The definition of E and this estimate are also stated on page 1 of Bourgain and
Watt (2015), arXiv:1505.04161v1, which proves a stronger bound in Theorem 4.
Neither imported result assumes RH. Their proofs are NOT re-proved by this package.

New deductions are:

1. On both ORIGINAL cutoff-window families,

       E_I X_N^2 = (1/2) log N + O(1),
       limsup_N max_nu <X_N^2>_W/log N <= 4/3.

   In particular ||X_N||_(L2(W)) = O(sqrt(log N)). The weight and central
   coefficient are unchanged. This is an upper-energy estimate, not a claim
   that the weighted second moment has leading constant 4/3.

2. On N_m=floor(exp(m)), any fixed block j/d >= lambda_0 > 5/27 has a
   UNIFORM signed mixed-moment limit with the complete central coefficient:

       <X_N V_j>_W = Psi(s(j/d)) + o(1),
       Psi(s)=exp(1/2-s) cos(pi*s/4) [zeta(1+s)/2+1/12],
       j/d=s/2+4s^2-2s^3, 0<s<=1/2.

   The o(1) is uniform across every index in the growing block and both windows.
   Hence liminf min_(nu,j) <X_N V_j>_W >= c_* > 1.28374. This is a SIGNED
   bilinear correlation, not positivity of a gated minimum or of all coefficients.

3. The full original gated surplus admits shortening over a larger block. For
   j/d >= 1/4 and K=floor(sqrt(N)), its paid change is

       O(N^(-1/10) log N + N^(-1/30) (log N)^(3/2)) = o(1).

   Alternatively K=min(M,ceil((log(N+1))^6)) gives

       O((log N)^(-1/5) + N^(-1/30)(log N)^(3/2)) = o(1).

   The latter is an asymptotic polylogarithmic-length reduction. At N=64 it is
   capped at the full M=62; it is NOT the eight-term finite experiment.

4. The finite N=64 check freezes the larger block j=2,3,4,5, K=8, and leaves
   j=0,1 and the central gate untouched. Both restored surpluses are positive.
   A proved ONE-SIDED transport allowance gives floors >0.8377 and >0.9879;
   the more conservative absolute transport still gives >0.3389 and >0.8672.

The main new arithmetic information is the central energy bound and simultaneous
signed centre–upper correlations. The remaining joint sign is unresolved. Even
positive correlations with every upper coefficient do not establish
<X_+ min_j V_j> > 0; an exact counter-control appears in Section 8.
There is no new zero census, selected physical region, or RH claim.

## 2. Unchanged source quantities

For N>=64 set

    J=floor((N/64)^(1/3)), M=N-J-1,
    ell=1/[50(J+1)],
    I_(N,nu)=[(1+2nu)/4-ell/2,(1+2nu)/4+ell/2], nu=0,1,
    a=N+r, t=2*pi*a^2, d=ceil(log(N+1)),
    epsilon=(-1)^(N+nu), theta0=2*pi*a^2 log(a)-pi*a^2-pi/8,
    exp(i chi)=epsilon exp(i theta0), W=(1+cos chi)^2.

E_I is the ordinary normalized r integral; <f>_W=E_I(Wf)/E_I W. In particular
0<=W<=4 and the existing elementary phase estimate gives E_I W=3/2+o(1).

Keep

    B_(d,j)(z)=sum_(k<=j) binom(j,k)/binom(d,k) *z^(2k)/(4^k*(2k)!),
    s_j=B_(d,j)(d),
    beta_j=epsilon Re sum_(n<=M) sqrt(a/n) exp(i(theta0-t log n))
                                      B_(d,j)(log(a/n)+i*pi/4),
    c_N=H_J-E_N,
    H_J=(2/3)(J+1)-503/1000,
    E_N=(e^2/9)N^(-(log 16-5/2))+(log N+2)/(4*pi*N),
    Z_j=(beta_j+c_N)/s_j, X=Z_0/sqrt(N), V_j=(2s_d/N)Z_j,
    S_N=<X_+ min_(0<=j<=d) V_j>_W.

The all-N approximation and tail theorem remain inherited. In particular
0<c_N<N^(1/3)/3. There is no change in the sufficient full-strip sign criterion.
The completed zeta source is used in the proof below through an exact source
relation and a known UNCONDITIONAL mean-square estimate, not through a
numerical zeta evaluator, a zero count, or an RH assumption.

## 3. A uniform bridge from the actual central coefficient to Hardy's real function

Let theta_kappa(t)=arg[pi^(-(1/2+it)/2)Gamma((1/2+it)/2)] use the existing
continuous phase. Write

    Z_H(t)=exp(i theta_kappa(t))*zeta(1/2+it),

which is real. This symbol is different from the normalized coefficient Z_j.
The reflected auxiliary identity gives exactly

    Z_H(t)/2=Re[exp(i theta_kappa(t))*R(1/2+it)].

The inherited auxiliary bound [A1] at sigma=1/2 is

    |R-P_N| <= a^(-1/2)(1/2+b),
    b <= 1/(6*pi*a)+121*2^(3/4)/(700*a^2).

The existing Gamma-phase bound is

    |theta_kappa-theta0| <= 17/(48t)+4/(45t^3) < 1/t.

Thus, WITHOUT using the sign of any term,

    X = (epsilon/2)*sqrt(a/N)*Z_H(t)+e_N(r),

where

    |e_N| <= sqrt(a/N)*(J+1)/sqrt(N-J)
             +(1/2+b)/sqrt(N)
             +sqrt(a/N)*2sqrt(N)/t + c_N/sqrt(N).       (C1)

Each term is retained: deleted cutoff-tail summands, the full auxiliary
remainder, the small Gamma-phase change, and the original deterministic shift.

For N>=64, J+1<=N^(1/3)/2, N-J>=(63/64)N, a/N<65/64,
t>6N^2, b<1/500, and c_N<N^(1/3)/3. Also
sqrt(65/63)<33/32 and sqrt(65/64)<33/32. Dividing (C1) by N^(-1/6),
the four allowances have sum at most

    33/64 + 251/2000 + 11/8192 + 1/3 < 1.

Consequently the useful completely uniform estimate is

    |X-(epsilon/2)sqrt(a/N)*Z_H(t)| < N^(-1/6).          (C2)

This bridge does not evaluate Z_H numerically. It uses the already retained
source theorem. No multiplicative factor has been differentiated as an error
bound or treated as an independently variable phase.

## 4. Imported mean-square bound on these exact window lengths

Define the classical error term

    E_zeta(T)= integral_0^T |zeta(1/2+it)|^2 dt
               -T[log(T/(2*pi))+2gamma-1].

Watt's unconditional bound is E_zeta(T)=O(T^(131/416) log^4 T). Both endpoints
of an original r window have height comparable to N^2. Its physical length is

    H_N=4*pi*(N+r_center)*ell asymp N^(2/3) asymp T^(1/3).

Subtracting the two global mean-square formulas proves

    (1/H_N) integral_(t_-)^(t_+) |zeta(1/2+it)|^2 dt
       =log(T/(2*pi))+2gamma
           +O(H_N/T + T^(131/416)log^4(T)/H_N).

The relevant strict power gap is

    2/3 - 2*(131/416) = 23/624 > 0.

So the last error is O(N^(-23/624)log^4 N)=o(1). The factor
 dr/dt=1/[4*pi*(N+r)] differs from its window-centre value by a relative
O(ell/N), uniformly. Positivity of |zeta|^2 transfers the integral to the
ordinary r average, giving

    E_I |Z_H(t(r))|^2=2 log N+O(1).                       (C3)

The variation of a/N from one is O(1/N). By (C2), Cauchy–Schwarz, and (C3),

    E_I X^2=(1/2)log N+O(1).                             (C4)

The error due to e_N is O(N^(-1/6)sqrt(log N)+N^(-1/3)), so it is harmless.
Finally 0<=W<=4 and E_I W ->3/2 imply

    limsup_N max_nu <X^2>_W/log N <=4/3,
    ||X||_(L2(W))=O(sqrt(log N)).                        (C5)

This bound is source-specific. Replacing the central coefficient by the
modulus of an arbitrary length-N Dirichlet polynomial before applying the
functional equation loses the cancellation needed for (C5).

The external theorem is a new analytic dependency. It does NOT determine
individual source signs, zero locations, or the required joint minimum.
No effective constant or numerical starting cutoff is claimed in (C3)-(C5).
In particular 4/3 log N is not installed as a finite upper bound at N=64.

## 5. The uniform spectral envelope inherited from the current checkpoint

The latest interior-spectrum derivation proves two facts about the exact
positive-coefficient kernels. They are explicitly the hypotheses used here.
For j/d in a fixed compact block [lambda_0,1], let s(lambda) solve

    lambda=s/2+4s^2-2s^3, 0<s<=1/2.

Positive kernel weights have their mass concentrated near k/d=s/2. This gives

    B_(d,j)(d+z)/s_j -> exp(s(j/d)*z)

uniformly in the block on each bounded complex z set. This is the checkpoint's
positive-weight concentration theorem, not a numerical extrapolation.

For each fixed beta with 1/2<beta<1/2+s(lambda_0), the same checkpoint proves,
for all sufficiently large N with constants uniform in j, nu and r,

    b_(n,j,N)=(2s_d/N)*sqrt(a/n)
                  *B_(d,j)(log(a/n)+i*pi/4)/s_j,
    |b_(n,j,N)| <= C n^(-beta),
    |partial_r b_(n,j,N)| <= (C/N)n^(-beta).              (S1)

The deterministic shift in V_j is left unchanged. For the tail past K,
all ratio off-diagonals are paid, giving

    ||V_j-V_j^[K]||_2
       <= C[K^(1/2-beta)+N^(2/3-beta)sqrt(log N)].         (S2)

Here V_j^[K] retains the exact b_(n,j,N), phase chi, normalizer and shift.
For (S2), the off-diagonal reciprocal sum is O(N^(2-2beta)log N),
multiplied by 1/(N ell). This produces N^(4/3-2beta)log N in the squared
norm. Restricting to the upper block does not remove a source contribution
without this payment. We use 2/3<beta<1, so all sums stated below have the
claimed estimates.

There is a strict threshold: 1/2+s(lambda_0)>2/3 exactly when
lambda_0>5/27. No assertion at that boundary or below it follows from (S2).

## 6. Transfer inside the complete central gate and coefficient minimum

Let A_N={ceil(lambda_0 d),...,d}. Form Vhat by using V_j^[K] on A_N and
leaving every lower index unchanged. For the EXACT same gate X_+,

    |S_N-<X_+ min_j Vhat_j>_W|
       <= <X_+ max_(j in A_N)|V_j-Vhat_j|>_W
       <= ||X||_2 [sum_(j in A_N)||V_j-Vhat_j||_2^2]^(1/2).

Since d+1=O(log N), (C5) and (S2) prove

    error <= C[K^(1/2-beta)log N
                    +N^(2/3-beta)(log N)^(3/2)].         (T1)

This is a bound on the growing maximum multiplied by the FULL, unchanged gate.
It is not a fixed-coordinate L2 limit being multiplied by an unbounded factor.
The nontruncated lower block stays inside both minima.

At lambda_0=1/4 choose beta=7/10. It is strictly admissible because
lambda(1/5)=61/250<1/4. For K=floor(sqrt N), (T1) is

    O(N^(-1/10)log N+N^(-1/30)(log N)^(3/2)).            (T2)

For K=min(M,ceil((log(N+1))^6)), eventually K~(log N)^6 and (T1) is

    O((log N)^(-1/5)+N^(-1/30)(log N)^(3/2)).            (T3)

Both tend to zero, without an effective onset. The polylog rule does not imply
that K is small at the inherited finite example. The finite check uses (T2)'s
K=8, with its ACTUAL finite difference, not a numerical value invented for C.

A useful one-sided version is also exact. Put

    B_minus(r)=max(0,max_(j in A_N)(Vhat_j(r)-V_j(r))).

Then

    min_j V_j >= min_j Vhat_j-B_minus,
    S_N >= <X_+(min Vhat-B_minus)>_W.                    (T4)

A positive removed tail cannot hurt this lower bound. Formula (T4) retains all
negative contributions and is bounded by (T1) because B_minus<=max|Vhat-V|.

## 7. A uniform SIGNED central–upper correlation theorem

This is distinct from the transfer result. Take the degree-edge sequence
N_m=floor(exp(m)), with d=m+1, and a fixed lambda_0>5/27. Choose
2/3<beta<1/2+s(lambda_0) and a constant p>1/(2beta-1). Let
K=min(M,ceil((log(N+1))^p)). The error in replacing V_j by its short sum
inside <X V_j> is, uniformly in j,

    O(K^(1/2-beta)sqrt(log N)+N^(2/3-beta)log N)=o(1).    (M1)

The gate is not inserted here: this is the ORDINARY signed bilinear moment.
The coefficient shift contributes O(N^(-1/6)sqrt(log N)) at most.
The central coefficient remains complete throughout.

Write the central amplitude a_n=sqrt(a/N)n^(-1/2). Expand the short mixed
product using W=(1+cos chi)^2, just as in the earlier endpoint-resonance proof.
Ratio phases have X=n/m, product phases X=nm, and harmonics are fixed integers.
Before dividing by E_I W, exactly two families of constant phases survive:

    (3/4) E_I sum_(n<=K) a_n Re b_(n,j,N),
    (1/8) E_I a_1 Re b_(1,j,N).

After division by 3/2+o(1), their factors are 1/2 and 1/12.
No diagonal-only lower bound is being assumed: all other terms are estimated.
Their amplitudes and total variations satisfy

    |a_n b_m| <= C n^(-1/2)m^(-beta),
    integral_I |(a_n b_m)'| <= (C ell/N)n^(-1/2)m^(-beta).

A complete list of sufficient upper costs is:

| Nonconstant class | Uniform sufficient bound, constants depending on beta |
|---|---|
| zero ratio, n!=m | O(N^(-2/3)K^(3/2-beta)log(2K)+N^(-1/6)K^(1-beta)) |
| other fast ratio/product harmonics | O(N^(-1/6)K^(1-beta)) |
| ratio h=1,m=1 near n=N | O(N^(-1/6)log N) |
| product h=1 near nm=N | O(N^(-1/2)K^(3/2-beta)+N^(-1/6)log N) |

To justify the last line, retain |N+r-nm| >= (1+|N-nm|)/10. At fixed m,
the products have spacing m, so

    sum_(n:N/2<=mn<=2N) min(1,B/(1+|nm-N|))
                        <= 2+(2B/m)H_(2N+1), B=O(ell^(-1)).

Their amplitude is O(N^(-1/2)m^(1/2-beta)). Summation uses
sum_(m<=K)m^(1/2-beta)=O(K^(3/2-beta)) and
sum_(m>=1)m^(-1/2-beta)<infinity. Exact products nm=N are included.
For the zero ratio, near n=m the reciprocal summand is bounded by
C m^(1/2-beta)/|n-m|. Outside [m/2,2m], use |log(n/m)|>=log 2.
For all other harmonics the earlier actual-height derivative bounds apply.
As K is polylogarithmic, nm<=NK is separated from a^2 eventually.
Every displayed nonconstant cost is o(1), uniformly over the growing j block.

Consequently

    <X V_j>_W = (1/2)E_I sum_(n<=K) a_n Re b_(n,j,N)
                  +(1/12)E_I a_1 Re b_(1,j,N)+o(1).      (M2)

On the declared sequence, d-log a ->1 and 2s_d/sqrt N ->sqrt e. For every
FIXED n the kernel limit in Section 5 gives, uniformly in j,

    b_(n,j,N) -> exp(1/2-s) exp(i*pi*s/4) n^(-1/2-s),
                  s=s(j/d).

The diagonal tail in (M2) is uniformly bounded by C sum_(n>F)n^(-beta-1/2).
It tends to zero as the fixed F increases. Therefore use fixed F first,
take N to infinity with uniform convergence for n<=F, then let F increase.
This justifies the limit of the diagonal even though K itself grows:

    max_(nu,j in A_N) |<X V_j>_W-Psi(s(j/d))| ->0,         (M3)
    Psi(s)=exp(1/2-s)cos(pi*s/4)[zeta(1+s)/2+1/12].

No nonlinear gate or growing maximum is passed through a fixed-support limit
in this proof. The actual phases are kept until their mixed integrals are paid.

For 0<s<=1/2, all three positive factors in Psi are decreasing in s.
For the zeta factor this follows term by term from its absolutely convergent
positive Dirichlet series at 1+s>1. Hence

    Psi(s)>=Psi(1/2)=c_*.

This proves the claimed simultaneous signed lower limit. It is not the
positive-central mixed moment and not the mean of the common minimum.

## 8. Why the remaining joint sign is still not a consequence

A two-state algebraic control makes the distinction exact. With equal weights,
let X=1 and let the three tested coefficients be

    (V_0,V_1,V_2)=(2,-2,10) or (2,10,-2).

Both upper bilinear moments <X V_1> and <X V_2> equal 4>0. Nevertheless
<X_+ min(V_0,V_1,V_2)>=-2. This is not proposed as an arithmetic source model;
it rejects the inference that positive signed correlations settle a minimum.

For the complete actual vector split

    L_N(r)=min_(j<ceil(lambda_0 d)) V_j(r),
    U_N(r)=min_(j>=ceil(lambda_0 d)) V_j(r).

The exact block identity is

    S_N=<X_+ U_N>-<X_+(U_N-L_N)_+>.                       (J1)

The shortened block may be inserted using the paid error in Section 6.
Both terms still refer to one height. The sign of the first term cannot be
recovered by replacing min_j <X V_j> with <X_+ min_j V_j>.
The spectral mixed theorem supplies a uniform bilinear baseline, while
(J1) identifies the active-index and gate correlations still needing a bound.

The earlier R-Q<0.5172 target on N_m is unchanged. No claim is made that
Section 7 bounds that signed combination. Winding, multiplicity, cutoff
compatibility and absolute initial-count closure remain separate obligations.

## 9. Finite calculation and evidence scope

The inherited 21-member endpoint-sign package authenticates. Its compact
2,048-cell input is copied byte-for-byte, retaining W, X, every V_j, all exact
r endpoints and the original interpolation/source allowances. The incoming
interior-spectrum report and derivation were read remotely, but its 87-member
archive and historical pins were not reaudited.

The finite plan fixes lambda_0=1/4, j=2,3,4,5, K=8 before new arithmetic.
The lower indices j=0,1 stay unchanged. The numerical source is N=64,d=5,
with the same error payment 0.271900134725 and source-sized rational scales.

Each new short coefficient is evaluated on a COMPLETE original r cell.
For a_c=64+r_mid and u=r-r_mid, use the exact phase Taylor expansion

    phi_n(a)=phi_n(a_c)+4*pi*a_c*log(a_c/n)*u
                  +2*pi*(log(a_c/n)+1)*u^2+remainder,
    |remainder| <= [2*pi/(3*a_min)]|u|^3.

The third derivative is exactly 4*pi/a. The amplitude, logarithm, full finite
B_(5,j) and deterministic shift are interval-evaluated on the same whole cell.
No special-function values, new physical heights, or finite selected points
are used as source input. At each precision the build uses 16,384 elementary
summand phase enclosures and produces 8,192 short-coefficient intervals.

Primary complete-window findings, rounded outward:

| Window | Signed products <X V_2>,<X V_3>,<X V_4>,<X V_5> |
|---|---|
| first | [1.83196,1.98365], [1.50853,1.63723], [1.27714,1.38972], [1.10079,1.20122] |
| second | [1.75778,1.91222], [1.49633,1.63105], [1.30001,1.42025], [1.14359,1.25246] |

These are finite intervals, not the limiting Psi values. In particular the
first finite endpoint interval lies BELOW c_*, and a test explicitly prevents
using the asymptotic lower limit as a finite numerical floor.

For the exact full-block decomposition (J1):

| Window | <X_+ U_N> | <X_+(U_N-L_N)_+> | Direct original surplus lower |
|---|---|---|---|
| first | [1.09769684,1.18862693] | [0.01137371,0.01591024] | >1.0846 |
| second | [1.05774819,1.14499883] | [0.00363699,0.00691503] | >1.0528 |

For the larger SHORTENED block, with transport paid cellwise BEFORE averaging:

| Window | Shortened surplus lower | Absolute-tail restored floor | One-sided restored floor |
|---|---:|---:|---:|
| first | >0.8864 | >0.3389 | >0.8377 |
| second | >1.0068 | >0.8672 | >0.9879 |

The one-sided costs have upper bounds 0.052412 and 0.020099. The absolute
costs are larger. Favorable discarded contributions are not treated as
losses by (T4), but all adverse contributions are paid.

The finite calculation uses the full inherited coefficient enclosures to
certify the actual difference from the short coefficients. It is NOT an
eight-term-only source certificate. It does not substitute an asymptotic
constant for a finite error bound. These are alternative enclosures of the
same historical surplus, not new heights or a stronger physical region.

## 10. Verification, provenance and limits

The new 50- and 80-digit elementary builds use mpmath.iv and produce identical
mathematical intervals after excluding precision metadata. The primary
acceptance uses exact Fraction arithmetic. A separate program imports none
of its interval/acceptance code, reconstructs all window/cell partitions,
and reaggregates the signed products, full minimum and transport. It shares
the actual source-cell and short-coefficient inputs; no independent source
library is claimed.

The named test suite checks every retained index, both complete windows,
all eight positive upper mixed moments, both whole-vector surplus conditions,
both transport variants, analytical exponent and constant controls, input
integrity and rejection of modified geometry, scales and error payments.
It includes the non-positive joint-sign counter-control in Section 8.

The asymptotic arguments are WRITTEN proofs using the explicitly attributed
external mean-square theorem and the incoming kernel bounds. Finite tests
supplement their algebra; they do not establish an infinite sequence by
sampling or constitute proof-assistant formalization. No effective onset is
claimed. No historical source, laptop file, bookmark or repository is edited.

## References and read dependencies

[A1] J. Arias de Reyna, *Simple bounds for the auxiliary function of Riemann*,
arXiv:2407.06681v1, equations (18)–(24):
https://arxiv.org/html/2407.06681v1 . Used through the inherited source theorem.

[A2] N. Watt, *A note on the mean square of |zeta(1/2+it)|*, JLMS 82 (2010),
279–294. https://doi.org/10.1112/jlms/jdq024 . Unconditional mean-square
error E(T) << T^(131/416)log^phi(T+2), phi<4. NEW external dependency.

[A3] J. Bourgain and N. Watt, *Decoupling for perturbed cones and mean square
of |zeta(1/2+it)|*, arXiv:1505.04161v1, page 1, Theorem 4 and the following
paragraph: https://arxiv.org/pdf/1505.04161 . It states the definition of E,
recalls [A2], and proves an even stronger unconditional exponent. Only the
weaker [A2] result is needed here. This paper is not claimed as our result.

[D1] User's current `rh_interior_spectrum_20260915/DERIVATION.md`, sections
2–6, read in full via Desktop Commander at
`C:/Users/ollet/Documents/Codex/2026-07-03/l/work/rh_compute/tmp/rh_interior_spectrum_20260915/delivery/rh_interior_spectrum_20260915/`.
Its positive-kernel concentration, uniform coefficient envelope and complete
ratio-tail estimate are restated in Section 5, not claimed newly proved here.

[D2] Authenticated `RH_Endpoint_Sign_Energy_2026-09-15_v1.zip` (21 listed
members), source-cell input and normalization. Read derivation and preserved
source arrays are the runtime dependency; old special-function evaluations
and historical-pin audits were not replayed.

[D3] `RH_Assembled_Gate_Derivation_2026-09-15_v1.md`, read in full; the signed
mixed-harmonic bookkeeping and explicit near-product progression estimate.
Sections 3–7 above supply the new source-aware energy and uniform block use.

The new work grants no general reuse permission. Third-party attribution is
retained. No novelty priority or resolution of RH is asserted.
