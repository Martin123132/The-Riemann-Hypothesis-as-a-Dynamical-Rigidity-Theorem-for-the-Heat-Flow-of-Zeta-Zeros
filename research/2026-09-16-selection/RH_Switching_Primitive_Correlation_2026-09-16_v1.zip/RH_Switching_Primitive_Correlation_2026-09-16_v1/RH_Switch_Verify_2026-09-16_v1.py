"""Verify the seal, rerun both standalone programs, and compare canonical bytes.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def verify(root=ROOT):
    manifest=json.loads((root/'RH_Switch_Manifest_2026-09-16_v1.json').read_text())
    for name,expected in manifest['files'].items():
        if sha((root/name).read_bytes())!=expected:raise ValueError('manifest mismatch: '+name)
    parent=root/'RH_Switch_Parent_Archive_2026-09-16_v1.zip'
    with ZipFile(parent) as z:
        mn=[x for x in z.namelist() if x.endswith('RH_Active_Index_Manifest_2026-09-16_v1.json')]
        if len(mn)!=1:raise ValueError('parent manifest roster')
        prefix=mn[0].rsplit('/',1)[0]+'/'
        pm=json.loads(z.read(mn[0]))
        for name,h in pm['files'].items():
            if sha(z.read(prefix+name))!=h:raise ValueError('parent mismatch')
    pairs=[('RH_Switch_Builder_2026-09-16_v1.py','RH_Switch_Results_2026-09-16_v1.json'),
           ('RH_Switch_Independent_2026-09-16_v1.py','RH_Switch_Independent_Results_2026-09-16_v1.json')]
    records=[]
    with tempfile.TemporaryDirectory(prefix='rh_switch_verify_') as td:
        import shutil
        # Each standalone replay has ONLY the program and the two source inputs.
        for idx,(prog,result) in enumerate(pairs):
            work=Path(td)/str(idx);work.mkdir()
            names=[prog,'RH_Switch_Full_Source_2026-09-16_v1.json.gz','RH_Switch_Pilot_Source_2026-09-16_v1.json.gz']
            for name in names:shutil.copyfile(root/name,work/name)
            out=work/result
            run=subprocess.run([sys.executable,str(work/prog),'--full',str(work/names[1]),'--pilot',str(work/names[2]),'--output',str(out)],capture_output=True,text=True,timeout=40,check=True)
            b=out.read_bytes()
            if b!=(root/result).read_bytes():raise ValueError('replay mismatch: '+result)
            records.append({'file':result,'sha256':sha(b),'byte_identical':True,'isolated_runtime_files':3})
    tests=subprocess.run([sys.executable,str(root/'RH_Switch_Tests_2026-09-16_v1.py')],capture_output=True,text=True,timeout=40,check=True)
    if 'Ran 32 tests' not in tests.stderr or '\nOK\n' not in tests.stderr:raise ValueError('unexpected test completion')
    return {'manifest_members_verified':len(manifest['files']),'parent_members_verified':len(pm['files']),
            'tests_passed':32,'reproduced':records,'new_source_evaluations':0,
            'shared_source_enclosures':True,'historical_pin_audit':False,'remote_access':False}
if __name__=='__main__':print(json.dumps(verify(),sort_keys=True,indent=2))
