# Selection-dependent correlation as a signed switching-boundary sum

**16 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Result and exact scope

This continuation addresses the selection-dependent correction in the preceding active-index certificate. It leaves the source, weight, gate, degree, scales, lower block, finite pilot, source payment and two original N=64 windows unchanged.

There are three results:

1. The selection correction is exactly a signed sum of centred arithmetic primitives at the heights where the selected upper index changes. No differentiation of a discontinuous selector, and no fixed-Fourier approximation of an N-dependent indicator, is used.
2. Under the inherited source estimates, each full upper coefficient's centred primitive is uniformly

       O((1+log N)^(-7/10) + N^(-1/30)*(1+log N)).

   The supremum includes EVERY prefix of either original window and every index j/d >= 1/4. This is an asymptotic estimate with no effective onset. It is not a bound for the accumulated adaptive selection correction when the number of switches grows.
3. In the unchanged finite data, collecting common-reference and repeated-prefix terms BEFORE interval evaluation certifies the selection correction as strictly negative in BOTH windows. The second window's previous enclosure crossed zero. Both finite complete-surplus calculations still pass after this adverse correction, the gate correction, lower-block loss and selection regret are paid.

| Window | Primary selection correction Gamma | Independent correction | Primary completely paid surplus lower |
| --- | --- | --- | --- |
| [0.245,0.255] | [-0.223790633,-0.171350417] | [-0.223112026,-0.172108881] | >1.01918 |
| [0.745,0.755] | [-0.160806557,-0.106772617] | [-0.159765061,-0.107966636] | >0.97242 |

All displays are rounded outward. These are enclosures of the same historical normalized surplus, not new source margins, heights or counts. The two implementations share the existing whole-cell source enclosures.

The remaining theorem concerns the SIGNED accumulation of primitives at the actual switches, coupled to the gate and lower block. Small individual primitives do not suffice without that additional argument. Section 8 gives an analytic counter-control demonstrating why.

## 2. Unchanged source and selection definitions

For N>=64 retain

    J=floor((N/64)^(1/3)), M=N-J-1, d=ceil(log(N+1)),
    ell=1/[50(J+1)], a=N+r, t=2*pi*a^2,
    I_(N,nu)=[(1+2nu)/4-ell/2,(1+2nu)/4+ell/2], nu=0,1,
    epsilon=(-1)^(N+nu), exp(i chi)=epsilon exp(i theta0(t)),
    W=(1+cos chi)^2.

Let

    B_(d,j)(z)=sum_(k<=j) binom(j,k)/binom(d,k)*z^(2k)/(4^k*(2k)!),
    s_j=B_(d,j)(d),
    beta_j=Re sum_(n<=M) sqrt(a/n)*exp(i(chi-t log n))
                                      *B_(d,j)(log(a/n)+i*pi/4),
    c_N=H_J-E_N,
    H_J=(2/3)(J+1)-503/1000,
    E_N=(e^2/9)*N^(-(log 16-5/2))+(log N+2)/(4*pi*N),
    Z_j=(beta_j+c_N)/s_j, X=Z_0/sqrt N, P=X_+,
    V_j=(2s_d/N) Z_j.

The original probability measure is

    dmu(r)=W(r)dr / integral_I W,

and angle brackets denote its expectations. No complex argument principle is applied to this weight. The exact normalized selection surplus is

    S_N=<P min_(0<=j<=d) V_j>.

A positive surplus supplies the inherited sufficient full-width sign-selection condition. Winding and the absolute multiplicity count are separate obligations.

The upper block is A_N={ceil(d/4),...,d}; the lower block is its complement. Let iota(r) be a measurable upper-index selector, based on the shortened upper vector. The finite rule is precisely the parent rule: on each complete source cell choose the smallest midpoint of the four K=8 pilot intervals, breaking ties by the smaller index. The full coefficients do not choose the policy.

Set

    f_j=X V_j, C_j=<f_j>, I_j=1_{iota=j}, p_j=<I_j>,
    Gamma_sel=sum_j [<I_j f_j>-p_j C_j].

The parent establishes the exact full-surplus identity

    S_N=B_mix+Gamma_sel+D_gate-B_low-T_sel,
    B_mix=sum_j p_j C_j,
    D_gate=<(-X)_+ V_iota>,
    B_low=<P(V_iota-L)_+>, L=min_lower V_j,
    T_sel=<P [min(L,V_iota)-min(L,min_upper V_j)]>.

The last term is nonnegative and has the parent's paid adaptive-index transport estimate. Neither Gamma_sel nor D_gate has a sign imposed by definition.

## 3. Exact switching-boundary formula

Write I=[r_-,r_+] and define the centred primitive

    F_j(u)= integral_(r_-)^u (f_j(r)-C_j) dmu(r).

It is absolutely continuous and satisfies F_j(r_-)=F_j(r_+)=0. Suppose iota is constant on the finitely many intervals cut by

    r_- < t_1 < ... < t_B < r_+,

and changes from i_b^- to i_b^+ at t_b. Then

    Gamma_sel = sum_(b=1)^B [F_(i_b^-)(t_b)-F_(i_b^+)(t_b)].       (S1)

Proof: integrate f_i-C_i on each constant-policy interval. Its integral is the difference of that coefficient's primitive at the two ends. All window endpoint terms vanish. At each internal boundary the outgoing primitive has sign plus and the incoming one sign minus. Collecting those terms proves (S1).

No smoothness of the selector is asserted. For a finite-short-sum argmin, the coefficient differences are real analytic near a closed window. A nonidentically-zero difference has finitely many zeros there; identical pairs are resolved by the deterministic tie rule. Thus a finite switching partition is available at each fixed cutoff, but this observation gives NO uniform switch-count bound as N grows. The finite executed selector switches at cell faces; those faces are not asserted to be actual equality points of the pilot functions.

### Exact common-reference cancellation

Fix any upper reference index q. Replacing every f_j by f_j-f_q leaves Gamma_sel unchanged, because

    sum_j I_j=1, sum_j p_j=1.

At the primitive level every F_j is reduced by F_q, which cancels in each term of (S1). More generally an arbitrary common function may be added to all f_j with no change in Gamma_sel.

For the finite calculation q=d=5. We form X(V_j-V_d) BEFORE multiplying by W or enclosing the expression. The self-difference at j=d is exactly zero. This invariance concerns the selection correction only; it does not assert that the full surplus, lower-block screening or source value is invariant under a common source change.

## 4. Two equivalent ways to preserve the signed cancellation

### 4.1 Collect repeated prefixes before evaluating intervals

Index the original equal-length cells by l and let i_l be their selector. For j in the upper block define

    c_(l,j)=sum_(switch b after cell l)
                     [1_{outgoing at b=j}-1_{incoming at b=j}].

The exact telescoping identity is

    c_(l,j)=1_{i_l=j}-1_{i_last=j}.

Consequently its weighted mean is p_j-1_{i_last=j}, and subtracting this mean gives simply 1_{i_l=j}-p_j.

Let h be the common cell width and introduce the EXACT, generally unknown cell integrals

    a_l=(1/h) integral_cell W,
    b_(l,j)=(1/h) integral_cell W X(V_j-V_d),
    D=sum_l a_l.

Their enclosures come from whole-cell images, not the assumption that functions are constant. Formula (S1) becomes

    Gamma_sel=(1/D) sum_(l,j!=d) [1_{i_l=j}-p_j] b_(l,j).          (S2)

This is the primary acceptance formula. The primitive terms have been assembled symbolically before applying intervals. In particular, the exact identity mean(c_j)=p_j-1_{i_last=j} is used, rather than paying the total weight in numerator and denominator as unrelated copies.

### 4.2 An independent paired-group formula

Let A_i be the union of cells selected as i and define unnormalized integrals

    w_i=integral_(A_i) W,
    H_(i,j)=integral_(A_i) W X(V_i-V_j),
    Z=integral_I W.

Then

    Gamma_sel = (1/Z^2) sum_(i,j) w_j H_(i,j).                    (S3)

For i=j the term is exactly zero. To prove (S3), expand its numerator as

    Z integral W X V_iota
           -sum_j (integral W I_j)(integral W X V_j).

Division by Z^2 gives the definition of Gamma_sel. Equivalently it is a double integral over two height variables drawn from the same integration measure. This algebra introduces no model of independent prime phases at a single height.

The independent code computes (S3) directly, with its own Fraction interval operations. It does not import the primary builder, primitive arrays or primary interval code.

## 5. A uniform source bound for every centred prefix primitive

This is an analytic consequence of the full-source central-energy theorem and the upper-kernel envelopes in the included central-energy derivation [D2]. It uses their stated hypotheses; neither Watt's external theorem nor the auxiliary source estimates are re-proved here.

Let Lambda=1+log N. For every j/d>=1/4, choose beta=7/10 and

    K=min(M,ceil(Lambda^6)).

The following estimate holds uniformly over BOTH original windows, EVERY such index, and EVERY prefix endpoint u in the window:

    sup_(j,nu,u) |F_j(u)|
       =O(Lambda^(-7/10)+N^(-1/30)*Lambda).                       (S4)

There is no numerical constant or onset supplied. The primitive is centred with its EXACT full-window C_j. No rate for convergence of the spectral kernel to its limiting shape is needed to centre it.

### 5.1 Truncate only after keeping the complete central coefficient

The inherited hypotheses, uniform over this upper block, are

    ||X||_(L2(W))=O(sqrt Lambda),
    |b_(n,j,N)(r)|<=C n^(-beta),
    |partial_r b_(n,j,N)(r)|<=C n^(-beta)/N,
    ||V_j-V_j^[K]||_2
        <=C[K^(1/2-beta)+N^(2/3-beta)*sqrt Lambda].

The exact b_(n,j,N) include the source-sized kernel and normalization. V_j^[K] retains the original deterministic shift. The weighted L1 difference between X V_j and X V_j^[K] is at most

    r_N=C[K^(1/2-beta)*sqrt Lambda+N^(2/3-beta)*Lambda].           (S5)

Every prefix integral of that difference is bounded by the same FULL-WINDOW L1 norm. After centring, the cost is at most 2r_N. There is no division by a possibly tiny prefix length. With beta=7/10 and K~Lambda^6, (S5) is

    O(Lambda^(-7/10)+N^(-1/30)*Lambda).

### 5.2 The elementary mixed-phase bounds apply uniformly to prefixes

Write

    X=X0+c_N/sqrt N,
    X0=Re[e^(i chi) sum_(n<=M) a_n e^(-it log n)],
    a_n=sqrt(a/N)n^(-1/2),
    V_j^[K]=Re[e^(i chi) sum_(m<=K) b_m e^(-it log m)]+q_j,
    q_j=(2s_d/N)c_N/s_j=O(N^(-1/6)).

The shift terms cost O(N^(-1/6)*sqrt Lambda) in weighted L1, uniformly. Upper-coefficient L2 norms are bounded by the same tail estimate with a fixed initial truncation. All shifts are therefore paid rather than silently removed.

Expanding W X0 Re(e^(i chi)sum b_m e^(-it log m)) yields the ratio/product harmonics already proved in [D2]. Before normalization, the exactly nonoscillating contribution is

    A_j(r)=(3/4) sum_(n<=K) a_n Re b_n
                              +(1/8) a_1 Re b_1.

Since beta>1/2, the envelopes give

    |A_j(r)|<=C, |A_j'(r)|<=C/N,

by summing n^(-beta-1/2). Thus variation of A_j throughout the original window is O(ell/N), with uniform constants.

For a nonconstant phase Phi=h*theta0-t log Q, the derivative is

    Phi'=4*pi*a*(h log a-log Q).

On any subinterval, integration by parts on at most two monotone pieces bounds the UNNORMALIZED integral by a constant times (sup amplitude + total variation)/inf|Phi'|. The number of monotone pieces does not increase on restriction. Normalize by the ORIGINAL window length ell, not by the subinterval length. The trivial bound also uses that the subinterval length is at most ell. Consequently every complete-window error estimate below holds simultaneously for every prefix.

The sufficient costs, with the full central index n<=M and endpoint index m<=K, are:

| Nonconstant mixed phase class | Normalized absolute cost, uniformly in prefix |
| --- | --- |
| h=0 ratio, n!=m | O(N^(-2/3)K^(3/2-beta) log(2K)+N^(-1/6)K^(1-beta)) |
| other fast ratio/product harmonics | O(N^(-1/6)K^(1-beta)) |
| h=1 ratio, slow m=1 terms | O(N^(-1/6)Lambda) |
| h=1 product, nm near N | O(N^(-1/2)K^(3/2-beta)+N^(-1/6)Lambda) |

For clarity the potentially slow products are NOT omitted. For r in the original windows and integer nm,

    |N+r-nm| >= (1+|N-nm|)/10.

For fixed m, the products have spacing m. Charging the nearest point on each side trivially and the others by their inverse distances gives

    sum_(n:N/2<=nm<=2N) min(1,B/(1+|nm-N|))
        <=2+(2B/m)H_(2N+1), B=O(ell^(-1)).

Multiplication by the amplitude C N^(-1/2)m^(1/2-beta) and summation gives the last table row. Exact nm=N is included. The other ratio bounds split n near m from its complement, using log(n/m)>=(n-m)/n. Products h>=2 are separated from a^h because K is only polylogarithmic. These estimates are inherited mixed-sum arguments applied on prefixes, not a random-phase or full-diagonal assumption.

For beta=7/10, K~Lambda^6 the table costs are bounded by sums of

    N^(-2/3)Lambda^(24/5)log(2Lambda),
    N^(-1/6)Lambda^(9/5),
    N^(-1/6)Lambda,
    N^(-1/2)Lambda^(24/5).

Each is O(N^(-1/30)Lambda) eventually. The statement concerns asymptotic orders, not finite numerical dominance at N=64.

### 5.3 Centring by the actual probability mass

Let D_W=integral_I W. Direct integration of the finite harmonics of W gives, uniformly in u,

    integral_(r_-)^u W=(3/2)(u-r_-)+O(1/(N log N)),
    D_W=(3/2)ell+O(1/(N log N)).

Since ell is comparable to N^(-1/3), the normalized mass of a prefix differs from its ordinary length fraction by O(N^(-2/3)/log N). Positivity of D_W eventually is already in the parent; it is checked directly in the finite calculation.

Replace A_j(r) by A_j at the window centre at cost O(ell/N). Its prefix integral is then the length fraction times its full integral. The preceding weight-mass discrepancy, the nonconstant table, the shifts, and twice (S5) bound the difference from centring by the exact C_j. This proves (S4).

The estimate is valid at all sufficiently large cutoffs in both window families, not only the degree-edge subsequence. It gives no signed value of F_j at a switch and no bound on the number of switches.

## 6. What (S4) implies for adaptive selection, and what it does not

If B_N is the number of actual policy changes, (S1) and (S4) imply the sufficient bound

    |Gamma_sel| <= 2 B_N sup_(j,u)|F_j(u)|
        =O(B_N[Lambda^(-7/10)+N^(-1/30)Lambda]).                 (S6)

For example a separately justified B_N=o(Lambda^(7/10)) would make this bound vanish. No such bound has been proved for our source selector. A fixed finite grid's 21 or 14 switches at N=64 is not a uniform counting theorem.

The signed form (S1) is sharper than (S6) and retains cancellations across switches. At a true exact-pilot-argmin switch from i to j, the pilot coefficients tie; (S1) must nevertheless use their centred PRIMITIVES, not their instantaneous values. Equality of pilot values does not make F_i(t)-F_j(t) zero. The discrete finite policy need not even switch at a tie.

For any reference q, the pairwise difference F_i-F_j is independent of q. Thus an argument may estimate the actual signed jump sum through pair-specific arithmetic without paying a large component common to every coefficient. That is the next source-specific opportunity, not an already-established sign bound.

## 7. Complete finite calculation

All 2,048 original complete source cells and all six V_j are retained. The pilot has the four full-cell eight-term upper images. The selector agrees with the incoming one on every cell:

| Window | selected j=2 | j=3 | j=4 | j=5 | policy changes |
| --- | --- | --- | --- | --- | --- |
| first | 449 | 19 | 16 | 540 | 21 |
| second | 404 | 14 | 18 | 588 | 14 |

These changes occur at exact rational cell faces, recorded in the new result file. They are policy changes, not zeros of zeta, not counts of true argmin crossings and not approximations to a physical probability.

The main program uses (S2). The independent program uses (S3), without importing primary code. Both prove the negative correction and positive fully paid surplus. The complete budgets in the primary calculation are:

| Original-W expectation | First window | Second window |
| --- | --- | --- |
| fixed-index mixture B_mix | [1.322229380,1.471724777] | [1.340974612,1.499030892] |
| selection correction Gamma | [-0.223790633,-0.171350417] | [-0.160806557,-0.106772617] |
| negative-central gate correction | [-0.061946302,-0.047818735] | [-0.198836384,-0.167917725] |
| lower-block loss | [0.012233062,0.016837222] | [0.004047666,0.008131851] |
| effective selection regret | [0.000198807,0.000472857] | [0.000132854,0.000778639] |
| separately paid surplus | [1.019182368,1.240123755] | [0.972421183,1.220160028] |

All displays are outward-rounded. No asymptotic constant is substituted as a finite allowance. The independent surplus lower bounds exceed 1.01986 and 0.97346; both therefore establish the common floors 1.019 and 0.972.

The new bounds are not sharper than the earlier direct complete-surplus integration. Their new information is the resolved selection-correction sign, especially in the second window, and its explicit switch primitive ledger. Direct reference surplus bounds remain above 1.0846 and 1.0528.

### Why separately intervalizing every switch is too costly

If each primitive prefix is widened independently before summing, the same switch identity gives only

    first: [-1.702689709, 1.311395356],
    second: [-1.330626458, 1.074015421].

Both cross zero. These valid but inconclusive calculations remain in the output, together with every individual jump enclosure. There are overlapping prefixes and a shared normalization; charging each occurrence independently repeats uncertainty. Collecting their exact coefficients and the common reference first leads to (S2), which resolves the sign without changing input data.

No actual source integral is replaced by the midpoint of its enclosure. Midpoints choose the unchanged policy and provide discrete algebraic controls only. Source acceptance uses full-cell image bounds, including their inherited interpolation and source errors.

## 8. A control preventing an invalid unbounded inference

Small centred primitives do NOT by themselves make the adaptive correction small. On [0,1], use ordinary uniform measure, X=1, and

    V_2=b+sin(2*pi*m*r), V_3=b-sin(2*pi*m*r), b>0.

Both fixed-index means equal b. Let the selector choose the smaller one. Then

    Gamma_sel=-integral_0^1 |sin(2*pi*m*r)|dr=-2/pi,

for every positive integer m, while each centred primitive has sup norm at most 1/(pi*m), tending to zero. The number of policy switches grows like m. The functions are analytic; the failure is not caused by rough source data. This is an exact logic control, not an arithmetic model of our source.

The tests also implement a rational alternating-cell version: both fixed means are zero, the common minimum is always -1, and the primitive maximum is 1/(2m). The boundary formula and paired-group formula agree exactly for all tested integer instances. The general conclusion follows from the displayed formulas, not from sampling m.

Thus (S4) cannot be promoted to Gamma_sel=o(1) without controlling its signed switching sum or a compatible switching complexity. The finite source result does not supply that unbounded control.

## 9. Remaining sign comparison

On the declared degree-edge sequence, the parent's uniform signed theorem still yields

    B_mix=sum_j p_j <X V_j> >= c_*+o(1),
    c_*=cos(pi/8)[zeta(3/2)/2+1/12].

The newly resolved object is

    Gamma_sel=sum_switches(F_old-F_new).

The same full-surplus identity remains

    S_N=B_mix+Gamma_sel+D_gate-B_low-T_sel.

A sufficient next theorem is the same signed comparison

    limsup (B_low-D_gate-Gamma_sel)<c_*,

on the required admissible family, together with the already paid vanishing selection regret for the exact short-argmin policy. This stage has not established it. The new prefix estimate supplies controllable arithmetic primitives, and the switch identity identifies exactly where their correlated values must be bounded.

The earlier R-Q formulation has different terms and its 0.5172 threshold is not changed. Neither formulation supplies the later winding, multiplicity and absolute initial-count closure merely by selecting boundaries.

## 10. Verification, files and attribution

The parent archive is included unchanged; all 18 parent manifest entries were authenticated. The runtime needs only the two authenticated source files and its own program. The historical source integrations, parent analytic theorems and research-pin audit are inherited, not repeated.

There are 32 new named tests. They rebuild both complete results, check all 8,192 integer prefix-collection identities, verify covariance/switch/paired identities on exact arrays, retain the negative-switch-sum overpayment, exercise the many-switch counter-control, and reject altered geometry, missing cells or coefficients, changed scales, error payments and pilot bindings. No empty selection is accepted as a successful test.

The two implementations have different exact interval and aggregation code. They share source enclosures and written analytic hypotheses. Their agreement is not a second independent special-function evaluation or proof-assistant verification. The unbounded primitive estimate rests on Section 5's analytic argument, not the finite tests.

Only new container files are written. No laptop access, desktop change, repository modification, bookmark update or historical-file overwrite was performed. All launched computations are completed before delivery.

### References

[D1] Included unchanged active-index derivation: definitions, selector, exact full-surplus identity, and regret estimate. Its provenance hashes are retained in the supplied parent archive.

[D2] Included unchanged central-energy/joint-spectrum derivation, especially Sections 4–7: unconditional source-aware central L2 bound; exact coefficient envelopes; all nonconstant mixed-sum estimates. These are the inherited analytic inputs to Section 5. Watt's mean-square theorem remains explicitly attributed there, not claimed as a new result here.

[S1] NIST DLMF §2.3(i), integration by parts: https://dlmf.nist.gov/2.3 . The general technique is standard. The specific uniform prefix estimate and selection identities used here are proved above.

[S2] NIST DLMF §1.4, integration and variation: https://dlmf.nist.gov/1.4 . The finite switching formula is proved by direct telescoping; it requires no new claim about a general integration-by-parts theorem.

The supplied source is used within this private research workflow. No new reuse permission or novelty-priority claim is asserted.
