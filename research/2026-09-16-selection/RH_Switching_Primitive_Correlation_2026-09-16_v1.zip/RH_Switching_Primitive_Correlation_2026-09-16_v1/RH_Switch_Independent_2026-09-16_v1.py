"""Independent paired-group covariance replay (no imports from the primary).
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
Source enclosures and their analytic hypotheses are shared.
"""
import argparse,gzip,hashlib,json
from fractions import Fraction as F
from pathlib import Path
from math import comb,factorial
FH='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
PH='5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4'
U=(2,3,4,5)
def iv(x):
    if isinstance(x,(list,tuple)):
        a,b=F(x[0]),F(x[1])
    else:a=b=F(x)
    if a>b:raise ValueError('bad interval')
    return a,b
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    x=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]];return min(x),max(x)
def div(a,b):
    if b[0]<=0<=b[1]:raise ValueError('zero denominator')
    return mul(a,(1/b[1],1/b[0]))
def pos(a):return max(F(),a[0]),max(F(),a[1])
def mn(xs):return min(x[0] for x in xs),min(x[1] for x in xs)
def sumiv(xs):
    a=(F(),F())
    for b in xs:a=add(a,b)
    return a
def enc(a):return [str(a[0]),str(a[1])]
def read(p,h):
    b=Path(p).read_bytes()
    if hashlib.sha256(b).hexdigest()!=h:raise ValueError('source hash')
    return json.loads(gzip.decompress(b))
def build(fullp,pilotp):
    full=read(fullp,FH);pilot=read(pilotp,PH)
    scales=[sum((F(comb(j,k)*5**(2*k),comb(5,k)*4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    if (full['N'],full['degree'],pilot['N'],pilot['d'],pilot['K'])!=(64,5,64,5,8):raise ValueError('source contract')
    if list(map(F,full['scales']))!=scales or F(full['source_payment'])!=F('0.271900134725'):raise ValueError('normalization')
    if pilot['input_sha256']!=FH or pilot['whole_cell_evaluation'] is not True or pilot['upper_indices']!=list(U):raise ValueError('pilot contract')
    if [w['nu'] for w in full['windows']]!=[0,1] or [w['nu'] for w in pilot['windows']]!=[0,1]:raise ValueError('windows')
    out={'stage':'independent paired-group covariance','independent_primary_imports':False,'new_source_evaluation':False,'windows':[]}
    for nu,(fw,pw) in enumerate(zip(full['windows'],pilot['windows'])):
        ends=[F(49+100*nu,200),F(51+100*nu,200)]
        if list(map(F,fw['r']))!=ends or len(fw['cells'])!=1024 or len(pw['cells'])!=1024:raise ValueError('window')
        D=iv(0);groups={j:iv(0) for j in U};pairs={(i,j):iv(0) for i in U for j in U}
        ref=iv(0);diff={j:iv(0) for j in U};gate=iv(0);lower=iv(0);reg=iv(0);pol=[]
        for k,(c,p) in enumerate(zip(fw['cells'],pw['cells'])):
            r=[ends[0]+F(k,102400),ends[0]+F(k+1,102400)]
            if c['i']!=k or p['i']!=k or list(map(F,c['r']))!=r or list(map(F,p['r']))!=r:raise ValueError('cell')
            if len(c['V'])!=6 or len(p['Vshort'])!=4:raise ValueError('coefficients')
            w,x=iv(c['W']),iv(c['X']);v=list(map(iv,c['V']));h=list(map(iv,p['Vshort']))
            if w[0]<0 or w[1]>4:raise ValueError('weight')
            i=min(range(4),key=lambda j:(h[j][0]+h[j][1],j))+2;pol.append(i)
            D=add(D,w);groups[i]=add(groups[i],w)
            wx=mul(w,x);wp=mul(w,pos(x))
            for j in U:
                if i!=j:pairs[i,j]=add(pairs[i,j],mul(wx,sub(v[i],v[j])))
                if j!=5:diff[j]=add(diff[j],mul(wx,sub(v[j],v[5])))
            ref=add(ref,mul(wx,v[5]))
            gate=add(gate,mul(mul(w,pos(neg(x))),v[i]))
            l=mn(v[:2]);lower=add(lower,mul(wp,pos(sub(v[i],l))))
            other=mn([v[j] for j in U if j!=i])
            rr=mn([pos(sub(v[i],other)),pos(sub(l,other))])
            reg=add(reg,mul(wp,rr))
        if D[0]<=0:raise ValueError('zero mass')
        numerator=sumiv(mul(groups[j],pairs[i,j]) for i in U for j in U if i!=j)
        cov=div(numerator,mul(D,D))
        mix=add(div(ref,D),sumiv(mul(div(groups[j],D),div(diff[j],D)) for j in U if j!=5))
        gate,lower,reg=div(gate,D),div(lower,D),div(reg,D)
        surplus=sub(sub(add(add(mix,cov),gate),lower),reg)
        result={'selection_covariance':cov,'fixed_index_mixture':mix,'gate_correction':gate,'lower_block_loss':lower,'effective_regret':reg,'separately_paid_surplus':surplus}
        out['windows'].append({'nu':nu,'cells':1024,'switch_count':sum(pol[k]!=pol[k-1] for k in range(1,1024)),
          'selector_counts':{str(j):pol.count(j) for j in U},
          'values':{k:enc(v) for k,v in result.items()},'display':{k:[float(v[0]),float(v[1])] for k,v in result.items()},
          'negative_covariance_certified':cov[1]<0,'positive_paid_surplus':surplus[0]>0})
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--pilot',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    out=Path(a.output)
    if out.exists():raise FileExistsError(out)
    out.write_bytes((json.dumps(build(a.full,a.pilot),sort_keys=True,indent=2)+'\n').encode())
