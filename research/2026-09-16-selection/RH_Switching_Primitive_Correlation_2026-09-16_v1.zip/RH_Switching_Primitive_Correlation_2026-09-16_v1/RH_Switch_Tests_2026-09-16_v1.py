"""Exact controls and complete two-window replay.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import copy,gzip,hashlib,importlib.util,itertools,json,tempfile,unittest
from fractions import Fraction as F
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent

def module(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    out=importlib.util.module_from_spec(spec);sys.modules[name]=out;spec.loader.exec_module(out);return out
b=module('switch_builder','RH_Switch_Builder_2026-09-16_v1.py')
i=module('switch_independent','RH_Switch_Independent_2026-09-16_v1.py')
FULL=ROOT/'RH_Switch_Full_Source_2026-09-16_v1.json.gz'
PILOT=ROOT/'RH_Switch_Pilot_Source_2026-09-16_v1.json.gz'
class Checks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.full=b.load(FULL,b.FULL_HASH);cls.pilot=b.load(PILOT,b.PILOT_HASH)
        cls.primary=b.build(FULL,PILOT);cls.other=i.build(FULL,PILOT)
    def test_01_primary_full_replay(self):
        self.assertEqual(self.primary,b.load(ROOT/'RH_Switch_Results_2026-09-16_v1.json'))
    def test_02_independent_full_replay(self):
        self.assertEqual(self.other,b.load(ROOT/'RH_Switch_Independent_Results_2026-09-16_v1.json'))
    def test_03_both_covariances_negative(self):
        self.assertEqual(len(self.primary['windows']),2)
        for w in self.primary['windows']:self.assertLess(F(w['values']['selection_covariance'][1]),0)
    def test_04_both_decomposed_surpluses_positive(self):
        for w,limit in zip(self.primary['windows'],['1.019','0.972']):
            self.assertGreater(F(w['values']['separately_paid_surplus'][0]),F(limit))
    def test_05_independent_common_floors(self):
        for w,limit in zip(self.other['windows'],['1.019','0.972']):self.assertGreater(F(w['values']['separately_paid_surplus'][0]),F(limit))
    def test_06_covariance_overlap(self):
        for p,q in zip(self.primary['windows'],self.other['windows']):
            self.assertTrue(b.overlap(b.IV(*p['values']['selection_covariance']),b.IV(*q['values']['selection_covariance'])))
    def test_07_switch_counts(self):
        self.assertEqual([w['switch_count'] for w in self.primary['windows']],[21,14])
    def test_08_complete_cell_and_coefficient_collection(self):
        self.assertEqual(sum(w['cells'] for w in self.primary['windows']),2048)
        self.assertEqual(sum(w['coefficient_collection_checks'] for w in self.primary['windows']),8192)
    def test_09_unchanged_selector_roster(self):
        self.assertEqual([w['selector_counts'] for w in self.primary['windows']],
                         [{'2':449,'3':19,'4':16,'5':540},{'2':404,'3':14,'4':18,'5':588}])
    def test_10_loose_boundary_signs_unresolved(self):
        for w in self.primary['windows']:
            a=b.IV(*w['values']['naively_intervalized_boundary_sum']);self.assertLess(a.lo,0);self.assertGreater(a.hi,0)
    def test_11_switch_primitive_overlap(self):
        for w in self.primary['windows']:
            self.assertTrue(b.overlap(b.IV(*w['values']['selection_covariance']),b.IV(*w['values']['naively_intervalized_boundary_sum'])))
    def test_12_exact_identity_over_policies(self):
        weights=list(map(F,[1,2,3,4]));values=[{j:F((2*k+1)*(j-3)+(-1)**k) for j in b.UPPER} for k in range(4)]
        for p in itertools.product((2,3,5),repeat=4):b.exact_discrete_control(weights,values,list(p))
    def test_13_no_switch(self):
        v=[{j:F(k+j) for j in b.UPPER} for k in range(4)]
        self.assertEqual(b.exact_discrete_control([F(1)]*4,v,[2]*4),0)
    def test_14_common_component_invariance(self):
        w=[F(1),F(3),F(2)];p=[2,4,5]
        v=[{j:F((k+1)*j*(-1)**j) for j in b.UPPER} for k in range(3)]
        v2=[{j:q[j]+F((k+1)*100) for j in b.UPPER} for k,q in enumerate(v)]
        self.assertEqual(b.exact_discrete_control(w,v,p),b.exact_discrete_control(w,v2,p))
    def test_15_zero_weight_cell(self):
        v=[{j:F(k*j) for j in b.UPPER} for k in range(3)]
        b.exact_discrete_control([F(1),F(0),F(1)],v,[2,5,4])
    def test_16_small_primitives_many_switches_control(self):
        for m in [1,2,4,8,16]:
            w=[F(1,2*m)]*(2*m);v=[];p=[]
            for k in range(2*m):
                a=F((-1)**k);v.append({2:a,3:-a,4:a,5:-a});p.append(3 if a>0 else 2)
            self.assertEqual(b.exact_discrete_control(w,v,p),-1)
            running=F();peak=F()
            for a,z in zip(w,v):running+=a*z[2];peak=max(peak,abs(running))
            self.assertEqual(peak,F(1,2*m))
    def test_17_sign_of_switch_identity(self):
        v=[{2:F(1),3:F(-1),4:F(1),5:F(-1)},{2:F(-1),3:F(1),4:F(-1),5:F(1)}]
        self.assertEqual(b.exact_discrete_control([F(1),F(1)],v,[3,2]),-1)
    def test_18_invalid_switch_roster(self):
        with self.assertRaises(ValueError):b.collected_switch_coefficients([2,3,5],[(1,2,3)])
    def test_19_ties_are_index_ordered(self):self.assertEqual(b.select([b.IV(0)]*4),2)
    def test_20_positive_weight_mass_required(self):
        with self.assertRaises(ValueError):b.exact_discrete_control([F(0)],[{j:F(1) for j in b.UPPER}],[2])
    def changed_full(self,change):
        f=copy.deepcopy(self.full);change(f)
        with self.assertRaises(ValueError):b.validate(f,self.pilot)
    def test_21_missing_window_rejected(self):self.changed_full(lambda f:f['windows'].pop())
    def test_22_missing_cell_rejected(self):self.changed_full(lambda f:f['windows'][0]['cells'].pop())
    def test_23_moved_cell_rejected(self):self.changed_full(lambda f:f['windows'][0]['cells'][5]['r'].__setitem__(0,'1/2'))
    def test_24_scale_tamper_rejected(self):self.changed_full(lambda f:f['scales'].__setitem__(2,'1'))
    def test_25_payment_tamper_rejected(self):self.changed_full(lambda f:f.__setitem__('source_payment','0'))
    def test_26_coefficient_omission_rejected(self):self.changed_full(lambda f:f['windows'][1]['cells'][0]['V'].pop())
    def test_27_invalid_weight_rejected(self):self.changed_full(lambda f:f['windows'][0]['cells'][0].__setitem__('W',['-1','2']))
    def test_28_wrong_pilot_contract(self):
        for key,val in [('K',9),('upper_indices',[2,3,5]),('input_sha256','bad'),('whole_cell_evaluation',False)]:
            p=copy.deepcopy(self.pilot);p[key]=val
            with self.assertRaises(ValueError):b.validate(self.full,p)
    def test_29_hash_and_overwrite_guards(self):
        with tempfile.TemporaryDirectory() as td:
            q=Path(td)/'a.json';b.save(q,{'a':1})
            with self.assertRaises(FileExistsError):b.save(q,{})
            with self.assertRaises(ValueError):b.load(q,b.FULL_HASH)
    def test_30_interval_operation_controls(self):
        for a in range(-3,3):
            for c in range(-3,3):
                x=b.IV(a,a+2);y=b.IV(c,c+2);z=x*y
                for xx in (F(a),F(a+1),F(a+2)):
                    for yy in (F(c),F(c+1),F(c+2)):self.assertLessEqual(z.lo,xx*yy);self.assertGreaterEqual(z.hi,xx*yy)
        with self.assertRaises(ValueError):b.IV(1)/b.IV(-1,1)
    def test_31_analytic_exponent_control(self):
        beta=F(7,10);p=6
        self.assertEqual(p*(F(1,2)-beta)+F(1,2),-F(7,10))
        self.assertEqual(F(2,3)-beta,-F(1,30))
        self.assertEqual(p*(1-beta),F(9,5))
        self.assertEqual(p*(F(3,2)-beta),F(24,5))
    def test_32_inputs_and_implementation_scope(self):
        self.assertEqual(hashlib.sha256(FULL.read_bytes()).hexdigest(),b.FULL_HASH)
        self.assertEqual(hashlib.sha256(PILOT.read_bytes()).hexdigest(),b.PILOT_HASH)
        text=(ROOT/'RH_Switch_Independent_2026-09-16_v1.py').read_text()
        self.assertNotIn('import switch_builder',text);self.assertNotIn('RH_Switch_Builder',text)
        self.assertFalse(self.primary['unbounded_selected_sign_proved'])
        self.assertEqual(self.primary['new_source_evaluations'],0)
if __name__=='__main__':unittest.main(verbosity=2)
