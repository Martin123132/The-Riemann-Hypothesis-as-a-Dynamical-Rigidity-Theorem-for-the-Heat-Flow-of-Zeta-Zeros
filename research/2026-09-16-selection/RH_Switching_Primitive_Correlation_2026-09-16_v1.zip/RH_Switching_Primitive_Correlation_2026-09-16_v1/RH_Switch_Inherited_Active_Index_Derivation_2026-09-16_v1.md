# Active-index correlations and gap-localized selection regret

**16 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Result and precise scope

The preceding central-energy package establishes ordinary signed correlations
with a growing upper coefficient block. It explicitly does not infer a positive
mean of the gated minimum from those correlations. This continuation tests the
missing index selection directly, with all source and error conventions fixed.

On each of the original 2,048 complete N=64 cells, a deterministic rule uses
ONLY the four eight-term upper-coefficient enclosures to choose an index. It
chooses their smallest interval midpoint, ties to the smaller index. The FULL
upper coefficients are not used in this choice. The selected full coefficient
is then evaluated, the unshortened lower block is retained, and any loss from
choosing the wrong upper coefficient is paid.

Both original windows pass. The gap-and-tail allowance by itself gives restored
normalized surplus floors **1.0666** and **1.0352**. A separately labelled finite
calibration using the complete source boxes gives sharper selection-regret
bounds, with restored floors **1.0845** and **1.0523** in both implementations.
These are enclosures of the SAME historical finite surplus, not new heights,
new function values, or larger zero-free regions.

There is a genuine adverse-selection example in the actual data. In the first
window the ordinary moment for coefficient 4 is positive, greater than 1.27.
But its signed contribution restricted to cells where the short-sum rule selects
that index is strictly negative, below -0.000076. This is a restriction of the
same source quantity at the same heights, not a random-phase countermodel.

The new analytic statements are a sharp, gap-localized regret bound and an exact
correlation decomposition which permits the parent's uniform signed theorem to
enter a joint selection criterion. They do not prove the outstanding unbounded
sign inequality. No effective cutoff or new historical-pin audit is supplied.

## 2. Unchanged source, gate, and coefficient blocks

Use the definitions of the authenticated parent derivation, copied unchanged
under `RH_Active_Index_Parent_Derivation_2026-09-16_v1.md`:

    d=ceil(log(N+1)), J=floor((N/64)^(1/3)), M=N-J-1,
    a=N+r, t=2*pi*a^2, epsilon=(-1)^(N+nu),
    W=(1+epsilon*cos(theta0(t)))^2, nu=0,1.

The two original r-windows have centres 1/4 and 3/4 and halfwidth
1/[100(J+1)]. All averages below use the SAME probability measure

    <f>_W = integral W*f dr / integral W dr.

Retain the exact coefficient kernels, scales, and complete error shift:

    B_(d,j)(z)=sum_(k<=j) [binom(j,k)/binom(d,k)] z^(2k)/(4^k(2k)!),
    s_j=B_(d,j)(d), Z_j=(beta_j+c_N)/s_j,
    c_N=H_J-E_N,
    H_J=(2/3)(J+1)-503/1000,
    E_N=(e^2/9)N^(-(log16-5/2))+(log N+2)/(4*pi*N),
    X=Z_0/sqrt(N), P=X_+, V_j=(2s_d/N)Z_j.

The exact surplus is S_N=<P min_j V_j>_W. Positive surplus gives the inherited
sufficient full-width coefficient-sign selection statement. It does not supply
winding or an absolute zero census.

Let A_N={ceil(d/4),...,d} be the upper index block. The other indices form the
lower block. Set

    U=min_(j in A_N) V_j, L=min_(j not in A_N) V_j.

For j in A_N, let Vhat_j be the SAME arithmetic coefficient truncated to its
first K terms, keeping its scale and deterministic source shift. Lower
coefficients and the central gate are not truncated. For the finite test:

    N=64, d=5, K=8, A_N={2,3,4,5}, lower={0,1},
    complete declared error payment=0.271900134725.

No normalization is fitted or retuned in this stage.

## 3. A selector is not a fixed-coefficient average

Let iota(r) be a measurable choice of an upper index, determined by the
shortened vector. Define I_j(r)=1_{iota(r)=j} and p_j=<I_j>_W. Each occurrence
uses the same r. Then

    C_j=<X V_j>_W,
    C_sel=<X V_iota>_W=sum_j <I_j X V_j>_W.

In general C_sel is NOT sum_j p_j*C_j. The exact missing correction is

    Gamma_sel=sum_j [<I_j X V_j>_W-p_j<X V_j>_W].          (1)

Thus

    C_sel=B_mix+Gamma_sel, B_mix=sum_j p_j C_j.           (2)

The parent's signed theorem is uniform over j/d>=1/4 on N_m=floor(exp(m)):

    C_j=Psi(s(j/d))+o(1), Psi(s)>=c_*>0,
    c_*=cos(pi/8)[zeta(3/2)/2+1/12].

Because p_j>=0 and sum_j p_j=1, it DOES imply

    B_mix>=c_*+o(1),                                    (3)

even when the selector and its probabilities depend on N. Uniformity in j is
what justifies that implication. It does not determine Gamma_sel, or a gated
selected moment. No fixed-Fourier limit is applied to the changing indicators.

The gate correction is also retained exactly:

    D_gate=<(-X)_+ V_iota>_W,
    <P V_iota>_W=C_sel+D_gate.                           (4)

Neither Gamma_sel nor D_gate is nonnegative by definition.

## 4. The exact lower-block and selection-regret decomposition

The selected full upper value is V_iota. Define

    T=min(L,V_iota),
    r_sel=T-min(L,U)>=0.

The lower block can make an upper-index error irrelevant: if L<=U, then
r_sel=0 irrespective of which upper coefficient was chosen. Pointwise,

    r_sel=max(0,min(L,V_iota)-U)
         =max(0,max_(j in A_N, j!=iota) min(L-V_j,V_iota-V_j)). (5)

The term j=iota is nonpositive and may be omitted, not charged a spurious
independent interval width. Also r_sel<=V_iota-U.

Set

    B_low=<P(V_iota-L)_+>_W, T_sel=<P r_sel>_W.

The SAME full surplus has the exact identity

    S_N=<P V_iota>_W-B_low-T_sel
       =B_mix+Gamma_sel+D_gate-B_low-T_sel.              (6)

Every term in (6) is evaluated on the original windows. This is not a new
weight or a new sufficient polynomial. It identifies the source-dependent
correlations that replacing a fixed index by a minimum introduces.

## 5. Sharp gap-localized regret

Define actual truncation errors, not their separately adversarial replacements,

    e_j=V_j-Vhat_j,
    Omega=max_j e_j-min_j e_j>=0,
    g_j=Vhat_j-Vhat_iota, g=min_(j!=iota) g_j.

Then exactly

    V_iota-U=max(0,max_(j!=iota)[e_iota-e_j-g_j]).         (7)

Consequently, for ANY index choice, including an approximate pilot choice,

    0<=r_sel<=V_iota-U<=(Omega-g)_+.                     (8)

Here g is signed when the pilot choice is only approximate. The finite
cell-constant selector below does not assume g>=0. It pays negative lower
bounds for g as well as the source tail intervals.

For the exact shortened argmin (lowest-index tie convention), g>=0. If its
pilot gap exceeds the oscillation of the omitted terms, the chosen upper
index is still a minimizer of the full upper source. In particular:

    Omega<=g  =>  r_sel=0,
    r_sel<=Omega*1_{g<Omega}.                            (9)

The oscillation, not the absolute size of the tails, matters here. Adding
one common real number to EVERY e_j leaves Omega and the upper-index regret
unchanged. It can change which lower block dominates; we do NOT claim that
the complete source value or lower-block interaction is invariant. The full
selected coefficient in (6) retains that common contribution.

For g>0, completing a square gives

    (Omega-g)_+ <= Omega^2/(4g),                         (10)

because Omega^2-4g(Omega-g)=(Omega-2g)^2. The constant 1/4 is sharp. For
example pilot values (0,g), errors (g,-g), and selection of the first index
have Omega=2g and actual upper regret g. The quadratic bound is not applied
through g=0 or to a negative pilot gap.

Thus the potential error is concentrated where competing pilot coefficients
are close enough for the omitted terms to reverse their ordering. This gap
is a difference of COEFFICIENT VALUES, not a gap between zero heights.

A direct consequence, with the exact shortened argmin, is

    T_sel <= <P Omega 1_{g<Omega}>_W
           <= ||P 1_{g<Omega}||_2 ||Omega||_2.            (11)

This uses the gate energy ON the possible-switch set, rather than assuming
all heights can switch. Its source-specific smallness has not been proved
at unbounded cutoffs. The exact gap statement remains valid without it.

## 6. All-height transport for the adaptive index (conditional on the parent)

For the exact shortened argmin, Omega<=2 max_j|e_j|. The parent proves

    ||X||_2=O(sqrt(log N)),
    ||e_j||_2<=C[K^(1/2-beta)+N^(2/3-beta)*sqrt(log N)]

uniformly on an upper block with lambda_0>5/27 and admissible beta. Since the
block has O(log N) indices, (8)-(11) give

    T_sel <= 2||X||_2 [sum_(j in A_N)||e_j||_2^2]^(1/2)
            =O(K^(1/2-beta)*log N
                  +N^(2/3-beta)*(log N)^(3/2)).           (12)

For lambda_0=1/4, beta=7/10 and K=floor(sqrt N), this is

    O(N^(-1/10)*log N+N^(-1/30)*(log N)^(3/2))=o(1).      (13)

The rate is INHERITED from the block-tail and central-energy estimates; this
stage does not improve its exponent or provide a numerical starting cutoff.
The new consequence is that an adaptively selected FULL coefficient can be
used in (6), with the cost of possibly choosing the wrong index paid by (13).
The lower block remains unchanged.

For an approximate selector with pilot excess eta=Vhat_iota-min_j Vhat_j,
add <P eta>_W to the elementary 2-max-tail bound. A fixed finite grid is not
claimed to control that term uniformly as N grows. The finite execution
instead checks its signed gaps directly on EVERY closed source cell.

Combining (3), (6), and (13), one sufficient source-specific next target is

    limsup_m max_nu [B_low-Gamma_sel-D_gate] < c_*.        (14)

This is an alternative joint-selection target, NOT a larger numerical
allowance for the earlier quantity R-Q. The terms have changed by exact
accounting; their thresholds must not be compared as improvement factors.
Equation (14) is unproved. In particular, signs of the fixed C_j do not
bound Gamma_sel or D_gate. The existing R-Q<0.5172 route and the winding,
multiplicity, initial-count, and full absolute-count obligations remain.

## 7. Finite execution, including wrong choices and adverse masks

Each original cell carries complete intervals for W, X, every FULL V_j, and
four eight-term Vhat_j. The new rule chooses the smallest midpoint among the
four Vhat intervals and breaks ties by index. A midpoint chooses a policy;
it is NOT declared the value of the source or a certificate of its minimum.
The same chosen index is used across that cell. At shared faces choose either
neighbouring policy; the faces have zero integration measure and both closed
source enclosures remain valid. No derivative of the discontinuous policy
or of a minimum is taken.

The selected-index rosters are:

| Window | index 2 | index 3 | index 4 | index 5 |
| --- | ---: | ---: | ---: | ---: |
| First | 449 | 19 | 16 | 540 |
| Second | 404 | 14 | 18 | 588 |

In 97 first-window and 25 second-window cells, X is strictly positive AND a
full upper competitor is strictly smaller than the chosen upper coefficient.
Those mistakes are not suppressed. The lower block sometimes screens their
impact; the effective regret in (5) is what enters the source surplus.

The pilot minimum itself is proved throughout 622 and 535 cells, respectively.
It is not assumed on the other cells. Full-source upper minimality of the
chosen index is separately certified on 618 and 663 cells. None of these counts
is used as an estimate of a physical-height probability.

### Positive selected aggregate, with its gate correction retained

| Quantity, original W expectation | First window | Second window |
| --- | --- | --- |
| selected ordinary product C_sel | [1.14669894,1.25182129] | [1.22662351,1.34519735] |
| negative-central correction D_gate | [-0.06194631,-0.04781873] | [-0.19883639,-0.16791772] |
| selected gated contribution | [1.09888021,1.18987499] | [1.05870579,1.14636096] |
| loss to the unchanged lower block | [0.01223306,0.01683723] | [0.00404766,0.00813186] |

Displayed endpoints are rounded outward. Rational records govern acceptance.
The selected ordinary product is NOT reconstructed by multiplying unconditional
correlations by selection frequencies. The exact selection covariance is
calculated separately. Its enclosure is strictly negative in the first window;
the second enclosure crosses zero and no sign is assigned to it.

The actual first-window data give

    <X V_4>_W > 1.2771,
    <1_{iota=4} X V_4>_W in [-0.000316120,-0.000076460].

The selected gated contribution for index 4 is also negative, with an upper
bound below -0.0000539. These quantities are original-W contributions of a
subset, NOT a conditional expectation divided by its subset probability. The
index is kept in the total even though its contribution is adverse.

### Gap-derived acceptance and full-source regret calibration

Let intervals enclose e_j, g_j on a complete cell. The certified index-regret
upper bound is the smaller of the valid bounds

    max(0,max_(j!=iota)(e_iota.upper-e_j.lower-g_j.lower)),
    max(0,2*max_j sup|e_j|-g.lower),
    max(0,max_j e_j.upper-min_j e_j.lower-g.lower).

This pays the possibly negative pilot gap. It requires no exact identification
of a minimum from point samples. Applied to the selected full coefficient and
unchanged lower block, the gap-only restored scores exceed 1.0666 and 1.0352.

The separate full-vector calibration evaluates (5) directly with the complete
source enclosures, excluding the exactly zero self-difference. It supplies:

| Quantity | First window | Second window |
| --- | --- | --- |
| primary effective selection-regret upper | 0.000472857 | 0.000778639 |
| independent effective regret upper | 0.000472857 | 0.000784016 |
| restored surplus, both implementations | >1.0845 | >1.0523 |

The independent second-window regret is slightly wider; it does not reproduce
the tighter primary endpoint. Both implementations confirm the same sign and
reported common floors. Every approximation/source error is inherited inside
the complete cell images. Neither calculation uses an asymptotic constant as
a finite error allowance.

The tighter calibration reads all full coefficients to bound the regret. The
gap-only calculation also reads full-minus-short tail enclosures and the full
selected coefficient. This is a finite test of the reduction, NOT a proof
using only eight Dirichlet terms. No input is selected or narrowed by whether
its final surplus succeeds.

## 8. Verification, limitations, and next action

The primary builder is new standard-library Fraction code. A separate builder
uses tuple/Fraction operations, independently rechecks all source geometry,
scales, payment, policy decisions, block integrals, and finite regret. It
imports neither the primary interval module nor its acceptance functions.
It uses different equivalent regret enclosures. The numerical source inputs
and analytic source hypotheses are shared; there is no independent fresh
special-function implementation in this stage.

All 36 named tests pass. They include 3,375 exact pilot/error vector cases,
625 complete block-identity cases, sharp-gap equality, ties, negative pilot
gaps, common-tail invariance, conditional-correlation counter-controls,
nonvacuous coverage, tampering guards, and complete rebuilds of both outputs.
Those finite controls supplement the written lemmas, not a formal verification
of the parent's analytic asymptotics or the new unbounded sign target.

An initial replay comparison exposed only integer dictionary keys becoming
strings in JSON. The functions now construct canonical string keys directly;
serialized result bytes did not change. The initial failed test log is retained.
The first exploratory accounting export is retained outside the sealed delivery
and its hash is recorded in the development note. No historical file changed.

The next arithmetic task is to control the selection covariance and gate
correction jointly with the lower-block loss in (14), or the existing
endpoint-relative R-Q formulation. A gap-distribution bound can sharpen the
vanishing regret payment, but does not by itself supply that signed comparison.
The tested negative selected contribution is a concrete reason not to demand
positivity of every selected summand separately.

No new source evaluation, numerical Gamma/zeta/auxiliary call, remote process,
laptop write, desktop modification, repository update, bookmark edit, or
historical-pin audit was performed. Only new uniquely named container files
were made. This stage establishes no new zero count or certified region.

## References and preserved dependencies

1. Authenticated `RH_Central_Energy_Joint_Spectrum_2026-09-15_v1.zip`, 19
   manifest members. Its complete derivation was read and is included unchanged.
   Its Sections 6–7 supply the quantitative growing-block tail estimate and the
   uniform signed bilinear limit used conditionally in Sections 3 and 6 here.
2. Its complete source-cell input, SHA-256
   `f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161`.
3. Its 80-digit complete eight-term coefficient enclosures, SHA-256
   `5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4`.
   These primitives were copied byte-for-byte. Their source calculations and
   earlier test suites were not rerun in this continuation.

The minimum, covariance, and gap lemmas are proved directly above. They are
ordinary finite-dimensional inequalities, not claimed as novel general tools.
All private-source rights and third-party attribution are retained. No
publication or general reuse permission is granted by this delivery.
