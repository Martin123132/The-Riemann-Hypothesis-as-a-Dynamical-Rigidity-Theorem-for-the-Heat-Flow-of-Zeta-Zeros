"""Signed switch-boundary correlation on authenticated complete source cells.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
Standard-library, exact rational interval acceptance; no source oracle.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
from dataclasses import dataclass
from fractions import Fraction as F
from math import comb, factorial
from pathlib import Path
from typing import Any, Iterable

FULL_HASH = 'f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
PILOT_HASH = '5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4'
UPPER = (2, 3, 4, 5)
REFERENCE = 5

@dataclass(frozen=True, init=False)
class IV:
    lo: F
    hi: F
    def __init__(self, lo=0, hi=None):
        if isinstance(lo, IV):
            a, b = lo.lo, lo.hi
        else:
            a, b = F(lo), F(lo if hi is None else hi)
        if a > b:
            raise ValueError('reversed interval')
        object.__setattr__(self, 'lo', a)
        object.__setattr__(self, 'hi', b)
    def __add__(self, other):
        z = IV(other); return IV(self.lo + z.lo, self.hi + z.hi)
    __radd__ = __add__
    def __neg__(self): return IV(-self.hi, -self.lo)
    def __sub__(self, other): return self + (-IV(other))
    def __rsub__(self, other): return IV(other) - self
    def __mul__(self, other):
        z = IV(other)
        p = (self.lo*z.lo, self.lo*z.hi, self.hi*z.lo, self.hi*z.hi)
        return IV(min(p), max(p))
    __rmul__ = __mul__
    def __truediv__(self, other):
        z = IV(other)
        if z.lo <= 0 <= z.hi: raise ValueError('denominator contains zero')
        return self * IV(1/z.hi, 1/z.lo)
    def pos(self): return IV(max(F(0), self.lo), max(F(0), self.hi))
    def abs(self):
        return IV(0 if self.lo <= 0 <= self.hi else min(abs(self.lo), abs(self.hi)),
                  max(abs(self.lo), abs(self.hi)))
    def mid(self): return (self.lo + self.hi)/2
    def dump(self): return [str(self.lo), str(self.hi)]
    def display(self): return [float(self.lo), float(self.hi)]

def imin(values: Iterable[IV]) -> IV:
    v = list(values)
    if not v: raise ValueError('empty minimum')
    return IV(min(z.lo for z in v), min(z.hi for z in v))

def imax(values: Iterable[IV]) -> IV:
    v = list(values)
    if not v: raise ValueError('empty maximum')
    return IV(max(z.lo for z in v), max(z.hi for z in v))

def isum(values: Iterable[IV]) -> IV: return sum(values, IV())

def overlap(x: IV, y: IV) -> bool: return max(x.lo,y.lo) <= min(x.hi,y.hi)

def load(path: str | Path, expected: str | None = None) -> Any:
    b = Path(path).read_bytes()
    if expected and hashlib.sha256(b).hexdigest() != expected:
        raise ValueError('input hash mismatch')
    return json.loads(gzip.decompress(b) if str(path).endswith('.gz') else b)

def save(path: str | Path, obj: Any) -> None:
    p = Path(path)
    if p.exists(): raise FileExistsError(p)
    b = (json.dumps(obj, sort_keys=True, indent=2) + '\n').encode()
    p.write_bytes(gzip.compress(b, mtime=0) if str(p).endswith('.gz') else b)

def scale_roster():
    return [sum((F(comb(j,k), comb(5,k))*F(5**(2*k), 4**k*factorial(2*k))
                 for k in range(j+1)), F()) for j in range(6)]

def select(short: list[IV]) -> int:
    if len(short) != 4: raise ValueError('four pilot coefficients required')
    return min(range(4), key=lambda j: (short[j].mid(), j)) + 2

def validate(full: dict, pilot: dict) -> None:
    if (full.get('N'), full.get('degree')) != (64,5): raise ValueError('source N/degree')
    if list(map(F,full['scales'])) != scale_roster(): raise ValueError('scales')
    if F(full['source_payment']) != F('0.271900134725'): raise ValueError('payment')
    if (pilot.get('N'),pilot.get('d'),pilot.get('K')) != (64,5,8): raise ValueError('pilot N/degree/K')
    if pilot['upper_indices'] != list(UPPER): raise ValueError('upper indices')
    if pilot['input_sha256'] != FULL_HASH or pilot['whole_cell_evaluation'] is not True:
        raise ValueError('pilot source binding')
    if [w['nu'] for w in full['windows']] != [0,1] or [w['nu'] for w in pilot['windows']] != [0,1]:
        raise ValueError('window roster')
    for nu,(fw,pw) in enumerate(zip(full['windows'],pilot['windows'])):
        ends = [F(49+100*nu,200), F(51+100*nu,200)]
        if list(map(F,fw['r'])) != ends: raise ValueError('window endpoints')
        if len(fw['cells']) != 1024 or len(pw['cells']) != 1024: raise ValueError('cell count')
        for k,(c,h) in enumerate(zip(fw['cells'],pw['cells'])):
            r = [ends[0]+F(k,102400), ends[0]+F(k+1,102400)]
            if c['i'] != k or h['i'] != k or list(map(F,c['r'])) != r or list(map(F,h['r'])) != r:
                raise ValueError('cell order or gap')
            if len(c['V']) != 6 or len(h['Vshort']) != 4: raise ValueError('coefficient roster')
            w=IV(*c['W']);IV(*c['X'])
            if w.lo<0 or w.hi>4: raise ValueError('weight range')
            for v in c['V']+h['Vshort']: IV(*v)

def switches(policy: list[int]) -> list[tuple[int,int,int]]:
    if not policy or any(j not in UPPER for j in policy): raise ValueError('invalid policy')
    return [(k,policy[k-1],policy[k]) for k in range(1,len(policy)) if policy[k]!=policy[k-1]]

def collected_switch_coefficients(policy: list[int], switch_list=None):
    """For cell k, sum the jumps strictly after that cell, without intervalizing.
    The identity is c[k,j]=1_{policy[k]=j}-1_{policy[-1]=j}.
    """
    sw=switches(policy) if switch_list is None else switch_list
    if sw != switches(policy): raise ValueError('switch roster inconsistent with policy')
    state={j:0 for j in UPPER}; by_boundary={k:(i,j) for k,i,j in sw}
    out=[None]*len(policy)
    for k in range(len(policy)-1,-1,-1):
        if k+1 in by_boundary:
            i,j=by_boundary[k+1];state[i]+=1;state[j]-=1
        out[k]=dict(state)
        for j in UPPER:
            if state[j] != int(policy[k]==j)-int(policy[-1]==j):
                raise ArithmeticError('summation-by-parts coefficient identity')
    return out

def exact_discrete_control(weights, values, policy):
    """Pure algebra on exact arrays, not source values assumed constant in a cell."""
    D=sum(weights,F())
    if D<=0: raise ValueError('nonpositive mass')
    mu={j:sum((w*v[j] for w,v in zip(weights,values)),F())/D for j in UPPER}
    p={j:sum((w for w,a in zip(weights,policy) if a==j),F())/D for j in UPPER}
    gamma=sum((w*v[a] for w,v,a in zip(weights,values,policy)),F())/D-sum((p[j]*mu[j] for j in UPPER),F())
    pref={j:F() for j in UPPER}; mass=F(); bdy=F(); sw={k:(i,j) for k,i,j in switches(policy)}
    for k,(w,v) in enumerate(zip(weights,values)):
        if k in sw:
            i,j=sw[k];bdy+=(pref[i]-pref[j]-mass*(mu[i]-mu[j]))/D
        mass+=w
        for j in UPPER:pref[j]+=w*v[j]
    paired=sum((weights[k]*weights[l]*(values[k][policy[k]]-values[k][policy[l]])
                for k in range(len(weights)) for l in range(len(weights))),F())/D**2
    if gamma!=bdy or gamma!=paired: raise ArithmeticError('discrete covariance identity')
    return gamma

def one_window(fw,pw):
    cells=fw['cells']; n=len(cells)
    W=[IV(*c['W']) for c in cells]; X=[IV(*c['X']) for c in cells]
    V=[[IV(*v) for v in c['V']] for c in cells]
    policy=[select([IV(*v) for v in h['Vshort']]) for h in pw['cells']]
    sw=switches(policy); coeff=collected_switch_coefficients(policy,sw)
    den=isum(W)
    if den.lo<=0: raise ValueError('positive weight mass required')
    probs={j:isum(w for w,a in zip(W,policy) if a==j)/den for j in UPPER}
    # Common reference removed before enclosure. Its self-difference is EXACT zero.
    f=[{j:w*x*(v[j]-v[REFERENCE]) if j!=REFERENCE else IV() for j in UPPER}
       for w,x,v in zip(W,X,V)]
    means={j:isum(row[j] for row in f)/den for j in UPPER}
    # Since mean(c_j)=p_j-1_{last=j}, retain the exact unit-mass cancellation.
    coeff_means={j:probs[j]-int(policy[-1]==j) for j in UPPER}
    gamma=isum((cr[j]-coeff_means[j])*fr[j]
               for cr,fr in zip(coeff,f) for j in UPPER if j!=REFERENCE)/den
    # Direct-reference form is retained as a weaker independent algebraic arrangement.
    gamma_ref=isum(row[a] for row,a in zip(f,policy))/den-isum(probs[j]*means[j] for j in UPPER)
    if not overlap(gamma,gamma_ref): raise ArithmeticError('covariance arrangements disagree')
    Cref=isum(w*x*v[REFERENCE] for w,x,v in zip(W,X,V))/den
    mixture=Cref+isum(probs[j]*means[j] for j in UPPER if j!=REFERENCE)
    dg=isum(w*(-x).pos()*v[a] for w,x,v,a in zip(W,X,V,policy))/den
    low=isum(w*x.pos()*(v[a]-imin(v[:2])).pos() for w,x,v,a in zip(W,X,V,policy))/den
    rr=[];direct=[]
    for w,x,v,a in zip(W,X,V,policy):
        L=imin(v[:2]);reg=imax([IV()]+[imin([L-v[j],v[a]-v[j]]) for j in UPPER if j!=a]).pos()
        rr.append(w*x.pos()*reg); direct.append(w*x.pos()*imin(v))
    regret=isum(rr)/den
    decomposed=mixture+gamma+dg-low-regret
    # Deliberately retain the loose result from intervalizing each prefix independently.
    prefix=[{j:IV() for j in UPPER}]; wm=[IV()]
    for w,row in zip(W,f):
        wm.append(wm[-1]+w);prefix.append({j:prefix[-1][j]+row[j] for j in UPPER})
    terms=[]
    for k,i,j in sw:
        term=(prefix[k][i]-prefix[k][j])/den-(wm[k]/den)*(means[i]-means[j])
        terms.append({'boundary_cell':k,'r':cells[k]['r'][0],'from':i,'to':j,
                      'primitive_jump_interval':term.dump()})
    naive=isum(IV(*z['primitive_jump_interval']) for z in terms)
    abs_cost=isum(IV(*z['primitive_jump_interval']).abs() for z in terms)
    if not overlap(gamma,naive): raise ArithmeticError('boundary and collected covariance disagree')
    # Point array identity: algebraic control only, distinct from whole-cell source proof.
    midsW=[w.mid() for w in W]
    midsF=[{j:x.mid()*v[j].mid() for j in UPPER} for x,v in zip(X,V)]
    # Efficient exact boundary identity (avoid the O(n^2) auxiliary check at n=1024).
    md=sum(midsW,F()); mp={j:sum((w for w,a in zip(midsW,policy) if a==j),F())/md for j in UPPER}
    mm={j:sum((w*f[j] for w,f in zip(midsW,midsF)),F())/md for j in UPPER}
    mg=sum((w*f[a] for w,f,a in zip(midsW,midsF,policy)),F())/md-sum((mp[j]*mm[j] for j in UPPER),F())
    mcw=[F()];mcf=[{j:F() for j in UPPER}]
    for w,row in zip(midsW,midsF):
        mcw.append(mcw[-1]+w);mcf.append({j:mcf[-1][j]+w*row[j] for j in UPPER})
    mb=sum(((mcf[k][i]-mcf[k][j]-mcw[k]*(mm[i]-mm[j]))/md for k,i,j in sw),F())
    if mg!=mb:raise ArithmeticError('midpoint algebra identity')
    if not gamma.lo<=mg<=gamma.hi:raise ArithmeticError('control outside valid enclosure')
    results={'selection_covariance':gamma,'reference_subtraction_only':gamma_ref,
             'naively_intervalized_boundary_sum':naive,'absolute_boundary_cost':abs_cost,
             'fixed_index_mixture':mixture,'negative_central_gate_correction':dg,
             'lower_block_loss':low,'effective_selection_regret':regret,
             'separately_paid_surplus':decomposed,'direct_reference_surplus':isum(direct)/den,
             'weight_mean':den/n}
    return {'nu':fw['nu'],'r':fw['r'],'cells':n,'policy':policy,'switch_count':len(sw),
            'switches':terms,'reference_index':REFERENCE,'coefficient_collection_checks':4*n,
            'selector_counts':{str(j):policy.count(j) for j in UPPER},
            'probabilities':{str(j):probs[j].dump() for j in UPPER},
            'values':{k:v.dump() for k,v in results.items()},
            'display':{k:v.display() for k,v in results.items()},
            'exact_discrete_identity_verified':True,'midpoint_algebra_gamma':str(mg),
            'negative_covariance_certified':gamma.hi<0,'positive_paid_surplus':decomposed.lo>0}

def build(full_path,pilot_path):
    full=load(full_path,FULL_HASH);pilot=load(pilot_path,PILOT_HASH);validate(full,pilot)
    return {'stage':'signed switching primitives with collected coefficient differences',
            'date':'2026-09-16','N':64,'degree':5,'K':8,'upper_indices':list(UPPER),
            'lower_indices':[0,1],'new_source_evaluations':0,'unbounded_selected_sign_proved':False,
            'source_payment':full['source_payment'],'source_hashes':{'full':FULL_HASH,'pilot':PILOT_HASH},
            'windows':[one_window(fw,pw) for fw,pw in zip(full['windows'],pilot['windows'])]}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--pilot',required=True);p.add_argument('--output',required=True)
    a=p.parse_args(); save(a.output,build(a.full,a.pilot))
