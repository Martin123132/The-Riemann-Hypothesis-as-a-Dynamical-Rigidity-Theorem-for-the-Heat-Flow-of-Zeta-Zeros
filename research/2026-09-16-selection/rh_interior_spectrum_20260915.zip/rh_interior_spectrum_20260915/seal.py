"""Create a separate immutable-evidence package, never revise a predecessor."""
import json,shutil,zipfile
from pathlib import Path
from intake import HERE,sha,write

delivery=HERE/'delivery';delivery.mkdir()
package=delivery/'rh_interior_spectrum_20260915';package.mkdir()
for p in sorted(HERE.iterdir()):
    if p.is_file() and p.suffix in ['.py','.md','.json','.log'] and p.name!='BOOKMARK_BEFORE.json':
        shutil.copyfile(p,package/p.name)
for name in ['inputs','incoming','receipts']:
    shutil.copytree(HERE/name,package/name)
rows=[dict(path=p.relative_to(package).as_posix(),sha256=sha(p),bytes=p.stat().st_size)
      for p in sorted(package.rglob('*')) if p.is_file()]
write(package/'PACKAGE_MANIFEST.json',dict(kind='RH_gated_upper_block_transport',files=rows))
archive=delivery/(package.name+'.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(package.rglob('*')):
        if p.is_file():z.write(p,(Path(package.name)/p.relative_to(package)).as_posix())
receipt=dict(path=str(package),members=len(rows),seal=sha(package/'PACKAGE_MANIFEST.json'),
    archive_path=str(archive),archive_sha256=sha(archive),report_sha256=sha(package/'REPORT.md'),
    derivation_sha256=sha(package/'DERIVATION.md'),result_sha256=sha(package/'FINAL_RESULT.json'))
write(HERE/'SEAL_RECEIPT.json',receipt);print(json.dumps(receipt,indent=2))
