# Interior coefficient spectrum on the actual cutoff windows

15 September 2026. Private research for Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

## 1. What is and is not established

The endpoint-sign package is retained unchanged. Its 21-member manifest,
41 tests, eight symbolic identities and four output rebuilds were checked.
Its sufficient allowances 0.4363 and 0.5172 are NOT estimates for R-Q.
No material defect was found in its written fixed-support/L2 passage.

This continuation proves an interior extension of that passage. On the
declared sequence N_m=floor(exp(m)), put d=ceil(log(N_m+1))=m+1. Fix

    5/27 < lambda <= 1, j_m=floor(lambda*d).

There is a unique s in (1/6,1/2] satisfying

    lambda = s/2 + 4*s^2 - 2*s^3.                         (1)

Write sigma=1/2+s, delta=pi*s/4, g=exp(1/2-s). The actual coefficient
V_(j_m) has fixed-support L2 approximations with limiting arithmetic sum

    g Re[exp(i*chi+i*delta) sum_(n<=K) n^(-sigma-it)].     (2)

The order of limits is FIX K, then m->infinity, then K->infinity.
It supplies joint limits for any FIXED FINITE list of such coefficients,
including their one-sided second moments and pairwise covariances.

These moment limits do NOT justify a growing list, the minimum over all j,
or an interchange with X_+. Section 6 instead gives a separate QUANTITATIVE
gated truncation theorem for a growing upper block. Neither result proves
limsup(R-Q)<0.5172, unbounded surplus positivity, a zero count, or RH.
The cutoff 5/27 is a threshold of the explicit absolute ratio-sum bound
below, not a claimed natural barrier for the source.

## 2. Exact positive-coefficient representation

Retain the existing polynomial and normalization, without alteration:

    B_(d,j)(z)=sum_(k=0)^j binom(j,k)/binom(d,k)
                                *z^(2k)/(4^k*(2k)!),
    s_j=B_(d,j)(d).

Let

    w_k=binom(j,k)/binom(d,k)*d^(2k)/(4^k*(2k)!),
    p_k=w_k/s_j.

These are positive weights of total mass one. This is an algebraic
representation of a fixed polynomial, NOT a random model for source phases.

Exactly,

    B_(d,j)(d+z)/s_j = sum_k p_k*(1+z/d)^(2k),            (3)
    w_(k+1)/w_k = [(j-k)/(d-k)]
                          *d^2/[4(2k+1)(2k+2)].          (4)

For 0<lambda<=1, j/d->lambda, the ratio at k/d=x tends to

    r_lambda(x)=(lambda-x)/(16*x^2*(1-x)).

It is strictly decreasing on (0,lambda). The logarithmic derivative is
-1/(lambda-x)-2/x+1/(1-x)<0. Its unique crossing of one lies at x<=1/4
and satisfies 16*x^2*(1-x)=lambda-x. Thus s=2x satisfies (1).
The polynomial in (1) has derivative 1/2+8s-6s^2>0 on [0,1/2].

For every fixed eta>0, the mass outside |k/d-x|<eta tends to zero
exponentially in d. Here is an elementary justification. On any compact
subinterval strictly below x, consecutive ratios are bounded below by
1+c; above x they are bounded above by 1-c. Compare weights outside the
eta neighbourhood to weights an eta/2 distance closer to x, using at least
floor(eta*d/2) such ratios. Summing at most d+1 terms still gives
O(d*(1-c')^(eta*d/2)). The endpoint portions use the same monotone ratio.
This argument is uniform when lambda lies in a compact subinterval of
(0,1] and the crossing is uniformly separated from zero and lambda.

For bounded complex z,
(1+z/d)^(2k)=exp(2(k/d)z+O_z(1/d)), uniformly 0<=k<=d.
Equation (3), concentration and the uniform boundedness of these terms give

    B_(d,j)(d+z)/s_j -> exp(s*z)                         (5)

uniformly on compact complex sets. This is a written concentration proof,
not an extrapolation from the accompanying finite-degree evaluations.

## 3. A uniform envelope that pays the full Dirichlet tail

Termwise convergence (5) alone would NOT permit summation through M~N.
This section supplies the missing domination.

At a positive real argument q*d, replace d^2 in (4) by q^2*d^2.
For q in any compact positive interval, the same concentration proof is
uniform, now about x_lambda(q) satisfying

    16*x^2*(1-x)=q^2*(lambda-x).

Consequently

    B'(qd)/B(qd) -> 2*x_lambda(q)/q                       (6)

uniformly for q in [c,1], c>0. The right side is at least s for 0<q<=1.
Indeed x_lambda(q) increases with q and

    2*x_lambda(q)/q = (1/2)*sqrt((lambda-x)/(1-x));

the expression under the square root decreases with x when lambda<=1.

Choose 0<b<u<s, then choose c>0 so small that u*(1-c)>b.
For all sufficiently large d, (6) gives B'/B>=u throughout [cd,d].
Integration, followed by positivity of the polynomial on [0,cd], proves

    B(x)/B(d) <= exp(-b*(d-x)), 0<=x<=d.                 (7)

For x<cd, use B(x)<=B(cd)<=B(d)exp(-u*(1-c)d)
<=B(d)exp(-bd)<=B(d)exp(-b(d-x)). No estimate near x=0 is extrapolated
from a saddle point separated from zero.

Positive coefficients imply |B(z)|<=B(|z|). For each fixed C, (7) implies

    |B(x+iy)|/B(d) <= C_b,C exp(-b*(d-x)),
       0<=x<=d, |y|<=C.                                 (8)

To check the end near d, use B(d+C)/B(d)<=exp(2C), which follows termwise
from (3). Else |x+iy|<=x+C and apply (7). Cauchy's formula on a fixed
radius-one circle proves the same bound, with another constant, for B'.
Slightly negative real parts in that circle are harmless: their modulus
is at most x+C+1, the same positive-argument bound.

The constants and starting degree here are not computed effectively.
They can be uniform on compact lambda intervals inside (0,1].

## 4. Actual-window L2 transfer and the threshold 5/27

Use the SAME arithmetic expression as in the existing coefficient ledger:

    V_j=Re[exp(i*chi) sum_(n<=M) b_(n,N)(r)exp(-it log n)]
                                      +(2s_d/N)*c_N/s_j,
    b_(n,N)=(2s_d/N)*sqrt(a/n)
               *B_(d,j)(log(a/n)+i*pi/4)/s_j.            (9)

Here a=N+r, t=2*pi*a^2, M=N-J-1, the two windows and c_N are unchanged.
The deterministic shift is O(N^(-1/6)): c_N=O(N^(1/3)), s_j>=1,
and 2s_d/N=O(N^(-1/2)). It is paid before taking a limit.

For any 1/2<beta<sigma, put b=beta-1/2 in (8). Uniformly on the windows,

    |b_(n,N)| <= C*n^(-beta),
    |d b_(n,N)/dr| <= (C/N)*n^(-beta).                   (10)

Indeed 0<log(a/n)<d, d>log a, and (2s_d/N)*sqrt(a) stays bounded.
The derivative bound follows from (8) and d(log a)/dr=1/a.

Let ell be the r-window length; ell is comparable to N^(-1/3).
The unweighted squared mean of the tail n>K has diagonal bounded by
C sum_(n>K)n^(-2beta). Integration by parts for each off-diagonal pair,
with phase derivative 4*pi*a*log(n/m), and (10), gives its absolute cost

    C/(N*ell) sum_(m<n<=N) (mn)^(-beta)/log(n/m).

For beta<1, splitting m<n/2 and m>=n/2 and using
log(n/m)>=(n-m)/n bounds this by

    C*N^(4/3-2beta)*log N.                              (11)

For clarity, in the near range the sum is bounded by
C sum_n n^(1-2beta) sum_(h<=n/2)1/h; the far range is no larger.
This keeps EVERY ratio pair, rather than only diagonal terms.
The weight W is at most four and its mean tends to 3/2, so the same
bound, up to a fixed factor, holds in L2(W). The common exp(i*chi)
has modulus one; no stationarity involving chi is lost in this norm step.

If sigma>2/3 choose 2/3<beta<sigma. Then (11) tends to zero and

    limsup_N ||V_j - Re[exp(i*chi) sum_(n<=K)b_(n,N)
                                   exp(-it log n)]||_2^2
                      <= C*K^(1-2beta).                 (12)

By (1), sigma>2/3 is equivalent to lambda>5/27. This is the origin
of the threshold. No conclusion at or below it is asserted by this bound.

On N_m, d-log a->1, 2s_d/sqrt(N)->sqrt(e). For EACH FIXED n,
(5) yields

    b_(n,N) -> exp(1/2-s)*exp(i*pi*s/4)*n^(-1/2-s).

This convergence is uniform in r. Equations (12) and (5) prove (2) in
the claimed iterated, paid L2 sense, simultaneously for any fixed finite
list of lambda values. They do not bound the norm of a growing maximum.

## 5. Common-angle arithmetic limits and explicit interior moments

For fixed K, a nonconstant trigonometric monomial in chi and the prime
phases has phase h*theta0-t*log Q, Q fixed positive rational. Its derivative
is 4*pi*a*(h*log a-log Q), eventually separated from zero by cN
(or cN log N if h!=0). Integration by parts over the actual windows
therefore kills each fixed nonconstant character. The constant characters
retain integer factorization. Uniform trigonometric approximation on the
fixed compact torus proves the corresponding continuous-function limits.
This is an actual-height averaging theorem, not freely selected phases.

For sigma>1/2 define the arithmetic L2 limit

    B_sigma=sum_n n^(-sigma) q_n,

on the prime torus. Orthogonality and sum_n n^(-2sigma)<infinity justify
the limit. Finite-prime Euler products approximate it in L2 using exactly
the same smooth-integer argument as in the incoming endpoint proof.
No Euler product for a zeta value on the critical line is being assumed.

With H_sigma=E(|B_sigma| B_sigma), binomial expansion yields

    H_sigma=product_p sum_(k>=0)
               (2k+1)*binom(2k,k)^2/(16^k*p^(2sigma*k)).  (13)

It is real, positive and convergent for sigma>1/2. The map z->|z|z
has difference bounded by (|z|+|w|)|z-w|, so L2 convergence suffices.
The branch for each finite factor is the analytic branch at q=0;
all factors 1-q/p^sigma lie in the right half-plane.

Exact common-angle integration with W=(1+cos chi)^2 gives the new
actual-coefficient one-sided limits (lambda>5/27):

    Eplus(s)=g^2*[zeta(2sigma)/4 + cos(2delta)/24
                                +8*cos(delta)*H_sigma/(9*pi)],
    Eminus(s)=g^2*[zeta(2sigma)/4 + cos(2delta)/24
                                -8*cos(delta)*H_sigma/(9*pi)]. (14)

These are limits of <(V_j)_+^2> and <(-V_j)_+^2>, respectively.
They are not finite-N bounds. The inequality
|x_+^2-y_+^2|<=(|x|+|y|)|x-y| and (12) justify the final passage.

For two fixed positions s,t, the same argument gives the covariance

    M(s,t)=g_s*g_t*[cos(delta_s-delta_t)*zeta(sigma_s+sigma_t)/2
                                      +cos(delta_s+delta_t)/12]. (15)

Only equal Dirichlet indices survive the difference-angle harmonic;
only n=m=1 survives the sum-angle harmonic. This is the SAME prime
configuration at both positions. In particular the squared difference
from the endpoint has limit

    D(s)=M(s,s)+M(1/2,1/2)-2*M(s,1/2).                   (16)

For any s<1/2, this is strictly positive. The n=1 contribution alone is
the weighted square of Re[exp(i*chi)(g_s*exp(i*delta_s)-exp(i*pi/8))].
The complex coefficient is nonzero (its moduli differ), W is positive
except at one angle, and the resulting squared integral is positive.
The other arithmetic modes contribute nonnegative squared integrals.

Thus a fixed interior fraction does NOT converge to the endpoint in L2.
This invalidates the shortcut 'all interior coefficients collapse to Y'.
It does NOT prove positive interior defect Delta: a different coefficient
may still lie above min(V_0,Y), and endpoints must remain coupled.

## 6. Gated truncation of a growing upper coefficient block

The bounds in Section 4 are uniform over j/d in [lambda_0,1]. Choose

    lambda_0>29/54, 5/6<beta<1/2+s(lambda_0),
    K=floor(sqrt(N)), U_N={ceil(lambda_0*d),...,d}.

Define V_j^[K] by (9), retaining the EXACT same coefficients, normalizers,
height, phase and deterministic shift, but summing n only through K.
For j outside U_N, leave V_j unchanged. This is not a fixed-support or
Euler-product replacement: K grows and the exact polynomial kernels stay.

By (10)-(11), uniformly in j in U_N,

    ||V_j-V_j^[K]||_2
       <= C*[K^(1/2-beta)+N^(2/3-beta)*sqrt(log N)].

Since there are at most d+1=O(log N) indices, the pointwise bound
max_j |T_j| <= sqrt(sum_j |T_j|^2) gives an additional sqrt(log N).
The INHERITED fully paid central estimate is

    ||X||_2 = O(N^(1/6)*sqrt(log N)).

Cauchy--Schwarz, X_+<=|X| and K=floor(sqrt N) now prove

    <X_+ max_(j in U_N)|V_j-V_j^[K]|>_W
      <= C*[N^(5/12-beta/2)*log N
                         +N^(5/6-beta)*(log N)^(3/2)] = o(1). (17)

This controls a growing maximum and the untruncated central gate together.
It is a distinct estimate, not an application of the finite-coordinate
limit to a growing set. Its threshold is lambda(s=1/3)=29/54.

For a simple rational choice use lambda_0=3/5, beta=17/20. This is
permitted because lambda(s=7/20)=2317/4000<3/5. Then (17) becomes

    O(N^(-1/120)*log N + N^(-1/60)*(log N)^(3/2)).         (18)

The slow exponents and unspecified constant supply NO numerical onset.

Let Vhat equal V^[K] on U_N and V elsewhere. The scalar inequality

    |min_j V_j-min_j Vhat_j| <= max_(j in U_N)|V_j-Vhat_j|

and (17) imply

    <X_+ min_j V_j>_W = <X_+ min_j Vhat_j>_W + o(1).      (19)

Thus the upper 40 percent can be shortened INSIDE THE ORIGINAL SURPLUS,
not just in an isolated moment. The source remainder shift is unchanged.
This applies to both original windows for all sufficiently large N, not
only the degree-edge subsequence. The lower 60 percent, the full central
gate, and the signs of the surviving short sums remain in the expression.

## 7. Exactly what remains missing

The new results give nonlinear energy limits for fixed interior positions
and a paid transport for the full growing upper block. They do not bound
R=<X_+ Delta> or Q=<|X|Y>/2 by the required signed allowance.

Two unresolved passages must not be hidden:

1. j=0, or indices near it, correspond to sigma=1/2. The current bound
   (11) then grows. Fixed-support endpoint arguments cannot be copied
   to this central gate. The earlier central L2 bound is allowed to grow
   like N^(1/6)*sqrt(log N), and therefore multiplying an unquantified
   o(1) error by X_+ is not a justified vanishing-error argument.
2. Fixed-coordinate convergence alone does not license the maximum.
   Section 6 handles the upper block's removed tails, but not the signs
   of its remaining sqrt(N)-term sums or the lower-index block.

The next useful proof target is a signed joint estimate for the shortened
upper block and the unchanged lower block under the same central gate,
or a direct estimate of R-Q below 0.5172 on the declared subsequence.
In particular a square norm by itself still does not establish that sign.
More accurate endpoint moments
alone cannot supply it. None of the interval constants below is used
as a substitute for that missing comparison.

## 8. Numerical scope and references

The computation uses interval arithmetic for positive real zeta constants
via finite sums plus integral tails, not a zeta-height oracle. The product
(13) factors as zeta(2sigma)^(3/4) times corrected factors. For x<=1/4,
the incoming elementary bound |log h(x)+(3/4)log(1-x)|<=x^2 applies.
Here x=p^(-2sigma)<=2^(-4/3)<1/2, so this proof uses the slightly weaker
bound <=2*x^2, proved from the same series for all x<=1/2:
lower absolute coefficient <=9/32+(3/8)/(1-x)<=33/32<2;
upper <=(45/64)/(1-x)-3/8<=33/32<2.
Thus the omitted corrected-prime log is bounded by
2*B^(1-4sigma)/(4sigma-1). The local series tail is geometric.

All new constants are rebuilt at two precisions. Probability ratios,
polynomial identities, endpoint identities, concentration probes and
complex kernel convergence are checks on the written proof; they are
not themselves a certification of an infinite sequence. No effective
onset or proof-assistant formalization is claimed. Historical source
integrations are not repeated.

At N=64, d=5, the concrete transport shortens j=3,4,5 from 62 to eight
Dirichlet terms and retains j=0,1,2 unchanged. Every original cell, gate,
weight and source payment remains. Direct whole-cell interval evaluations
at 70 and 100 digits give:

| Quantity | First window | Second window |
| --- | ---: | ---: |
| Shortened surrogate surplus, lower | 0.8866 | 1.0073 |
| Paid gated maximum transport cost, upper | 0.4363 | 0.1202 |
| Source surplus restored BEFORE averaging, lower | 0.4706 | 0.8927 |

The last line is the interval mean of the shortened integrand minus its
pointwise cost, retaining shared cell weights; it is not obtained by
subtracting independently rounded aggregate endpoints. These are weaker
alternative certificates for the SAME historical windows, not new source
regions. They pay a nonzero finite truncation error and do not use (18)
with an invented numerical constant. Ten supplementary exact-rational
midpoints were checked with the uncollected phases theta0-t*log n: all
60 full coefficients and 20 transported quantities agree with the whole
cell enclosures. Those point checks do not replace the whole-cell proof.

General binomial-series and fixed-torus Fourier facts are standard:
https://dlmf.nist.gov/4.6 and https://dlmf.nist.gov/1.8 .
The coefficient spectrum, domination and actual-window reduction are
derived here. The incoming endpoint argument and exact previous ledger
remain attributed and retained under inputs/ and incoming/.
