"""Separate Fraction/decimal-grid verification at sigma=3/4; no mpmath."""
from fractions import Fraction as F
from math import isqrt,comb,factorial
import json
from pathlib import Path

GRID=10**36
def lo(x):return F(x.numerator*GRID//x.denominator,GRID)
def hi(x):return -lo(-x)
class I:
    def __init__(self,a,b=None):self.a=F(a);self.b=F(a if b is None else b);assert self.a<=self.b
    def __add__(self,x):
        x=conv(x);return I(lo(self.a+x.a),hi(self.b+x.b))
    __radd__=__add__
    def __neg__(self):return I(-self.b,-self.a)
    def __sub__(self,x):return self+-conv(x)
    def __rsub__(self,x):return conv(x)+-self
    def __mul__(self,x):
        x=conv(x);v=[self.a*x.a,self.a*x.b,self.b*x.a,self.b*x.b];return I(lo(min(v)),hi(max(v)))
    __rmul__=__mul__
    def inv(self):assert self.a*self.b>0;return I(lo(1/self.b),hi(1/self.a))
    def __truediv__(self,x):return self*conv(x).inv()
    def __rtruediv__(self,x):return conv(x)*self.inv()
    def sqrt(self):
        assert self.a>=0
        def floor(x):return F(isqrt(x.numerator*GRID*GRID//x.denominator),GRID)
        a=floor(self.a);b=floor(self.b)
        return I(a,b if b*b==self.b else b+F(1,GRID))
    def data(self):return [str(self.a),str(self.b)]
def conv(x):return x if isinstance(x,I) else I(x)

def atan(q):
    s=sum((F((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(60)),F(0))
    return I(s,s+F(1,121*q**121))
def zeta(power,terms=16384):
    assert power in (F(3,2),F(7,4))
    def root(n):
        return I(n).sqrt() if power==F(3,2) else I(n*n*n).sqrt().sqrt()
    s=sum((1/(n*root(n)) for n in range(1,terms+1)),I(0))
    tail=I((1/((power-1)*root(terms+1))).a,(1/((power-1)*root(terms))).b)
    return s+tail
def build():
    pi=16*atan(5)-4*atan(239)
    sqrt2=I(2).sqrt();cos8=((2+sqrt2)/4).sqrt()
    cos16=((1+cos8)/2).sqrt()
    sin8=((2-sqrt2)/4).sqrt();cos3_16=((1+sin8)/2).sqrt()
    ep=sum((F(1,4**k*factorial(k)) for k in range(61)),F(0))
    g=I(ep,ep+F(1,4**61*factorial(61))/(1-F(1,248)))
    z15=zeta(F(3,2));z175=zeta(F(7,4));z2=pi*pi/6
    prod=(z15*z15*z15).sqrt().sqrt();B=2048
    ps=[n for n in range(2,B+1) if all(n%p for p in range(2,isqrt(n)+1))]
    for p in ps:
        x=1/(p*I(p).sqrt());xp=I(1);h=I(0)
        for k in range(49):
            h+=F((2*k+1)*comb(2*k,k)**2,16**k)*xp;xp*=x
        nxt=F(99*comb(98,49)**2,16**49)*xp
        h=I(h.a,(h+nxt/(1-x)).b)
        corr=(1-x);corr=(corr*corr*corr).sqrt().sqrt()
        prod*=h*corr
    # 2*B^(1-4sigma)/(4sigma-1)=1/B^2 for sigma=3/4.
    eps=F(1,B*B);H=prod*I(1-eps,1/(1-eps))
    base=z15/4+cos8/24;signed=8*cos16*H/(9*pi)
    positive=g*g*(base+signed);negative=g*g*(base-signed)
    total=g*g*(z15/2+cos8/12)
    cross=g*(cos16*z175/2+cos3_16/12)
    end=z2/2+sqrt2/24
    vals=dict(H_sigma=H,positive_energy=positive,negative_energy=negative,
              total_energy=total,mean_square_endpoint_difference=total+end-2*cross)
    return dict(kind='independent_sigma_three_quarters',s='1/4',values={k:v.data() for k,v in vals.items()},
                display={k:[float(v.a),float(v.b)] for k,v in vals.items()},prime_cutoff=B,local_orders=48)

if __name__=='__main__':
    import sys
    result=build()
    with Path(sys.argv[1]).open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(result['display']))
