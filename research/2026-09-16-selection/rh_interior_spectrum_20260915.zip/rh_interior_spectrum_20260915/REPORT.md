# A growing coefficient block can be shortened under the original gate

15 September 2026. Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

## Main advance

The upper 40 percent of coefficient indices can be shortened from roughly
N Dirichlet terms to floor(sqrt(N)) terms while preserving the ORIGINAL
central gate and the minimum over ALL coefficients. The aggregate change
in the surplus is bounded by

    O(N^(-1/120)*log N + N^(-1/60)*(log N)^(3/2)) = o(1).

The source shifts, normalizers, common height and all lower coefficients
remain. This holds asymptotically on both original cutoff-window families.
It is a written analytic estimate, not an extrapolation of a finite test.
No effective starting cutoff or numerical big-O constant is supplied.

More generally any fixed upper block j/d>=lambda_0>29/54 admits a vanishing
gated truncation error. A quantitative L2 tail and a sqrt(log N) payment for
the growing maximum make this possible even though the central norm grows.

This is a REDUCTION, not the missing sign inequality. The surviving short
sums and the unchanged lower block still need a joint signed estimate.

## The finite transport is paid, not assumed

On the same two N64 windows, j=3,4,5 are shortened to eight terms and
j=0,1,2 stay unchanged. Across all 2,048 complete cells:

| Bound | First window | Second window |
| --- | ---: | ---: |
| Shortened surplus, lower | 0.8866 | 1.0073 |
| Transport-cost upper bound | 0.4363 | 0.1202 |
| Fully restored surplus, lower | 0.4706 | 0.8927 |

The restored quantity is formed cellwise before averaging. This is a
weaker alternative certificate for existing heights, not a larger RH
verification range. Its finite cost is explicitly nonzero.

## What the interior coefficients approach

On N_m=floor(exp(m)), fixed coefficient positions lambda=j/d above 5/27
have an actual-window, paid finite-support limit. Write

    lambda=s/2+4s^2-2s^3, sigma=1/2+s.

Their arithmetic spectrum has exponent sigma, phase pi*s/4 and amplitude
exp(1/2-s). It is not just another copy of the endpoint spectrum (sigma=1).
The common arithmetic configuration gives explicit one-sided energy and
cross-covariance limits. For example:

| Index fraction | Exponent | Negative energy limit | Squared distance from endpoint |
| --- | --- | ---: | ---: |
| 61/250 | 7/10 | [0.27852709,0.27852830] | [0.96693636,0.96693683] |
| 11/32 | 3/4 | [0.18905855,0.18905878] | [0.51267473,0.51267490] |
| 29/54 | 5/6 | [0.11459871,0.11459874] | [0.15919317,0.15919321] |

Rounded endpoints above are outward. These positive squared distances
rule out collapsing a fixed interior fraction to the endpoint. They do
not establish an interior-below-both-endpoints defect or a negative
surplus. Marginal energies are not the joint minimum.

## Incoming endpoint result

All 21 incoming manifest members verify; all 41 tests and eight symbolic
identities pass; four incoming results rebuild byte-for-byte. Its compact
2,048-cell input agrees with the previous authenticated source ledger.
The one-sided endpoint proof is consistent with its stated fixed-support
and L2 hypotheses. Its thresholds remain 0.4363 generally and 0.5172 on
the declared degree-edge sequence. Neither is a bound on R-Q.

## Verification and limits

New validation: 29 named checks, 11,480 exact ratio identities, 5,625
minimum-transport cases, 272 cross-precision spectral interval comparisons,
and 4,104 cross-precision finite interval comparisons. All pass. A separate
Fraction-based implementation agrees at exponent 3/4, without mpmath.
Sixty full coefficient and twenty transport point cross-checks also pass.
The written infinite arguments are not proof-assistant formalized.

All 787 existing pinned artifacts authenticated before work. Historical
packages and the desktop originals are unchanged. Work uses one serial
below-normal worker with a 900-second cap per invocation, no subagents,
no provider experiments, no external publication, and no new physical
heights or auxiliary/Gamma integrations. The two receipt-name collisions
and their unchanged successful numerical outputs are retained; the wrapper
now separates process receipts from numerical outputs.

## Next target

Use the exact upper-block truncation inside the complete signed surplus.
Prove a shared-height bound on the shortened upper block together with
the unchanged lower block and central gate, sufficient for

    limsup_m max_window (R_(N_m)-Q_(N_m)) < 0.5172.

That inequality remains open. The reduction does not establish unbounded
selection, winding closure, absolute zero-count closure or RH. More
accurate endpoint moments alone do not supply the missing joint sign.
