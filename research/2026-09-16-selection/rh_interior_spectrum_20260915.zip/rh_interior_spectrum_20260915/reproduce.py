"""Fresh output-only reproduction of three calculations and two check records."""
from pathlib import Path
import argparse,hashlib,importlib,json,runpy,shutil,sys

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);a=parser.parse_args()
    package=Path(__file__).resolve().parent;out=a.output.resolve()
    assert not out.exists() and not out.is_relative_to(package)
    mf=package/'PACKAGE_MANIFEST.json';files=json.loads(mf.read_text())['files']
    assert all(sha(package/r['path'])==r['sha256'] for r in files)
    built=['SPECTRUM_70_R1.json','FINITE_TRANSPORT_70.json','INDEPENDENT_CONSTANTS_R1.json',
           'VERIFICATION.json','POINT_CROSSCHECK.json']
    out.mkdir(parents=True)
    for p in package.iterdir():
        if p.name in built or p.name=='PACKAGE_MANIFEST.json':continue
        if p.is_dir():shutil.copytree(p,out/p.name)
        else:shutil.copyfile(p,out/p.name)
    sys.path.insert(0,str(out))
    spectrum=importlib.import_module('spectrum')
    dump(out/'SPECTRUM_70_R1.json',spectrum.build(70))
    transport=importlib.import_module('finite_transport')
    source=out/'incoming/RH_Endpoint_Sign_Energy_2026-09-15_v1/RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz'
    dump(out/'FINITE_TRANSPORT_70.json',transport.build(source,70))
    independent=importlib.import_module('independent')
    dump(out/'INDEPENDENT_CONSTANTS_R1.json',independent.build())
    runpy.run_path(str(out/'verify.py'),run_name='__main__')
    runpy.run_path(str(out/'point_crosscheck.py'),run_name='__main__')
    identical={name:sha(out/name)==sha(package/name) for name in built}
    assert all(identical.values())
    assert all(sha(package/r['path'])==r['sha256'] for r in files)
    receipt=dict(passed=True,members=len(files),byte_identical_results=identical,
        source_integrations_rerun=False,new_heights=0)
    dump(out/'CLEAN_RECEIPT.json',receipt);print(json.dumps(receipt))
if __name__=='__main__':main()
