from worker import run
from intake import HERE
run(HERE/'independent.py',[HERE/'INDEPENDENT_CONSTANTS_R1.json'],'separate_constants_replay')
run(HERE/'finite_transport.py',['--digits',100,'--source',HERE/'incoming/RH_Endpoint_Sign_Energy_2026-09-15_v1/RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz','--output',HERE/'FINITE_TRANSPORT_100.json'],'transport_compute_100')
