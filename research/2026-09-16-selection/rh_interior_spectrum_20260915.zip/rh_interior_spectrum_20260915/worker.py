"""One serial below-normal worker, bounded per invocation, retained receipts."""
from pathlib import Path
import os
import subprocess
import sys
import time
from intake import HERE, write, sha

def run(script,args,label,cwd=None):
    receipts=HERE/'receipts';receipts.mkdir(exist_ok=True)
    log=HERE/(label+'.log');receipt=receipts/(label+'.json')
    assert not log.exists() and not receipt.exists()
    command=[sys.executable,'-B',str(HERE/'invoke.py'),str(script),*map(str,args)]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
    tmp=HERE/'runtime_tmp';tmp.mkdir(exist_ok=True)
    env.update(TEMP=str(tmp),TMP=str(tmp))
    start=time.monotonic();timed_out=False
    with log.open('xb') as out:
        child=subprocess.Popen(command,cwd=cwd or Path(script).parent,env=env,
            stdout=out,stderr=subprocess.STDOUT,
            creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS if os.name=='nt' else 0)
        try:code=child.wait(timeout=900)
        except subprocess.TimeoutExpired:
            timed_out=True;child.kill();code=child.wait()
        out.flush();os.fsync(out.fileno())
    write(receipt,dict(command=command,pid=child.pid,exit_code=code,timed_out=timed_out,
        seconds=round(time.monotonic()-start,3),wall_cap_seconds=900,log_sha256=sha(log),
        maximum_compute_workers=1,below_normal=os.name=='nt',lf_text_serialization=True))
    print(f'{label}: {code}',flush=True)
    if code or timed_out:raise RuntimeError(label)
