"""Create-only intake, safe extraction, and read-only historical authentication."""
from pathlib import Path
import hashlib,json,os,shutil,zipfile

HERE=Path(__file__).resolve().parent
ROOT=next((p for p in HERE.parents if (p/'work/rh_compute/vendor').is_dir()),HERE)
PRIOR=ROOT/'work/rh_compute/tmp/rh_coefficient_shape_20260915'
DESKTOP=Path('D:/Users/ollet/Desktop/New folder (18)')

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def write(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(v,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())

def pins(book):
    rows={p:h for v in book['checkpoint'].values() if isinstance(v,dict)
          for p,h in v.get('artifact_hashes',{}).items() if isinstance(h,str) and len(h)==64}
    return dict(count=len(rows),mismatches=[p for p,h in rows.items() if sha(ROOT/p)!=h])

if __name__=='__main__':
    book=ROOT/'work/rh_compute/results/session_bookmark.json'
    checked=pins(json.loads(book.read_text()));assert checked['count']==787 and not checked['mismatches']
    shutil.copyfile(book,HERE/'BOOKMARK_BEFORE.json')
    prior=PRIOR/'delivery/rh_coefficient_shape_20260915'
    mf=prior/'PACKAGE_MANIFEST.json'
    assert sha(mf)=='7941537bc726f77dfabfe20222ae3b0dbb5201bcbe775eceed18b7fe3617e5b2'
    rows=json.loads(mf.read_text())['files'];assert len(rows)==45
    assert all(sha(prior/r['path'])==r['sha256'] for r in rows)
    inputs=HERE/'inputs';inputs.mkdir()
    for name in ['joint.json.gz','nodes.json.gz','MOMENT_LIMIT_REVIEW.md']:
        shutil.copyfile(PRIOR/'inputs'/name,inputs/name)
    for name in ['DERIVATION.md','SHAPE_RESULT.json']:
        shutil.copyfile(PRIOR/name,inputs/('PREVIOUS_'+name))
    for name in ['worker.py','invoke.py']:
        shutil.copyfile(PRIOR/name,HERE/name)
    archive=DESKTOP/'RH_Endpoint_Sign_Energy_2026-09-15_v1.zip'
    shutil.copyfile(archive,inputs/archive.name)
    target=HERE/'incoming';target.mkdir()
    with zipfile.ZipFile(archive) as z:
        assert len(z.infolist())<100 and sum(i.file_size for i in z.infolist())<100_000_000
        for i in z.infolist():
            p=(target/i.filename).resolve()
            assert p.is_relative_to(target.resolve()) and not (i.external_attr>>16)&0o170000==0o120000
        z.extractall(target)
    write(HERE/'INPUT_AUDIT.json',dict(passed=True,historical=checked,prior_members=45,
        prior_seal=sha(mf),zip_sha256=sha(archive),input_files={p.name:sha(p) for p in inputs.iterdir()}))
    print(json.dumps(dict(passed=True,pins=checked['count'],incoming=[p.as_posix() for p in target.iterdir()])))
