from intake import HERE,sha,write
from worker import run
import json

pack=HERE/'incoming/RH_Endpoint_Sign_Energy_2026-09-15_v1'
mf=pack/'RH_Endpoint_Sign_Manifest_2026-09-15_v1.json'
rows=json.loads(mf.read_text())['files']
assert len(rows)==21 and all(sha(pack/p)==h for p,h in rows.items())
write(HERE/'INCOMING_SEAL_CHECK.json',dict(members=21,passed=True,seal=sha(mf)))
out=HERE/'replayed';out.mkdir()
builder=pack/'RH_Endpoint_Sign_Builder_2026-09-15_v1.py'
source=pack/'RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz'
run(builder,['constants','--output',out/'constants.json'],'incoming_constants')
run(builder,['finite','--source',source,'--output',out/'finite.json.gz'],'incoming_finite')
run(pack/'RH_Endpoint_Sign_Independent_2026-09-15_v1.py',['--source',source,'--output',out/'independent.json'],'incoming_independent')
run(pack/'RH_Endpoint_Sign_Symbolic_2026-09-15_v1.py',['--output',out/'symbolic.json'],'incoming_symbolic')
run(pack/'RH_Endpoint_Sign_Tests_2026-09-15_v1.py',[],'incoming_tests')
pairs={'constants.json':'Constants_2026-09-15_v1.json','finite.json.gz':'Finite_2026-09-15_v1.json.gz',
       'independent.json':'Independent_2026-09-15_v1.json','symbolic.json':'Symbolic_Results_2026-09-15_v1.json'}
same={n:sha(out/n)==sha(pack/('RH_Endpoint_Sign_'+p)) for n,p in pairs.items()}
assert all(same.values())
assert all(sha(pack/p)==h for p,h in rows.items())
write(HERE/'INCOMING_REPLAY.json',dict(passed=True,byte_identical=same,tests=41,symbolic_identities=8,source_reevaluated=False))
print('All incoming results reproduced byte-identically; 41 tests passed.')
