"""Interval constants and bounded polynomial checks; no new source-height runs."""
from fractions import Fraction as F
from math import comb,isqrt
from pathlib import Path
from functools import lru_cache
import argparse,json
from mpmath import iv

def rat(x):
    x=F(x);return iv.mpf(x.numerator)/x.denominator

def bounds(x):
    from mpmath.libmp import to_rational
    return [str(F(*to_rational(t))) for t in x._mpi_]

def display(x):return [float(F(z)) for z in bounds(x)]

def pack(x):return dict(interval=bounds(x),display=display(x))

def primes(n):
    p=bytearray(b'\1')*(n+1);p[:2]=b'\0\0'
    for i in range(2,isqrt(n)+1):
        if p[i]:p[i*i:n+1:i]=b'\0'*((n-i*i)//i+1)
    return [i for i in range(2,n+1) if p[i]]

@lru_cache(None)
def zeta_real(power,terms):
    p=rat(power);assert F(power)>1
    total=sum((iv.mpf(n)**(-p) for n in range(1,terms+1)),iv.mpf(0))
    lo=(iv.mpf(terms+1)**(1-p)/(p-1)).a
    hi=(iv.mpf(terms)**(1-p)/(p-1)).b
    return total+iv.mpf([lo,hi])

def product(sigma,cutoff,orders,terms):
    sig=rat(sigma)
    v=zeta_real(str(2*F(sigma)),terms)**rat(F(3,4))
    for p in primes(cutoff):
        x=iv.mpf(p)**(-2*sig);h=iv.mpf(1);term=h
        for k in range(orders):
            term=term*rat(F((2*k+3)*(2*k+1),4*(k+1)**2))*x
            h+=term
        nxt=term*rat(F((2*orders+3)*(2*orders+1),4*(orders+1)**2))*x
        h=iv.mpf([h.a,(h+nxt/(1-x)).b])
        v*=h*(1-x)**rat(F(3,4))
    eps=2*iv.mpf(cutoff)**(1-4*sig)/(4*sig-1)
    return v*iv.exp(iv.mpf([-eps.b,eps.b])),eps

def params(s):
    s=F(s);sigma=F(1,2)+s
    return sigma,iv.pi*rat(s)/4,iv.exp(rat(F(1,2)-s))

def cov(s,t,terms):
    a,da,ga=params(s);b,db,gb=params(t)
    return ga*gb*(iv.cos(da-db)*zeta_real(str(a+b),terms)/2+iv.cos(da+db)/12)

def kernel_weights(d,j):
    weights=[iv.mpf(1)]
    for k in range(j):
        weights.append(weights[-1]*rat(F((j-k)*d*d,(d-k)*4*(2*k+1)*(2*k+2))))
    total=sum(weights,iv.mpf(0))
    return [w/total for w in weights]

def kernels():
    rows=[]
    for s in (F(1,5),F(1,4),F(1,3),F(1,2)):
        lam=s/2+4*s*s-2*s**3
        for d in (16,64,256,512):
            j=(lam*d).numerator//(lam*d).denominator
            ps=kernel_weights(d,j)
            mean=sum((p*rat(F(k,d)) for k,p in enumerate(ps)),iv.mpf(0))
            variance=sum((p*(rat(F(k,d))-mean)**2 for k,p in enumerate(ps)),iv.mpf(0))
            samples=[]
            for n in (1,2,7,31):
                w=-1-iv.log(n)+iv.pi*iv.j/4
                actual=sum((p*(1+w/d)**(2*k) for k,p in enumerate(ps)),iv.mpc(0))
                predicted=iv.exp(rat(s)*w)
                diff=abs(actual-predicted)
                samples.append(dict(n=n,error=pack(diff),actual_real=pack(actual.real),
                                    actual_imag=pack(actual.imag)))
            rows.append(dict(s=str(s),lambda_value=str(lam),d=d,j=j,
                             mean_k_over_d=pack(mean),variance=pack(variance),samples=samples))
    return rows

def build(digits,cutoff=4096,orders=64,terms=32768,with_kernels=True):
    iv.dps=digits;zeta_real.cache_clear()
    ss=(F(1,5),F(1,4),F(1,3),F(1,2));rows=[]
    for s in ss:
        sigma,delta,g=params(s);h,tail=product(str(sigma),cutoff,orders,terms)
        central=zeta_real(str(2*sigma),terms)/4+iv.cos(2*delta)/24
        signed=8*iv.cos(delta)*h/(9*iv.pi)
        positive=g*g*(central+signed);negative=g*g*(central-signed)
        total=cov(s,s,terms)
        difference=total+cov(F(1,2),F(1,2),terms)-2*cov(s,F(1,2),terms)
        c1=g*iv.exp(iv.j*delta)-iv.exp(iv.j*iv.pi/8)
        simple_lower=rat(F(5,12))*abs(c1)**2
        rows.append(dict(s=str(s),sigma=str(sigma),lambda_value=str(s/2+4*s*s-2*s**3),
            amplitude=pack(g),H_sigma=pack(h),prime_log_tail=pack(tail),
            positive_energy=pack(positive),negative_energy=pack(negative),
            total_energy=pack(total),mean_square_endpoint_difference=pack(difference),
            first_mode_difference_floor=pack(simple_lower)))
    covariance=[dict(s=str(s),t=str(t),value=pack(cov(s,t,terms))) for s in ss for t in ss]
    result=dict(kind='interior_spectrum_and_energy',digits=digits,cutoff=cutoff,orders=orders,
        constant_sum_terms=terms,rows=rows,covariance=covariance,
        scope=dict(new_source_evaluations=0,finite_coordinate_limits_only=True,
                   full_minimum_controlled=False,central_gate_controlled=False,
                   joint_R_minus_Q_bounded=False,effective_onset=False))
    if with_kernels:result['kernel_checks']=kernels()
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--digits',type=int,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--cutoff',type=int,default=4096)
    p.add_argument('--terms',type=int,default=32768);p.add_argument('--orders',type=int,default=64)
    p.add_argument('--no-kernels',action='store_true');a=p.parse_args()
    result=build(a.digits,a.cutoff,a.orders,a.terms,not a.no_kernels)
    with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps([dict(s=r['s'],positive=r['positive_energy']['display'],negative=r['negative_energy']['display'],difference=r['mean_square_endpoint_difference']['display']) for r in result['rows']]))
