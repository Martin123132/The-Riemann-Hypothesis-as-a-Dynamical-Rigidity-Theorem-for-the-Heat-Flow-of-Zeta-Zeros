"""Supplementary interval point checks using uncollected arithmetic phases."""
import gzip,json
from fractions import Fraction as F
from math import comb,factorial
from mpmath import iv
from intake import HERE,write
from spectrum import rat,bounds

iv.dps=100
src=json.loads(gzip.decompress((HERE/'incoming/RH_Endpoint_Sign_Energy_2026-09-15_v1/RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz').read_bytes()))
finite=json.loads((HERE/'FINITE_TRANSPORT_100.json').read_text())
scales=list(map(F,src['scales']));c=rat(F(2491,3000)-F(src['source_payment']))
def overlap(x,y):
    a,b=map(F,bounds(x));u,v=map(F,y);return max(a,u)<=min(b,v)
records=[]
for w in src['windows']:
    for i in [0,127,511,777,1023]:
        row=w['cells'][i];r=(F(row['r'][0])+F(row['r'][1]))/2;a=64+rat(r)
        t=2*iv.pi*a*a;theta=t*iv.log(a)-t/2-iv.pi/8
        angle=iv.exp(iv.j*theta)*(-1)**w['nu']
        full=[];short=[]
        for j in range(6):
            values=[]
            for cap in (62,8):
                zsum=iv.mpc(0)
                for n in range(1,cap+1):
                    z=iv.log(a/n)+iv.j*iv.pi/4
                    poly=sum((rat(F(comb(j,k),comb(5,k)))*z**(2*k)/rat(4**k*factorial(2*k)) for k in range(j+1)),iv.mpc(0))
                    zsum+=iv.sqrt(a/n)*iv.exp(-iv.j*t*iv.log(n))*poly
                values.append((2*rat(scales[-1])/64)*((angle*zsum).real+c)/rat(scales[j]))
            full.append(values[0]);short.append(values[1] if j>=3 else values[0])
            assert overlap(values[0],row['V'][j]),(w['nu'],i,j)
        x=full[0]/(rat(scales[-1])/4)
        def minimum(xs):return iv.mpf([min(z.a for z in xs),min(z.b for z in xs)])
        def maximum(xs):return iv.mpf([max(z.a for z in xs),max(z.b for z in xs)])
        p=iv.mpf([max(iv.mpf(0),x.a),max(iv.mpf(0),x.b)])
        new=p*minimum(short);err=p*maximum([abs(full[j]-short[j]) for j in range(3,6)])
        target=finite['windows'][w['nu']]['rows'][i]
        assert overlap(new,target['shortened']['interval'])
        assert overlap(err,target['error_cap']['interval'])
        records.append(dict(nu=w['nu'],i=i,shortened=bounds(new),error_cap=bounds(err)))
write(HERE/'POINT_CROSSCHECK.json',dict(passed=True,full_coefficient_checks=60,
      transported_point_checks=20,records=records,
      scope='supplementary point algebra check, not the whole-cell certificate'))
print('60 full coefficients and 20 transport values agree with whole-cell enclosures.')
