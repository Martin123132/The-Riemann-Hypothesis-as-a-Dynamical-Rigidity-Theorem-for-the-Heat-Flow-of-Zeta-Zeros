from intake import HERE
from worker import run

run(HERE/'spectrum.py',['--digits',70,'--output',HERE/'SPECTRUM_70_R1.json'],'compute_70')
run(HERE/'spectrum.py',['--digits',100,'--output',HERE/'SPECTRUM_100.json'],'compute_100')
