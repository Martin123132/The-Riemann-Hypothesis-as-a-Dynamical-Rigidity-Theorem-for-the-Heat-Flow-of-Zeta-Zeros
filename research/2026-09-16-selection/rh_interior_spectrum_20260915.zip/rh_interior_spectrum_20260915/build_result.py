from intake import HERE,write
import json
def read(name):return json.loads((HERE/name).read_text())
v=read('VERIFICATION.json');assert v['passed']
p=read('POINT_CROSSCHECK.json');assert p['passed']
finite=read('FINITE_TRANSPORT_100.json')
spectrum=read('SPECTRUM_100.json')
write(HERE/'FINAL_RESULT.json',dict(
    status='UPPER_BLOCK_GATED_TRUNCATION_AND_INTERIOR_ENERGY_LIMITS_SIGN_OPEN',
    input_review=read('INCOMING_REPLAY.json'),
    new_analytic=dict(energy_index_threshold='5/27',gated_index_threshold='29/54',
        concrete_block='j>=ceil(3d/5)',truncation='floor(sqrt(N))',
        gated_error='O(N^(-1/120)log(N)+N^(-1/60)log(N)^(3/2))',
        full_central_gate_retained=True,full_minimum_retained=True,effective_onset=False),
    finite=[dict(nu=w['nu'],moments=w['moments']) for w in finite['windows']],
    interior_moments=spectrum['rows'],validation=v,point_validation=p,
    remaining_target='limsup_m max_nu(R_N-Q_N)<0.5172 on N_m=floor(exp(m))',
    unbounded_sign_proved=False,RH_proof=False,new_heights=0,provider_calls=0,
    external_publication=False,maximum_compute_workers=1,subagents=0))
print('Final result created.')
