# Separate the endpoint clipping cost from the interior coefficient defect

15 September 2026. Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

## 1. Result and limitation

This stage attacks the signed coefficient loss, not the smoothness of its
rational surrogate. It proves a uniform bound for ONE component of that loss
and localizes the rest relative to both endpoints. It does not prove an
unbounded positive surplus or RH. All inherited source assumptions remain.

For the original positive-central gate, the exact surplus decomposes as

    S_tilde = <X Y>/2 + Q - C - R,
    Q=<|X|Y>/2,  0<=C<=<Y_+^2>/(4*kappa_N),  R>=0.       (1)

Here Y is the FULL last coefficient V_d, kappa_N=2s_d/sqrt(N)>1, and R
charges only interior coefficients which fall below BOTH endpoints. Angle
brackets use the original normalized W measure throughout.

The inherited mixed and second-moment limits therefore give

    S_tilde >= mu + Q - R + o(1),
    mu=c_*/2-v_*/4 > 0.4215,                              (2)

where

    c_*=cos(pi/8)*(zeta(3/2)/2+1/12),
    v_*=pi^2/12+cos(pi/4)/12.

Thus limsup(R-Q)<mu is sufficient on the required unbounded cutoffs. The
inequality is NOT proved here. Unlike the former undivided coefficient loss,
one of its pieces has now been paid uniformly using the endpoint moment.

On the same two N=64 windows, the fully paid finite lower bounds obtained by
(1) exceed 0.9678 and 0.9139. These are weaker alternative certificates for
the SAME surplus, not new heights or improved physical margins. The interior
penalty R is below 0.000003538 and 0.000076525, respectively. Its true value
may be zero; the enclosures do not prove pointwise endpoint dominance.

## 2. Exact endpoint/interior splitting

Use the incoming source-normalized coefficients

    X=Z_0/sqrt(N), V_j=(2s_d/N)Z_j, Y=V_d,
    P=X_+, kappa_N=2s_d/sqrt(N), V_0=kappa_N X.

Define pointwise

    E=min(V_0,Y),
    Delta=max(0, max_(1<=j<d)(E-V_j)).

For d=1 the empty maximum is zero. Exactly,

    min_(0<=j<=d)V_j=E-Delta
                   =Y-(Y-kappa_N X)_+-Delta.

Multiply by P>=0 and average. Since PY=(XY+|X|Y)/2, this proves (1), with

    C=<P*(Y-kappa_N X)_+>, R=<P*Delta>.

No term has been assumed favourable. In particular Q is SIGNED. It cannot
be declared positive from the sign of <XY>, analyticity, or a norm bound.
There is no new probability weight, no endpoint-only replacement of the
source, and no intermediate coefficient is discarded.

This is also an exact decomposition of the old residual loss:

    <P*max_j(Y-V_j)> = C+R.

## 3. The endpoint clipping cap is uniform and sharp

For every real x,y and kappa>0,

    0 <= x_+*(y-kappa*x)_+ <= y_+^2/(4*kappa).             (3)

If x<=0 or y<=0 the left side vanishes. Otherwise its nonzero region is
0<x<y/kappa and completing the square gives

    x*(y-kappa*x)=y^2/(4*kappa)-kappa*(x-y/(2*kappa))^2.

Equality is attained at x=y/(2*kappa)>0. Therefore the scalar constant
cannot be improved without using more joint source information. Averaging
(3) proves the cap in (1). Using <Y^2> instead of <Y_+^2> is conservative.

We next prove kappa_N>1 for the stated degree rule rather than assuming
an asymptotic equivalence. At j=d,

    s_d=sum_(k=0)^d (d/2)^(2k)/(2k)!.

Let T_d=cosh(d/2)-s_d. The ratio of successive omitted terms is less than
1/16, so

    T_d < (16/15)*(d/2)^(2d+2)/(2d+2)!
        < (16/15)*(e/4)^(2d+2).

The elementary factorial estimate m!>=(m/e)^m follows by summing log j
and comparing with integral_1^m log x dx; no asymptotic Stirling equality
is needed. With e<11/4 and sqrt(e)<5/3,

    2T_d*exp(d/2)
      < (121/120)*(605/768)^d < 1, d>=1.

Hence 2s_d=exp(d/2)+exp(-d/2)-2T_d>exp(d/2). Since
d=ceil(log(N+1)),

    kappa_N=2s_d/sqrt(N)>sqrt((N+1)/N)>1.                 (4)

This proof covers all the programme's N>=64. It is independent of any
measured coefficient signs or successful finite window.

Using the inherited uniform limits <XY>=c_*+o(1), <Y^2>=v_*+o(1),
(3)-(4) give (2). The endpoint here is the full Y, not the shortened
Y_K. The preceding paid endpoint truncation justifies using the same
mixed limit if starting from its K=floor(N^(2/3)) formulation. No new
effective starting cutoff is obtained for the inherited big-O terms.

## 4. The correct shape test includes the endpoint gap

For any real coefficient vector put

    L_j=(1-j/d)V_0+(j/d)V_d,
    C_k=V_(k-1)-2V_k+V_(k+1),
    G_(j,k)=min(j,k)*(d-max(j,k))/d, 1<=j,k<d.

The path Dirichlet Green identity is

    L_j-V_j=sum_(k=1)^(d-1) G_(j,k) C_k.                 (5)

It follows by checking zero endpoint values and
-Delta_j G_(j,k)=1_(j=k); a zero-second-difference sequence with zero
endpoints vanishes. This gives a direct proof for every finite d.
Background on discrete Green inverses is available in Chung and Yau's paper:
https://www.math.ucdavis.edu/~saito/data/discr-harm-anal/chung-yau-disc-green.pdf . Our simple path formula is
proved directly and no novelty is claimed for it.

But positive curvature alone is NOT the interior penalty. Put

    A_j=L_j-E
       =(j/d)(V_d-V_0)_+ + (1-j/d)(V_0-V_d)_+ >=0.

Then the exact interior defect is

    Delta=max(0, max_j [sum_k G_(j,k) C_k - A_j]).         (6)

All occurrences refer to the same coefficient vector and height. In the
finite calculation we collect the sum in (5) to L_j-V_j BEFORE interval
evaluation. Dropping A_j or replacing C_k by (C_k)_+ is valid for an upper
bound, but loses cancellation and the actual separation of the endpoints.

The finite probe distinguishes three hypotheses:

- Complete concavity fails on whole positive-gate cells: 208 in the first
  window and 209 in the second have a certified positive second difference.
- Unimodality of the raw scaled Taylor-input sequence also fails: 130 and
  126 positive-gate source nodes exhibit a strict decrease followed later
  by a strict increase. That sufficient shortcut cannot be assumed.
- No strictly interior minimum below both endpoints was certified by the
  whole-cell probe. This is NOT a proof that none exists. The explicit
  paid R bounds, rather than that absence of a counterexample, are used.

The raw-input sequence tested is D_k/[d^(2k)/(4^k(2k)!)], with c_N added
to D_0 only. Its unimodality is distinct from concavity of V_j. We do not
conflate these failed hypotheses or assert that V itself must be unimodal.

## 5. The curvature is an actual arithmetic kernel

Let lambda_N=2s_d/N and retain the inherited polynomial B_(d,j)(z).
Define, without new free phases,

    K_k(z)=B_(d,k-1)(z)/s_(k-1)-2B_(d,k)(z)/s_k
                                      +B_(d,k+1)(z)/s_(k+1).

For the SAME a=N+r, t=2*pi*a^2, epsilon, and natural prefix M,

    C_k=lambda_N*epsilon*Re sum_(n<=M) sqrt(a/n)
              *exp(i*(theta0-t*log n))*K_k(log(a/n)+i*pi/4)
         +lambda_N*c_N*(1/s_(k-1)-2/s_k+1/s_(k+1)).        (7)

The deterministic shift is retained, not differentiated away or discarded.
Equation (7) is an exact finite arithmetic representation, not a claim that
its real part has a fixed sign. Multiplying (7) by G and collecting recovers
the same chord difference in (5).

Thus the source-specific missing estimate can be stated precisely as

    limsup { <X_+ max_j(sum_k G_(j,k) C_k-A_j)_+>
                             - <|X|Y>/2 } < mu.          (8)

The max includes zero and all interior j. This is an equivalent geometric
form of R-Q, with one formerly coupled loss already paid by (3). Neither
(7) nor the finite probe proves (8). Controlling signed arithmetic
correlations jointly with the gate remains essential; independent curvature
magnitudes are not substituted as a claimed unbounded solution.

## 6. Executed finite test and what its numbers mean

We reuse all 2,048 certified whole-cell boxes from the authenticated joint
package, including the original second-derivative interpolation payments,
all six coefficient intervals, X, and W. The source payment remains exactly
0.271900134725. No new source sampling or physical height is introduced.

Exact rational interval arithmetic encloses each integrand and averages
with the original weight. The resulting conservative bounds are:

| Quantity | First window | Second window |
| --- | ---: | ---: |
| Gated endpoint <P Y>, lower | 1.0996 | 1.0586 |
| Actual clipping C, upper | 0.017942 | 0.007877 |
| Uniform-form finite clipping cap, upper | 0.138285 | 0.151239 |
| Interior penalty R, upper | 0.000003538 | 0.000076525 |
| New paid lower bound <P Y>-cap-R | 0.9678 | 0.9139 |
| Ignoring endpoint gap, signed-curvature penalty upper | 0.554129 | 0.342381 |
| Also dropping negative curvatures, penalty upper | 0.676705 | 0.465622 |

The new lower-bound integrand is enclosed BEFORE averaging, which is why
its recorded enclosure may be narrower than separately subtracting the
displayed aggregate extremes. The displayed numbers are rounded in the
conservative direction. The bounds do not establish R=0 or eventual
smallness of R at larger N. The better historical exact-surplus bounds
remain valid and unchanged.

The source-independent scalar clipping constant and Green identity are
analytic statements. The new moment envelopes are finite computations.
The inherited asymptotic limits are dependencies, not freshly proved here.
None of this substitutes finite tests for an unbounded argument.
