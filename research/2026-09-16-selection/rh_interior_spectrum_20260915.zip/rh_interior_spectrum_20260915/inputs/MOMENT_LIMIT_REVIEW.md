# Review of signed endpoint resonance and rational gate transfer

15 September 2026. Private RH research, TWO HANDS NETWORK LTD.
All rights reserved. Original supplied files and historical packages unchanged.

## 1. Conclusion and dependencies

No material mathematical defect was found in the two supplied written arguments
within their stated scope. This is a separate analytic/code review, not a
proof-assistant formalization or a new independent evaluation of the auxiliary
source. It retains the previously reviewed source polynomial, uniform endpoint
approximation, complete correction, logarithmic degree and source-sized scales.

The new signed-resonance statement, uniformly over the two original windows, is

    <X_N Y_N>_W = c_* + O(N^(-1/12)(1+log N)^(3/2)),
    c_*=cos(pi/8)*(zeta(3/2)/2+1/12)>0,
    X_N=Z_0/sqrt(N), Y_N=2*s_d*Z_d/N.

The second package proves

    <Y_N>_W -> (2/3)cos(pi/8),
    <Y_N^2>_W -> v_*=pi^2/12+cos(pi/4)/12,

and a uniformly paid rational approximation to the gate, not its unbounded
positive sign. No explicit starting cutoff is supplied for the limits. The
asymptotics concern the stated cutoff-window families, not arbitrary heights.

## 2. Signed resonance: the delicate steps checked

Write A=sum_(n<=M)n^(-1/2)e^(-it log n), B=sum_(m<=M)m^(-1)e^(-it log m),
C=sum_(n<=M)e^(-it log n), L=1+log N, and ell comparable to N^(-1/3).

The ratio-phase estimates are upper bounds with ALL off-diagonals retained:

    ||A||_2=O(N^(1/6)*sqrt(L)),
    ||B-B_K||_2=O(K^(-1/2)+L/sqrt(N ell)),
    ||C/N||_2=O(N^(-1/2)+sqrt(L/(N ell))).

For K=floor(sqrt(N)), the mixed endpoint-tail error is therefore

    O(N^(-1/12)*sqrt(L)+N^(-1/6)*L^(3/2)) = o(1).

The full central sum has NOT been truncated to fixed support. Its growing
norm is paid here. Multiplication by C/N costs O(N^(-1/6)*L), also o(1).

Expanding W=(1+cos chi)^2 and the product of two real parts leaves, before
division by <W>, just two stationary contributions:

    (3/4)cos(delta)*sum_(m<=K)m^(-3/2),
    (1/8)cos(delta), delta=pi/8.

The first is the zero ratio harmonic with equal indices. The second is the
zero product harmonic at n=m=1. Since the weight mass tends to 3/2, their
normalized coefficients are 1/2 and 1/12. Separate exact frequency-algebra
controls retain composite index ratios rather than assign an independent
variable to every integer; they agree with these coefficients.

The nonstationary estimates cover the following potentially dangerous cases:

* Ratio h=1, m=1: n<=N-J-1 keeps a-n>=J+1. Summing inverse distances
  pays O(N^(-1/6)*L); this term is not given an N log N lower bound.
* Product h=1: nm close to N is treated separately. For r in [0.24,0.76]
  and integer p, |N+r-p|>=(1+|N-p|)/10. Products for fixed m form an
  arithmetic progression of spacing m. Two nearest points cost at most two;
  the rest costs at most (2B/m)H_(2N+1), B=O(ell^(-1)). After multiplying
  by 1/sqrt(Nm) and summing m<=K, this is O(N^(-1/4)+N^(-1/6)*L).
* Product h>=2: after the PAID endpoint truncation, nm<=N*K<=N^(3/2),
  so no product near a^2 remains untreated.
* Other nonconstant ratio/product harmonics have the stated lower derivative
  bounds, including the zero product harmonic with nm!=1.

The phase derivative is 4*pi*a*log(a^h/X). Its second derivative has at most
one zero, giving at most two monotonicity pieces for the first derivative.
The elementary integration-by-parts bound therefore applies on the complete
windows. No independence, random signs or deletion of near resonances enters.

The a/N factors, correction c_N=O(N^(1/3)), and the O(N^(-kappa)) endpoint
polynomial error all vanish on the stated mixed normalization with these norm
bounds. Keeping s_d explicit handles the ceiling in d=ceil(log(N+1)).

## 3. Endpoint second moment: the limit order is valid

This proof uses a DIFFERENT truncation order: first fix K, then take N to
infinity, then enlarge K. The full endpoint differs in weighted L2 from

    Y_(K,N)=Re(e^(i chi+i delta) B_K)

by a limsup of at most sqrt(8/(3K)). The discarded C/N, c_N/N and endpoint
error tend to zero. The endpoint norms stay bounded, so L2 approximation
also controls the difference of second moments.

For fixed K, the exact constant coefficient of W Y_(K,N)^2 is

    (3/4)sum_(n<=K)n^(-2)+(1/8)cos(2 delta).

The first-moment constant is cos(delta). Division by weight mass 3/2
and then K->infinity gives the stated mean and v_*. Fixed support is justified
HERE; it is not silently reused for the growing rational gate below.

In particular <|Y_N|> has limsup at most sqrt(v_*), not necessarily equality.
Positive endpoint mean and positive ordinary mixed moment do not imply
positive gated moment. The exact negative-gated toy control in REVIEW_CHECKS
retains this distinction and is not an arithmetic model of the source.

## 4. Rational approximation: domain, tails and constants checked

For real x, |x|=(2/pi) integral_0^infinity x^2/(x^2+t^2) dt.
After t=exp(u), the integrand is |x|*sech(u-log|x|)/2. The translated sech
is smooth and exponentially decaying with its derivatives; Poisson summation
applies. Its Fourier transform pi/cosh(pi*xi/2) yields alias error at most

    4*A*exp(-pi^2/h)/(1-exp(-pi^2/h))

uniformly on [-A,A], with x=0 checked separately. The contour derivation of
the transform has the correct upper-edge sign and pole factor.

For rational b=1+1/qmesh and h=log b, the exact nodes b^k are positive.
The omitted low/high geometric tails are bounded by

    (2/3)*(b^(-K_-)+A^2*b^(-K_+)).

The rational alpha error is paid against the entire positive finite sum,
bounded by (A+E_alias)/alpha_lo. Thus coefficient rounding is included rather
than ignored. The chosen all-cutoff rule gives, in units eta=1/N,

    E_alias<=4*eta/63, E_tail<=eta/12, E_prefactor<=eta/8,
    (4/63+1/12+1/8)*eta < eta.

The source-wide domain |X_N|<3*ceil(sqrt N) follows from the complete finite
prefix magnitude and the retained shift, not measured maxima. The parameter
rule increases scalar precision as needed. Since qmesh=O(log N) and
log(1+1/qmesh)>=1/(qmesh+1), the number of nodes is O((log N)^2).

These estimates are uniform analytic bounds; the finite parameter and exact
arithmetic controls are checks of their implementation, not sampled proofs.

Let A_rat be the resulting rational approximation. Then

    |<(X_N)_+Y_N> - ( <X_NY_N>+<A_rat(X_N)Y_N> )/2|
      <= (delta_N/2)<|Y_N|>.

There is no central absolute or quadratic norm in THIS error. Consequently
the limsup of N times this discrepancy is at most sqrt(v_*)/2. The rational
expression is an evaluation device; (x+A_rat(x))/2 has not been installed
as a nonnegative probability weight.

## 5. A safe next reduction: assemble before truncating the endpoint

The preceding ingredients give a useful review corollary. Keep exactly the
same rational expression and define

    Q_N=(1/2)<A_rat(X_N)Y_N>,
    Q_(N,K)=(1/2)<A_rat(X_N)Y_(K,N)>.

The uniform additive approximation implies pointwise

    0<=A_rat(X_N)<=|X_N|+delta_N.

Thus, without treating the rational terms independently,

    |Q_N-Q_(N,K)|
       <= (1/2)(||X_N||_2+delta_N)||Y_N-Y_(K,N)||_2.       (R1)

Taking K=floor(sqrt N) in the already paid endpoint-tail estimates gives

    Q_N=Q_(N,K)+O(N^(-1/12)*sqrt(L)+N^(-1/6)*L^(3/2)).   (R2)

This is a consequence of the supplied bounds, not a new source experiment.
It does NOT give the sign of Q_(N,K). It also does not permit a fixed K
replacement of a factor multiplied by the growing central norm.

Why assemble first? A separate uniform error per rational moment would be
multiplied by alpha*sum_k tau_k, which can grow substantially. R1 instead
uses the actual aggregate and avoids that artificial coefficient payment.
The denominators and the complete central coefficient remain present.

With the intermediate loss Utilde=(2*s_d/N^(3/2))*U retained, the proof target
is still a strict shared-height comparison

    limsup max_nu (Utilde_N-Q_(N,K)) < c_*/2.

A suitably controlled unbounded selected family could also suffice. Every
individual rational moment need NOT be positive; the aggregate comparison is
what matters. Conversely, even all rational moments positive does not control
an arbitrary intermediate loss: the vector (1,-1,1) is an exact logic control.
No such source-wide strict comparison is established by this review.

## 6. Finite replay and preservation

Both supplied archives authenticate: 21 signed-resonance members and 20
rational-gate members. The embedded parent identities agree byte-for-byte.
The signed and rational suites pass 32 and 36 tests. Both primary/independent
builds and ancillary outputs reproduce eight saved result files exactly.
The rational primary also runs in only its three declared runtime files,
without historical acceptance records. Text outputs use an explicit external
LF writer on Windows; supplied source bytes are unchanged.

The separate review checker validates all 2048 cells, 2297 affine pieces,
104 positive rational moments, sign decomposition, normalization and inherited
residual combination, plus exact harmonic and logical controls. It performs
31863 exact checks. It does not replace source integrations or formalize the
analytic proof. Shared source nodes and the derivative helper remain inherited.

The finite normalized gated endpoints stay >1.0944 and >1.0486. After the
unchanged inherited intermediate loss, the normalized surpluses remain
>1.0780 and >1.0417. These are weaker enclosures of the SAME N64 successes,
not new heights or better physical margins.

All 766 incoming pins and the preceding 50-member package authenticate.
No new source evaluation, high-cutoff scan, provider call, Forge experiment,
external publication or unrequested background worker is part of this review.
Unbounded selection, winding and absolute-count closure remain open.

## Public mathematical references

The general analytic tools were checked against primary reference material:

* [NIST DLMF 1.8(iv)](https://dlmf.nist.gov/1.8#iv), Poisson summation.
* [NIST DLMF 2.3(i)](https://dlmf.nist.gov/2.3#i), integration by parts.
* [NIST DLMF 3.3(i)](https://dlmf.nist.gov/3.3#i), interpolation remainder.

The new source-specific sums, bounds and constants are justified in the two
supplied derivations and the review above, not attributed to those references.
No private research content was submitted to a web query.
