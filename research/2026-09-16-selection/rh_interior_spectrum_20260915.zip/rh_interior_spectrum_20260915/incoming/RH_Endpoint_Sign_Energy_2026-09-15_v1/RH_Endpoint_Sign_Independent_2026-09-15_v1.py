#!/usr/bin/env python3
"""Separate constant and cell replay; imports no primary code.
Local product coefficients use the closed binomial expression, not its recurrence.
All finite cell operations below use exact Fraction arithmetic without rounding.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from fractions import Fraction as F
from math import isqrt, factorial, comb
from pathlib import Path
import gzip, json, argparse

S=10**36
def down(x): return F((x.numerator*S)//x.denominator,S)
def up(x): return F(-((-x.numerator*S)//x.denominator),S)
def exact(x): return (F(x),F(x))
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[1],-a[0])
def sub(a,b): return add(a,neg(b))
def mul(a,b):
    p=[x*y for x in a for y in b]
    return (min(p),max(p))
def div(a,b):
    if b[0]<=0<=b[1]: raise ZeroDivisionError
    return mul(a,(1/b[1],1/b[0]))
def rnd(a): return down(a[0]),up(a[1])
def sq(a):
    return (F(0) if a[0]<=0<=a[1] else min(a[0]**2,a[1]**2),
            max(a[0]**2,a[1]**2))
def rt(a):
    if a[0]<0: raise ValueError("Negative root")
    ans=[]
    for idx,x in enumerate(a):
        k=isqrt((x.numerator*S*S)//x.denominator)
        if idx==1 and F(k,S)**2<x: k+=1
        ans.append(F(k,S))
    return tuple(ans)
def pos(a): return max(F(0),a[0]),max(F(0),a[1])
def amin(vals):
    if not vals: raise ValueError
    return min(a[0] for a in vals),min(a[1] for a in vals)
def amax(vals):
    if not vals: raise ValueError
    return max(a[0] for a in vals),max(a[1] for a in vals)
def read(v): 
    a=tuple(map(F,v))
    if len(a)!=2 or a[0]>a[1]: raise ValueError
    return a
def encode(a): return [str(v) for v in a]
def scale(a,b): return mul(a,exact(b))

def atan(q,n=50):
    s=sum((F((-1)**k,(2*k+1)*q**(2*k+1)) for k in range(n)),F(0))
    t=F((-1)**n,(2*n+1)*q**(2*n+1))
    return rnd((min(s,s+t),max(s,s+t)))
def pi_value(): return rnd(sub(scale(atan(5),16),scale(atan(239),4)))
def primes(B):
    out=[]
    for n in range(2,B+1):
        if all(n%p for p in out if p*p<=n): out.append(n)
    return out

def constant_check(B=2048,K=30):
    pi=pi_value(); z2=div(sq(pi),exact(6))
    prod=rt(rt(mul(sq(z2),z2)))
    for p in primes(B):
        # a_k=(2k+1)*binom(2k,k)^2/16^k.
        h=sum((F((2*k+1)*comb(2*k,k)**2,16**k*p**(2*k))
               for k in range(K+1)),F(0))
        nxt=F((2*K+3)*comb(2*K+2,K+1)**2,16**(K+1)*p**(2*K+2))
        hp=(h,h+nxt/(1-F(1,p*p)))
        z=exact(1-F(1,p*p))
        factor=rt(rt(mul(sq(z),z)))
        prod=rnd(mul(mul(prod,hp),factor))
    eps=F(1,3*B**3)
    prod=rnd(mul(prod,(1-eps,1/(1-eps))))
    sq2=rt(exact(2)); cdel=rt(div(add(exact(2),sq2),exact(4)))
    vs=add(div(sq(pi),exact(12)),div(sq2,exact(24)))
    extra=div(scale(mul(cdel,prod),8),scale(pi,9))
    vp=add(scale(vs,F(1,2)),extra); vm=sub(scale(vs,F(1,2)),extra)
    return {"prime_cutoff":B,"local_terms":K,"product":encode(prod),
            "vplus":encode(vp),"vminus":encode(vm),
            "vstar":encode(vs)}

def finite_check(src):
    if src["N"]!=64 or src["degree"]!=5: raise ValueError
    kappa=2*F(src["scales"][-1])/8
    if not kappa>1: raise ValueError
    result=[]
    if len(src["windows"])!=2: raise ValueError
    for nu,w in enumerate(src["windows"]):
        if w["nu"]!=nu or len(w["cells"])!=1024: raise ValueError
        lo,hi=(F(49,200),F(51,200)) if nu==0 else (F(149,200),F(151,200))
        mass=exact(0)
        sums={key:exact(0) for key in ("Yplus2","Yminus2","cap","interior","paid")}
        for i,c in enumerate(w["cells"]):
            if c["i"]!=i or tuple(map(F,c["r"]))!=(lo+(hi-lo)*i/1024,lo+(hi-lo)*(i+1)/1024):
                raise ValueError("Missing or shifted source cell")
            v=[read(z) for z in c["V"]]
            if len(v)!=6: raise ValueError
            x=read(c["X"]); weight=read(c["W"])
            weight=(max(F(0),weight[0]),min(F(4),weight[1]))
            if weight[0]>weight[1]: raise ValueError
            p=pos(x); y=v[-1]; v0=scale(x,kappa)
            v0=(max(v0[0],v[0][0]),min(v0[1],v[0][1]))
            if v0[0]>v0[1]: raise ValueError
            en=amin([v0,y])
            defect=amax([exact(0)]+[sub(en,z) for z in v[1:-1]])
            inter=mul(p,defect)
            cap=scale(sq(pos(y)),1/(4*kappa))
            vals={"Yplus2":sq(pos(y)),"Yminus2":sq(pos(neg(y))),
                  "cap":cap,"interior":inter,
                  "paid":sub(sub(mul(p,y),cap),inter)}
            for key,val in vals.items(): sums[key]=add(sums[key],mul(weight,val))
            mass=add(mass,weight)
        moments={k:div(v,mass) for k,v in sums.items()}
        if moments["paid"][0]<=0: raise ArithmeticError
        result.append({"nu":nu,"cells":1024,"moments":{k:encode(v) for k,v in moments.items()}})
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source",type=Path,required=True)
    ap.add_argument("--output",type=Path,required=True)
    a=ap.parse_args()
    if a.output.exists(): raise FileExistsError(a.output)
    src=json.loads(gzip.decompress(a.source.read_bytes()))
    result={"constants":constant_check(),"finite":finite_check(src),
            "scope":"Independent constant/cell arithmetic; shared inherited source enclosures; no second source evaluation."}
    a.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8",newline="\n")

if __name__=="__main__": main()
