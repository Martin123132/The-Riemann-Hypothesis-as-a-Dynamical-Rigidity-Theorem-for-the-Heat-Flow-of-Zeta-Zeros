# Endpoint sign energy — 15 September 2026, v1

Private research for Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

Read `RH_Endpoint_Sign_Energy_Derivation_2026-09-15_v1.md` for the new
one-sided endpoint-moment theorem and the precise still-unproved target.
`RH_Endpoint_Sign_Summary_2026-09-15_v1.json` contains the summary.

The new approximation is NOT another high-degree polynomial computation.
This stage computes a convergent arithmetic constant product and replays the
same inherited N64 source-cell bounds. It proves no new zero count.

## Reproduce (Python 3.10 or later)

The primary and independent arithmetic programs need only the standard library.
Use output paths that do not already exist.

```sh
python RH_Endpoint_Sign_Builder_2026-09-15_v1.py constants --output new_constants.json
python RH_Endpoint_Sign_Builder_2026-09-15_v1.py finite \
  --source RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz --output new_finite.json.gz
python RH_Endpoint_Sign_Independent_2026-09-15_v1.py \
  --source RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz --output new_independent.json
python RH_Endpoint_Sign_Tests_2026-09-15_v1.py
```

Optional symbolic identity replay (requires SymPy):
```sh
python RH_Endpoint_Sign_Symbolic_2026-09-15_v1.py --output new_symbolic.json
```

The raw inherited cell record and its original manifest are in `dependencies`.
The compact input retains only metadata and actual whole-cell W,X,V enclosures.
The input receipt records the source ZIP and exact source/compact SHA-256 values.
Neither program uses old acceptance thresholds or old rational-tree outputs.

The independent finite code uses exact unrounded Fraction operations. Its
constant code uses the closed binomial local coefficients and a different finite
prime cutoff. Both implementations share the inherited source enclosures and
the analytic endpoint-tail hypotheses; they are not independent source evaluations.

`RH_Endpoint_Sign_Manifest_2026-09-15_v1.json` hashes the delivered files. It does
not hash itself. The separate clean-rebuild receipt is outside the ZIP to avoid
a circular seal. Tests support written mathematics rather than formalizing an
asymptotic proof.

No earlier research file, desktop folder, repository, bookmark or pin record
was edited.
