#!/usr/bin/env python3
"""Eight symbolic controls; supplements, does not formalize, the analytic proof."""
from pathlib import Path
import argparse, json
import sympy as s
u=s.symbols("u",real=True)
x,y,kappa=s.symbols("x y kappa",real=True)
k=s.symbols("k",integer=True,nonnegative=True)

def checks():
    table=[
       ("positive_cosine_square",s.integrate(s.cos(u)**2,(u,-s.pi/2,s.pi/2))/(2*s.pi),s.Rational(1,4)),
       ("first_cosine_harmonic",s.integrate(s.cos(u)**3,(u,-s.pi/2,s.pi/2))/(2*s.pi),2/(3*s.pi)),
       ("first_sine_harmonic",s.integrate(s.sin(u)*s.cos(u)**2,(u,-s.pi/2,s.pi/2))/(2*s.pi),0),
       ("second_cosine_harmonic",s.integrate(s.cos(2*u)*s.cos(u)**2,(u,-s.pi/2,s.pi/2))/(2*s.pi),s.Rational(1,8)),
       ("second_sine_harmonic",s.integrate(s.sin(2*u)*s.cos(u)**2,(u,-s.pi/2,s.pi/2))/(2*s.pi),0),
       ("sharp_clipping_square",x*(y-kappa*x),y*y/(4*kappa)-kappa*(x-y/(2*kappa))**2),
    ]
    a=(2*k+1)*s.binomial(2*k,k)**2/16**k
    b=(2*k+3)*s.binomial(2*k+2,k+1)**2/16**(k+1)
    table.append(("local_binomial_ratio",s.simplify(s.combsimp(b/a)),1-1/(4*(k+1)**2)))
    H,delta,zz=s.symbols("H delta zz",real=True)
    vp=zz/4+8*s.cos(delta)*H/(9*s.pi)+s.cos(2*delta)/24
    vm=zz/4-8*s.cos(delta)*H/(9*s.pi)+s.cos(2*delta)/24
    table.append(("positive_negative_energy_sum",vp+vm,zz/2+s.cos(2*delta)/12))
    out=[]
    for name,left,right in table:
        diff=s.simplify(s.expand_trig(left-right))
        if diff!=0: raise AssertionError((name,diff))
        out.append({"name":name,"difference":str(diff),"passed":True})
    return {"symbolic_checks":out,"passed":len(out),
            "scope":"Exact identities only; not proof-assistant verification of limiting arguments."}

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,required=True)
    a=ap.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    a.output.write_text(json.dumps(checks(),indent=2,sort_keys=True)+"\n",encoding="utf-8",newline="\n")
