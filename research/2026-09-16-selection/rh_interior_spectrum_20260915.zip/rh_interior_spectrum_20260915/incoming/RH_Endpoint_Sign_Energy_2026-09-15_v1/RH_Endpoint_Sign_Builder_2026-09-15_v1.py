#!/usr/bin/env python3
"""Signed endpoint energy: directed rational constants and finite ledger.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

The unbounded conclusions are proved in the accompanying derivation.
This program checks constants and postprocesses inherited whole-cell enclosures.
It does not evaluate the critical-strip zeta or auxiliary function.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import isqrt, factorial, comb
from pathlib import Path
import argparse, gzip, hashlib, json

GRID = 10**42
SOURCE_SHA256 = "f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161"

def lower(x: F) -> F:
    x=F(x)
    return F((x.numerator*GRID)//x.denominator,GRID)

def upper(x: F) -> F:
    x=F(x)
    return F(-((-x.numerator*GRID)//x.denominator),GRID)

@dataclass(frozen=True)
class I:
    lo: F
    hi: F
    def __post_init__(self):
        object.__setattr__(self, "lo", F(self.lo))
        object.__setattr__(self, "hi", F(self.hi))
        if self.lo>self.hi:
            raise ValueError("Reversed interval")
    @staticmethod
    def exact(x): return I(F(x),F(x))
    @staticmethod
    def read(x): return I(F(x[0]),F(x[1]))
    def __add__(self, other):
        b=as_i(other); return I(lower(self.lo+b.lo),upper(self.hi+b.hi))
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,b): return self+-as_i(b)
    def __rsub__(self,b): return as_i(b)+-self
    def __mul__(self,other):
        b=as_i(other); p=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi]
        return I(lower(min(p)),upper(max(p)))
    __rmul__=__mul__
    def reciprocal(self):
        if self.lo<=0<=self.hi:
            raise ZeroDivisionError("Interval denominator includes zero")
        return I(lower(1/self.hi),upper(1/self.lo))
    def __truediv__(self,other): return self*as_i(other).reciprocal()
    def __rtruediv__(self,other): return as_i(other)*self.reciprocal()
    def square(self):
        l=F(0) if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi)
        return I(lower(l),upper(max(self.lo*self.lo,self.hi*self.hi)))
    def sqrt(self):
        if self.lo<0: raise ValueError("Negative square-root input")
        def down(x):
            return F(isqrt((x.numerator*GRID*GRID)//x.denominator),GRID)
        l=down(self.lo); u=down(self.hi)
        if u*u<self.hi: u+=F(1,GRID)
        return I(l,u)
    def positive(self): return I(max(F(0),self.lo),max(F(0),self.hi))
    def absolute(self):
        if self.lo>=0: return self
        if self.hi<=0: return -self
        return I(F(0),max(-self.lo,self.hi))
    def intersect(self,other):
        b=as_i(other)
        return I(max(self.lo,b.lo),min(self.hi,b.hi))
    def data(self): return [str(self.lo),str(self.hi)]
    def display(self): return [float(self.lo),float(self.hi)]

def as_i(x): return x if isinstance(x,I) else I.exact(x)

def imin(items):
    a=list(items)
    if not a: raise ValueError("Empty minimum")
    return I(min(v.lo for v in a),min(v.hi for v in a))

def imax(items):
    a=list(items)
    if not a: raise ValueError("Empty maximum")
    return I(max(v.lo for v in a),max(v.hi for v in a))

def primes_up_to(n):
    if n<2: return []
    flags=bytearray(b"\1")*(n+1); flags[0:2]=b"\0\0"
    for p in range(2,isqrt(n)+1):
        if flags[p]:
            flags[p*p:n+1:p]=b"\0"*((n-p*p)//p+1)
    return [p for p in range(2,n+1) if flags[p]]

def atan_bounds(q,terms=48):
    if q<=1 or terms<1: raise ValueError("Invalid arctangent parameters")
    x=F(1,q)
    s=sum(((-1)**k*x**(2*k+1)/F(2*k+1) for k in range(terms)),F(0))
    nxt=(-1)**terms*x**(2*terms+1)/F(2*terms+1)
    return I(lower(min(s,s+nxt)),upper(max(s,s+nxt)))

def pi_bounds(): return 16*atan_bounds(5)-4*atan_bounds(239)

def exp_one():
    n=80
    s=sum((F(1,factorial(k)) for k in range(n+1)),F(0))
    tail=F(1,factorial(n+1))/(1-F(1,n+2))
    return I(lower(s),upper(s+tail))

def local_factor(p,terms=32):
    if p<2 or terms<1: raise ValueError("Invalid local-factor parameters")
    x=F(1,p*p); term=I.exact(1); result=term
    for k in range(terms):
        term=term*F((2*k+3)*(2*k+1),4*(k+1)**2)*x
        result=result+term
    k=terms
    nxt=term*F((2*k+3)*(2*k+1),4*(k+1)**2)*x
    # Every later ratio is strictly below x.
    return I(result.lo,upper(result.hi+nxt.hi/(1-x)))

def endpoint_product(cutoff=4096,terms=32):
    if cutoff<2: raise ValueError("Prime cutoff must be at least two")
    pi=pi_bounds(); zeta2=pi.square()/6
    product=(zeta2*zeta2*zeta2).sqrt().sqrt()
    records=[]
    for p in primes_up_to(cutoff):
        fac=local_factor(p,terms)
        om=I.exact(1-F(1,p*p))
        corr=(om*om*om).sqrt().sqrt()
        product=product*fac*corr
        records.append({"p":p,"local":fac.data()})
    eps=F(1,3*cutoff**3)
    # |sum_{p>B} log(h(p^-2)*(1-p^-2)^(3/4))| < eps.
    complete=product*I(1-eps,1/(1-eps))
    return complete,{"prime_cutoff":cutoff,"terms_per_factor":terms,
                     "prime_count":len(records),"log_tail":str(eps),
                     "finite_corrected_product":product.data(),"local_factors":records}

def zeta_three_halves(terms=16384):
    if terms<1: raise ValueError("Invalid sum length")
    total=I.exact(0)
    for n in range(1,terms+1):
        total=total+1/(n*I.exact(n).sqrt())
    tail=I((2/I.exact(terms+1).sqrt()).lo,(2/I.exact(terms).sqrt()).hi)
    return total+tail

def constants():
    pi=pi_bounds(); sqrt2=I.exact(2).sqrt()
    cos_delta=((2+sqrt2)/4).sqrt()
    cos_2delta=sqrt2/2
    ep,details=endpoint_product()
    vstar=pi.square()/12+cos_2delta/12
    signed_add=8*cos_delta*ep/(9*pi)
    positive=vstar/2+signed_add
    negative=vstar/2-signed_add
    zeta32=zeta_three_halves()
    cstar=cos_delta*(zeta32/2+F(1,12))
    baseline=cstar/2-vstar/4
    all_cutoffs=cstar/2-positive/4
    selected=cstar/2-positive/(4*exp_one().sqrt())
    assert negative.lo>0
    assert all_cutoffs.lo>F("0.4363")
    assert selected.lo>F("0.5172")
    vals={"pi":pi,"endpoint_modulus_product":ep,"endpoint_total_energy":vstar,
          "endpoint_positive_energy":positive,"endpoint_negative_energy":negative,
          "zeta_three_halves":zeta32,"ordinary_resonance":cstar,
          "old_all_cutoff_allowance":baseline,
          "sign_resolved_all_cutoff_allowance":all_cutoffs,
          "degree_edge_subsequence_allowance":selected,
          "clipping_energy_saved":negative/4}
    return {"stage":"endpoint-sign-resolved asymptotic energy",
            "values":{k:v.data() for k,v in vals.items()},
            "display":{k:v.display() for k,v in vals.items()},
            "product_details":details,
            "scope":{"new_unbounded_joint_sign_bound":False,
                     "asymptotic_onset_computed":False,
                     "new_critical_strip_evaluations":0,
                     "sign_energy_limit_is_new_written_theorem":True,
                     "subsequence":"N_m=floor(exp(m)); d_N=m+1; m>=5",
                     "uniformity":"both original window families",
                     "constants_not_used_as_finite_N64_moment_bounds":True}}

def validate_source(src):
    if src["N"]!=64 or src["degree"]!=5:
        raise ValueError("This finite ledger is frozen at N64 degree five")
    if F(src["source_payment"])!=F("0.271900134725"):
        raise ValueError("Source payment changed")
    if len(src["windows"])!=2 or sorted(w["nu"] for w in src["windows"])!=[0,1]:
        raise ValueError("Both original windows are required")
    expected_scales = [
        sum((F(comb(j,k),comb(5,k))
             * F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F(0))
        for j in range(6)]
    if list(map(F,src["scales"]))!=expected_scales:
        raise ValueError("Scale roster changed")
    for w in src["windows"]:
        want=(F(49,200),F(51,200)) if w["nu"]==0 else (F(149,200),F(151,200))
        if tuple(map(F,w["r"]))!=want or len(w["cells"])!=1024:
            raise ValueError("Original window/cell roster changed")
        left=want[0]; step=(want[1]-want[0])/1024
        for i,c in enumerate(w["cells"]):
            if c["i"]!=i or tuple(map(F,c["r"]))!=(left+i*step,left+(i+1)*step):
                raise ValueError("Cell coverage changed")
            if len(c["V"])!=6: raise ValueError("Missing coefficient")
            for key in ("W","X"):
                I.read(c[key])
            for v in c["V"]: I.read(v)

def finite_ledger(src):
    validate_source(src)
    n=src["N"]; kappa=2*F(src["scales"][-1])/F(isqrt(n))
    if kappa<=1: raise ValueError("Invalid scale")
    output=[]
    names=("Y2","Yplus2","Yminus2","clipping_cap_one_sided","clipping_cap_two_sided",
           "clipping_actual","interior","gated_endpoint","ordinary_half","Q",
           "paid_one_sided","paid_two_sided","actual_surplus")
    for w in src["windows"]:
        totals={k:I.exact(0) for k in names}; mass=I.exact(0); rows=[]
        for c in w["cells"]:
            x=I.read(c["X"]); weight=I.read(c["W"]).intersect(I(0,4))
            v=[I.read(z) for z in c["V"]]
            v0=v[0].intersect(kappa*x)
            y=v[-1]; p=x.positive()
            endpoint_min=imin([v0,y])
            delta=imax([I.exact(0)]+[endpoint_min-z for z in v[1:-1]])
            delta=delta.positive()
            clip=p*(y-kappa*x).positive()
            cap=y.positive().square()/(4*kappa)
            oldcap=y.square()/(4*kappa)
            inter=p*delta
            gated=p*y
            payload={
                "Y2":y.square(),"Yplus2":y.positive().square(),
                "Yminus2":(-y).positive().square(),
                "clipping_cap_one_sided":cap,"clipping_cap_two_sided":oldcap,
                "clipping_actual":clip,"interior":inter,"gated_endpoint":gated,
                "ordinary_half":x*y/2,"Q":x.absolute()*y/2,
                "paid_one_sided":gated-cap-inter,"paid_two_sided":gated-oldcap-inter,
                "actual_surplus":p*imin(v)
            }
            for key,val in payload.items():
                totals[key]=totals[key]+weight*val
            mass=mass+weight
            rows.append({"i":c["i"],"r":c["r"],
                         "Y_positive_energy":payload["Yplus2"].data(),
                         "Y_negative_energy":payload["Yminus2"].data(),
                         "interior":inter.data(),"one_sided_paid":payload["paid_one_sided"].data()})
        # Equal cell widths cancel; no saved acceptance mean is read.
        if mass.lo<=0: raise ValueError("Unproved positive weight mass")
        moments={key:val/mass for key,val in totals.items()}
        if moments["paid_one_sided"].lo<=0: raise ArithmeticError("Finite positive test failed")
        output.append({"nu":w["nu"],"r":w["r"],"cells":rows,
                       "moments":{k:v.data() for k,v in moments.items()},
                       "display":{k:v.display() for k,v in moments.items()},
                       "positive_one_sided":True})
    return {"stage":"signed endpoint finite-ledger replay","N":64,"degree":5,
            "kappa_N":str(kappa),"windows":output,"original_cells":2048,
            "scope":{"new_source_evaluation":False,"historical_pins_reaudited":False,
                     "remaining_joint_loss_still_open":True,
                     "asymptotic_constants_used_at_N64":False,
                     "source_interpolation_enclosures_inherited":True}}

def write_json(path, data):
    path=Path(path)
    if path.exists(): raise FileExistsError(str(path))
    text=json.dumps(data,indent=2,sort_keys=True)+"\n"
    if path.suffix==".gz":
        path.write_bytes(gzip.compress(text.encode(),compresslevel=9,mtime=0))
    else:
        path.write_text(text,encoding="utf-8",newline="\n")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("mode",choices=("constants","finite"))
    ap.add_argument("--source",type=Path)
    ap.add_argument("--output",type=Path,required=True)
    args=ap.parse_args()
    if args.mode=="constants":
        ans=constants()
    else:
        if args.source is None: ap.error("--source is required")
        raw=args.source.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=SOURCE_SHA256:
            raise ValueError("Source byte binding failed")
        ans=finite_ledger(json.loads(gzip.decompress(raw)))
        ans["input_sha256"]=hashlib.sha256(args.source.read_bytes()).hexdigest()
    write_json(args.output,ans)

if __name__=="__main__": main()
