#!/usr/bin/env python3
"""Nonvacuous exact controls and complete replay for endpoint-sign energy."""
from fractions import Fraction as F
from pathlib import Path
from math import comb, factorial
from itertools import product
import copy, gzip, hashlib, importlib.util, json, sys, tempfile, unittest

ROOT=Path(__file__).resolve().parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,ROOT/file)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod
p=load("endpoint_primary_tests","RH_Endpoint_Sign_Builder_2026-09-15_v1.py")
q=load("endpoint_separate_tests","RH_Endpoint_Sign_Independent_2026-09-15_v1.py")
SOURCE=ROOT/"RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz"
src=json.loads(gzip.decompress(SOURCE.read_bytes()))
cr=json.loads((ROOT/"RH_Endpoint_Sign_Constants_2026-09-15_v1.json").read_text())
fr=json.loads(gzip.decompress((ROOT/"RH_Endpoint_Sign_Finite_2026-09-15_v1.json.gz").read_bytes()))
ir=json.loads((ROOT/"RH_Endpoint_Sign_Independent_2026-09-15_v1.json").read_text())
def ov(a,b): return max(a.lo,b.lo)<=min(a.hi,b.hi)
def canon(x): return (json.dumps(x,indent=2,sort_keys=True)+"\n").encode()
def val(key): return p.I.read(cr["values"][key])

class EndpointSignTests(unittest.TestCase):
    def test_01_signed_interval_product(self):
        self.assertEqual((p.I(-3,2)*p.I(-2,4)).data(),["-12","8"])
    def test_02_zero_denominator_rejected(self):
        with self.assertRaises(ZeroDivisionError): p.I(-1,2).reciprocal()
    def test_03_square_through_zero(self):
        self.assertEqual(p.I(-3,2).square().data(),["0","9"])
    def test_04_sqrt_outward(self):
        z=p.I.exact(2).sqrt()
        self.assertLessEqual(z.lo*z.lo,2);self.assertGreaterEqual(z.hi*z.hi,2)
    def test_05_positive_part(self):
        self.assertEqual(p.I(-2,3).positive().data(),["0","3"])
    def test_06_pi_rational_bracket(self):
        z=p.pi_bounds()
        self.assertGreater(z.lo,F("3.1415926535897932384626433832795028841971"))
        self.assertLess(z.hi,F("3.1415926535897932384626433832795028841972"))
    def test_07_binomial_coefficient_recurrence(self):
        a=F(1)
        for k in range(33):
            self.assertEqual(a,F((2*k+1)*comb(2*k,k)**2,16**k))
            a*=F((2*k+3)*(2*k+1),4*(k+1)**2)
    def test_08_local_ratio_geometric_tail(self):
        for prime in (2,3,5,7,101):
            for k in range(40):
                ratio=F((2*k+3)*(2*k+1),4*(k+1)**2*prime**2)
                self.assertGreater(ratio,0);self.assertLess(ratio,F(1,prime**2))
    def test_09_corrected_log_coefficients(self):
        self.assertEqual(F(9,32)+F(3,8)/(1-F(1,4)),F(25,32))
        self.assertEqual(F(45,64)/(1-F(1,4))-F(3,8),F(9,16))
        self.assertLess(F(25,32),1)
    def test_10_local_closed_series_inside_primary(self):
        for prime in (2,3,5,101):
            z=p.local_factor(prime,32)
            s=sum((F((2*k+1)*comb(2*k,k)**2,16**k*prime**(2*k)) for k in range(33)),F(0))
            self.assertLessEqual(z.lo,s);self.assertGreaterEqual(z.hi,s)
    def test_11_product_independent_contains_primary(self):
        a=val("endpoint_modulus_product");b=p.I.read(ir["constants"]["product"])
        self.assertLessEqual(b.lo,a.lo);self.assertGreaterEqual(b.hi,a.hi)
    def test_12_two_sign_energies_add(self):
        self.assertTrue(ov(val("endpoint_positive_energy")+val("endpoint_negative_energy"),
                           val("endpoint_total_energy")))
    def test_13_negative_energy_is_nonzero(self):
        self.assertGreater(val("endpoint_negative_energy").lo,F("0.05924"))
    def test_14_uniform_allowance(self):
        self.assertGreater(val("sign_resolved_all_cutoff_allowance").lo,F("0.4363"))
    def test_15_subsequence_allowance(self):
        self.assertGreater(val("degree_edge_subsequence_allowance").lo,F("0.5172"))
    def test_16_scalar_clipping_sharpness(self):
        for k in (F(1,2),F(1),F(7,3)):
            for y in (F(1,10),F(1),F(10)):
                x=y/(2*k)
                self.assertEqual(max(x,0)*max(y-k*x,0),y*y/(4*k))
    def test_17_scalar_cap_all_signs(self):
        for x,y,k in product(map(F,range(-5,6)),map(F,range(-5,6)),(F(1,3),F(1),F(3))):
            c=max(x,0)*max(y-k*x,0)
            self.assertGreaterEqual(c,0);self.assertLessEqual(c,max(y,0)**2/(4*k))
            if y<=0: self.assertEqual(c,0)
    def test_18_gate_algebra(self):
        for x,y in product(map(F,range(-5,6)),repeat=2):
            self.assertEqual(max(x,0)*y,(x*y+abs(x)*y)/2)
    def test_19_interior_identity(self):
        for vs in product(map(F,(-2,-1,0,1,2)),repeat=4):
            e=min(vs[0],vs[-1])
            delta=max([F(0)]+[e-v for v in vs[1:-1]])
            self.assertEqual(min(vs),vs[-1]-max(vs[-1]-vs[0],0)-delta)
    def test_20_no_concavity_assumption(self):
        v=(F(2),F(-1),F(3),F(2))
        self.assertGreater(v[0]-2*v[1]+v[2],0)
        self.assertEqual(min(v),-1)
        e=min(v[0],v[-1]);self.assertEqual(e-max([F(0)]+[e-x for x in v[1:-1]]),-1)
    def test_21_loss_splits_exactly(self):
        k=F(3,2)
        for x,y,z in product(map(F,(-2,0,1,3)),repeat=3):
            e=min(k*x,y);delta=max(0,e-z)
            self.assertEqual(max(x,0)*(y-min(k*x,y,z)),
                             max(x,0)*max(y-k*x,0)+max(x,0)*delta)
    def test_22_exact_scale_roster(self):
        want=[sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k))
                   for k in range(j+1)),F(0)) for j in range(6)]
        self.assertEqual(list(map(F,src["scales"])),want)
    def test_23_kappa_at_N64(self):
        self.assertGreater(F(fr["kappa_N"]),1)
        self.assertEqual(F(fr["kappa_N"]),2*F(src["scales"][-1])/8)
    def test_24_declared_subsequence_degree(self):
        e=p.exp_one();em=p.I.exact(1)
        checks=0
        for m in range(1,16):
            em=em*e
            if m>=5:
                low=em.lo.numerator//em.lo.denominator
                high=em.hi.numerator//em.hi.denominator
                self.assertEqual(low,high)
                self.assertGreater(F(low+1),em.hi)
                self.assertLess(F(low+1),(em*e).lo)
                checks+=1
        self.assertEqual(checks,11)
    def test_25_exact_allowance_gain(self):
        diff=val("sign_resolved_all_cutoff_allowance")-val("old_all_cutoff_allowance")
        self.assertTrue(ov(diff,val("endpoint_negative_energy")/4))
        self.assertGreater(val("clipping_energy_saved").lo,F("0.0148"))
    def test_26_complete_source_geometry(self):
        p.validate_source(src)
        self.assertEqual(sum(len(w["cells"]) for w in src["windows"]),2048)
    def test_27_missing_cell_rejected(self):
        bad=copy.deepcopy(src);bad["windows"][0]["cells"].pop()
        with self.assertRaises(ValueError):p.validate_source(bad)
    def test_28_shifted_cell_rejected(self):
        bad=copy.deepcopy(src);bad["windows"][1]["cells"][42]["r"][0]="3/4"
        with self.assertRaises(ValueError):p.validate_source(bad)
    def test_29_changed_scale_rejected(self):
        bad=copy.deepcopy(src);bad["scales"][4]="2"
        with self.assertRaises(ValueError):p.validate_source(bad)
    def test_30_changed_payment_rejected(self):
        bad=copy.deepcopy(src);bad["source_payment"]="0"
        with self.assertRaises(ValueError):p.validate_source(bad)
    def test_31_missing_window_rejected(self):
        bad=copy.deepcopy(src);bad["windows"].pop()
        with self.assertRaises(ValueError):p.validate_source(bad)
    def test_32_source_byte_binding(self):
        self.assertEqual(hashlib.sha256(SOURCE.read_bytes()).hexdigest(),p.SOURCE_SHA256)
        receipt=json.loads((ROOT/"RH_Endpoint_Sign_Input_Receipt_2026-09-15_v1.json").read_text())
        self.assertEqual(receipt["compact_input_sha256"],p.SOURCE_SHA256)
    def test_33_no_historical_acceptance_fields(self):
        self.assertEqual(set(src),{"N","degree","source_payment","scales","windows","provenance"})
        for w in src["windows"]:
            self.assertEqual(set(w),{"nu","r","cells"})
            for c in w["cells"]:
                self.assertEqual(set(c),{"i","r","W","X","V"})
    def test_34_full_finite_rebuild(self):
        got=p.finite_ledger(src);got["input_sha256"]=p.SOURCE_SHA256
        self.assertEqual(canon(got),canon(fr))
    def test_35_full_constant_rebuild(self):
        self.assertEqual(canon(p.constants()),canon(cr))
    def test_36_independent_full_rebuild(self):
        self.assertEqual(q.constant_check(),ir["constants"])
        self.assertEqual(q.finite_check(src),ir["finite"])
    def test_37_finite_positive_surpluses(self):
        for nu,w in enumerate(fr["windows"]):
            b=p.I.read(w["moments"]["paid_one_sided"])
            self.assertGreater(b.lo,F("0.9678") if nu==0 else F("0.9139"))
    def test_38_finite_energy_decomposition(self):
        for w in fr["windows"]:
            d=w["moments"]
            self.assertTrue(ov(p.I.read(d["Yplus2"])+p.I.read(d["Yminus2"]),p.I.read(d["Y2"])))
            self.assertGreater(p.I.read(d["Yminus2"]).lo,0)
    def test_39_overwrite_refused(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/"r.json";p.write_json(path,{"ok":1})
            with self.assertRaises(FileExistsError):p.write_json(path,{"ok":2})
    def test_40_scope_is_explicit(self):
        self.assertFalse(cr["scope"]["new_unbounded_joint_sign_bound"])
        self.assertFalse(cr["scope"]["asymptotic_onset_computed"])
        self.assertFalse(fr["scope"]["asymptotic_constants_used_at_N64"])
    def test_41_limit_is_not_a_finite_bound(self):
        # The second finite positive-energy lower bound exceeds the limiting
        # positive energy. This guards against substituting the limit at N64.
        finite=p.I.read(fr["windows"][1]["moments"]["Yplus2"])
        self.assertGreater(finite.lo,val("endpoint_positive_energy").hi)

if __name__=="__main__":
    unittest.main(verbosity=2)
