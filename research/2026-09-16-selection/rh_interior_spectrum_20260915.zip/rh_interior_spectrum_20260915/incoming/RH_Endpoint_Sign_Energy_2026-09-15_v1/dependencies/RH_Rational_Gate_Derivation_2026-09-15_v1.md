# The positive-central gate as a controlled finite rational-moment problem

**15 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Results and the boundary of this step

This continuation addresses the positive-central gate in the signed endpoint
budget. It does not change the source, its original squared-cosine probability
weight, its positive-central selection weight, the logarithmic degree, the
source-sized coefficient scales, or the approximation payment.

There are two new analytic statements and one finite calculation:

1. In the normalization defined below, the outer endpoint has the explicit
   second-moment limit
   
       <Y_N^2>_W -> v_* = pi^2/12 + cos(pi/4)/12
                          = 0.8813925985229922... .
   
   Its mean tends to (2/3) cos(pi/8). The proof uses fixed finite endpoint
   truncations followed by a paid tail estimate, not an assumption about a
   full-length diagonal or a random-prime model.
2. The positive-part operation in the mixed endpoint moment can be replaced
   by a finite rational expression with uniform absolute error. A rule using
   O((log N)^2) rational terms gives a mixed-moment error O(1/N) in the
   normalized units. The central coefficient's growing absolute or second
   moment is not charged in that error.
3. At N=64, every one of the 52 signed rational-kernel moments is strictly
   positive in BOTH complete original windows. The resulting gate bounds
   remain positive after every approximation and whole-cell error is paid.

The all-height SIGN of these rational moments, their weighted sum, and the
remaining intermediate-coefficient loss is not established. This is not an
unbounded height-selection theorem, new zero count, or new region certificate.
The old gate correction can still be negative; the new decomposition is exact
and does not reclassify it.

## 2. Unchanged definitions and the normalization

Use the source definitions of the included signed-endpoint-resonance package.
For N>=64,

    J=floor((N/64)^(1/3)), M=N-J-1, a=N+r, t=2*pi*a^2,
    d=ceil(log(N+1)), s_j=B_(d,j)(d),
    Z_j=(beta_j+c_N)/s_j, c_N=H_J-E_N,
    P=(Z_0)_+, m_source=min_j Z_j.

The two original r windows have centers 1/4 and 3/4 and half-width
1/[100(J+1)]. Their length ell is comparable to N^(-1/3).
The common probability expectation is the original

    <f>_W = E_I(W f)/E_I W, W=(1+cos chi)^2,
    exp(i chi)=(-1)^(N+nu) exp(i theta_0(t)).

No argument principle is applied to this real weight.

Normalize the two endpoint quantities as

    X_N=Z_0/sqrt(N),
    Y_N=2*s_d*Z_d/N=2*(beta_d+c_N)/N.                    (2.1)

Thus the gated endpoint moment in the preceding notation satisfies

    mathcal M_N := <(X_N)_+ Y_N>_W
                 = (2*s_d/N^(3/2)) <P Z_d>_W.           (2.2)

The ordinary signed moment is

    mathcal C_N := <X_N Y_N>_W -> c_*,
    c_*=cos(pi/8)*(zeta(3/2)/2+1/12)>0.                 (2.3)

Equation (2.3), with its stated error, is inherited from the supplied parent;
this stage does not re-prove that mixed central/endpoint theorem. The new
second-moment limit concerns Y_N alone and is proved in Section 3.

The exact gate identity to preserve is

    mathcal M_N = (1/2) mathcal C_N
                    +(1/2) <|X_N| Y_N>_W.              (2.4)

It is equivalent to the parent's ordinary-product-plus-negative-central
correction. In particular the second term in (2.4) is not a nonnegative
quantity by definition. Y_N retains its actual sign.

## 3. A precise endpoint second-moment limit

Let delta=pi/8 and retain the actual-height sums

    B_N(t)=sum_(n<=M) n^(-1) exp(-it log n),
    C_N^0(t)=sum_(n<=M) exp(-it log n).

The parent's paid endpoint approximation gives uniformly on both windows

    Y_N = Re{exp(i chi)[(a/N)exp(i delta)B_N
                           +exp(-i delta) C_N^0/N]}
          +2*c_N/N+O(N^(-1-kappa)),                    (3.1)

where kappa=log(16)-5/2>1/4. The shift c_N=O(N^(1/3)) and the endpoint
polynomial error are retained. The ceiling in d causes no unexplained limiting
scale in (3.1), because s_d has canceled from Y_N exactly.

### 3.1 A uniform tail bound permits a fixed truncation

For K fixed, let B_K=sum_(n<=K)n^(-1)exp(-it log n). For N sufficiently large,
K<=M. The ordinary ratio-phase integration estimate gives

    E_I |B_N-B_K|^2 <= sum_(K<n<=M)n^(-2)
                       +O(log^2(N)/(N ell))
                    <= 1/K+o_N(1).                     (3.2)

To justify the off-diagonal payment, for n>m use

    log(n/m)>=(n-m)/n,
    1/[mn log(n/m)] <= 1/[m(n-m)].

The entire resulting double sum is at most H_N^2. Integration of each ratio
phase costs O(1/(N ell)). No diagonal-only lower bound is used. This is the
same upper estimate proved in the parent, valid also after restricting the
indices to the tail. Its constants are independent of K.

Also, by the complete analogous ratio estimate,

    E_I |C_N^0/N|^2 = O(1/N+log(N)/(N ell)) -> 0.

Since W<=4 and E_I W->3/2, these transfer to weighted L2. With

    Y_(K,N)=Re(exp(i chi+i delta)B_K),

(3.1)-(3.2) imply

    limsup_N ||Y_N-Y_(K,N)||_(L2(W)) <= sqrt(8/(3K)).       (3.3)

The other errors in (3.1) tend to zero for each K. In particular the endpoint
norms remain bounded. This justifies passing from a finite trigonometric
calculation to the full endpoint.

### 3.2 All constant harmonics of the fixed sum

For fixed K, expand W and Y_(K,N). Each nonconstant phase is
h*theta_0(t)-t*log(n/m) or h*theta_0(t)-t*log(nm), with n,m<=K.
After N tends to infinity, fixed nonzero logarithms have derivatives of order
N, while nonzero h has derivatives of order N log N. Integration by parts on
at most two monotonicity pieces proves decay of these finite averages.
No uniform estimate for a simultaneously growing K is needed.

For the first moment the only constant contribution is n=1 after canceling
the theta harmonic. It gives

    lim_N <Y_(K,N)>_W = (2/3) cos(delta).                 (3.4)

For the square the constant contributions BEFORE dividing by the weight mass
are exactly

    (3/4) sum_(n<=K)n^(-2) + (1/8)cos(2 delta).

The first comes from equal-index conjugate products. The second is the
n=m=1 nonconjugate product and the degree-two weight harmonic. The other
terms are not silently dropped at finite N: their finite-support averages
tend to zero by the preceding estimate. Consequently

    lim_N <Y_(K,N)^2>_W
       = (1/2)sum_(n<=K)n^(-2)+(1/12)cos(2 delta).        (3.5)

The identity zeta(2)=pi^2/6 is used only for this absolutely convergent
positive series [S3], not for any fact about nontrivial zeros.

### 3.3 The order of limits

For fixed K take N to infinity in (3.4)-(3.5). Then let K increase.
By (3.3) and

    |<Y_N^2>-<Y_(K,N)^2>|
       <= ||Y_N-Y_(K,N)||_2 (||Y_N||_2+||Y_(K,N)||_2),

the discrepancy tends to zero as K tends to infinity. Uniformly in nu=0,1,

    <Y_N>_W -> (2/3)cos(pi/8),
    <Y_N^2>_W -> v_* = pi^2/12+cos(pi/4)/12.              (3.6)

In particular

    limsup <|Y_N|>_W <= sqrt(v_*) = 0.9388251160482405... . (3.7)

This is an upper bound for the absolute mean, not an assertion that its
limit equals the L2 limit. The first and second moments alone do not establish
positive gated contribution. For example, equal weights on the points
(X,Y)=(-2,-2),(1,-1),(0,4) have positive EY and EXY, but E[X_+Y]=-1/3.

## 4. A rational approximation to |x| with a global additive bound

For x real,

    |x| = (2/pi) integral_0^infinity x^2/(x^2+t^2) dt.     (4.1)

At x=0 both sides are zero. For nonzero x, substituting t=|x|v reduces this
to the elementary arctangent integral. With t=exp(u),

    x^2 exp(u)/(x^2+exp(2u))
        = (|x|/2) sech(u-log|x|).

For h>0 put

    A_h(x)=(2h/pi) sum_(k in Z)
                      exp(kh) x^2/(x^2+exp(2kh)).         (4.2)

Poisson summation applies to the translated sech function; it and its second
derivative are absolutely integrable [S1]. The transform needed here is

    integral_R sech(u) exp(-i xi u)du = pi/cosh(pi xi/2).

A short derivation closes the contour at imaginary height pi. The top edge
contributes exp(pi xi) times the lower integral, with the sign of cosh and
contour orientation cancelling. The residue at i*pi/2 is exp(pi xi/2)/i,
so (1+exp(pi xi))I=2*pi*exp(pi xi/2). The vertical edges vanish for each
fixed real xi; symmetry covers either sign. This gives the displayed transform.

Poisson summation now yields, for x!=0,

    A_h(x)/|x| = 1+2 sum_(j>=1)
        cos(2*pi*j*log|x|/h)/cosh(pi^2*j/h).

All Fourier terms converge absolutely. Therefore, on |x|<=A,

    |A_h(x)-|x|| <= 4*A*q/(1-q), q=exp(-pi^2/h).           (4.3)

This is a continuous-domain error theorem, not an estimate from a finite
set of x samples.

### 4.1 Rational nodes and explicit truncation

Take an integer qmesh>=1, b=1+1/qmesh, h=log b, and tau_k=b^k.
All tau_k are exact positive rationals. Truncate k to -K_-<=k<=K_+.
Using x^2*t/(x^2+t^2)<=t and <=A^2/t bounds the two omitted tails:

    tail <= [2h/(pi(b-1))]*(b^(-K_-)+A^2*b^(-K_+))
          < (2/3)*(b^(-K_-)+A^2*b^(-K_+)).                (4.4)

Here h<=b-1 and pi>3. Also h<=1/qmesh and pi^2>9, so

    exp(-pi^2/h) < 2^(-9*qmesh)=q_bound.

The latter is deliberately conservative; it uses e>2. Equation (4.3) may
therefore be paid by the exact rational value

    E_alias=4*A*q_bound/(1-q_bound).

Finally replace 2h/pi by a rational alpha enclosed by proved rational
log/atan series. If alpha_exact lies in [alpha_lo,alpha_hi], let alpha be
the midpoint and e_alpha the half-width. Since the positive finite sum is
at most the infinite one,

    E_prefactor <= e_alpha*(A+E_alias)/alpha_lo.           (4.5)

The approximation used in acceptance is the genuine rational function

    A_rat(x)=alpha sum_(k=-K_-)^(K_+) tau_k*x^2/(x^2+tau_k^2).

Equations (4.3)-(4.5) prove

    sup_(|x|<=A) |A_rat(x)-|x|| <= delta,
    delta=E_alias+E_tail+E_prefactor.                     (4.6)

Every real denominator is positive. There is no untested puncture at x=0.

## 5. An all-cutoff rule with only logarithmically squared many kernels

For the present normalized central coefficient, the inherited tail/error rule
and the elementary square-root sum give

    |X_N| <= 2*sqrt(N+1)+(1/3)N^(-1/6)
           < 3*ceil(sqrt(N))=:A_N^max, N>=64.             (5.1)

Indeed |D0|/sqrt(N)<=sqrt(a/N)*sum_(n<=M)n^(-1/2)<=2sqrt(a), and
0<c_N<H_J<(2/3)(J+1)<=N^(1/3)/3. This uses a source-wide upper bound,
not a maximum observed on the N64 nodes.

Choose eta_N=1/N. Let qmesh be the smallest positive integer with

    2^(9*qmesh) >= 64*A_N^max/eta_N.

Choose the smallest nonnegative K_-,K_+ with

    b^(K_-)>=16/eta_N,
    b^(K_+)>=16*(A_N^max)^2/eta_N.

Compute alpha finely enough that E_prefactor<=eta_N/8. The included exact
rational series increase precision until this last inequality is verified;
fixed decimal precision is NOT asserted sufficient for unbounded N.
Then

    E_alias <= (4/63)eta_N,
    E_tail <= eta_N/12,
    E_prefactor <= eta_N/8,

so delta_N<eta_N=1/N for every N>=64. The first bound uses q_bound<=
eta_N/(64*A_N^max)<=1/64. None of these inequalities is established by
checking a list of cutoffs.

Moreover qmesh=O(log N), and

    log(1+1/qmesh)>=1/(qmesh+1).

Thus K_-+K_++1=O((log N)^2). The required scalar precision also grows only
logarithmically. This counts rational-kernel terms, not the total cost of
evaluating their actual-height moments. No computational speedup is claimed.

## 6. Transfer to the signed endpoint without the divergent central norm

Set

    K_(N,k)=< [X_N^2/(X_N^2+tau_k^2)] Y_N >_W,
    Q_N=(alpha_N/2) sum_k tau_k*K_(N,k),
    Mhat_N=(1/2)<X_NY_N>_W+Q_N.                          (6.1)

All quantities use the original common height and original W. The actual
positive-central weight is unchanged. In particular (x+A_rat(x))/2 is
used only to approximate this moment: it need not be nonnegative and is
not installed as a substitute probability density.

By (2.4) and (4.6), exactly

    |mathcal M_N-Mhat_N| <= (delta_N/2)<|Y_N|>_W.           (6.2)

Only the endpoint absolute mean is paid. There is no factor ||X_N||_2 or
<X_N^2> in this gate-approximation error. Hence (3.7) and delta_N<1/N give

    limsup_N max_nu N*|mathcal M_N-Mhat_N|
         <= sqrt(v_*)/2 = 0.4694125580241202... .          (6.3)

This is a quantitative all-cutoff approximation/transfer rule and an asymptotic
bound on its cost. It does NOT establish the sign of Q_N or of mathcal M_N.
The rational factors lie in [0,1], but multiplying them by signed Y_N does
not give nonnegative moments automatically.

Using the parent's signed resonance (2.3),

    mathcal M_N = c_*/2+Q_N
                   +O(N^(-1/12)(1+log N)^(3/2))+O(1/N).  (6.4)

The function being averaged is no longer nonsmooth. Its denominator and growing
set of scales remain essential. It is NOT a fixed finite trigonometric test;
one cannot apply the earlier finite-harmonic limit by pretending that its
Fourier support is fixed. Proving a signed bound for (6.1) is still necessary.

## 7. Complete finite calibration on the unchanged source

At N=64 the frozen rule gives

    A_max=24, eta=1/64, qmesh=2, b=3/2,
    K_-=18, K_+=33, number of kernels=52.

The computed rational uniform approximation error is

    delta < 0.001410668 < 0.001411,

well below the declared 1/64 target. The difference is not treated as a measured
error: it is the sum of the proved alias, truncation and prefactor allowances.

The source data are the same 2050 arithmetic nodes, degree five, scales and
payment 0.271900134725 as in the supplied parent. There are 1024 complete
cells in each window. Each node bounds W,D0,...,D6; only D0,...,D5 enter this
source polynomial. The unchanged helper rederives whole-window second-derivative
bounds from the explicit finite summands.

For each smooth W, X_N, Y_N, the hull of its two endpoint intervals widened
by hcell^2*sup|f''|/8 encloses its image on the entire cell [S2]. Only AFTER
this step is x^2/(x^2+tau^2) applied. Its monotonicity as a function of x^2
provides the exact range enclosure. Signed products with W Y_N are retained,
then summed across all original cells. These are not point samples.

All 52 weighted signed kernel moments have positive LOWER bounds in each
window: 104/104 moment inequalities, using 106496 whole-cell kernel images.
Both signs of Y_N occur in the source cover; negative products are not clipped.
No moment is discarded for having an inconvenient sign.

The primary normalized results are:

| Original window | <|X_N|Y_N> after rational error | <(X_N)_+Y_N> |
|---|---:|---:|
| [0.245,0.255] | [1.0880941,1.1902553] | [1.0944457,1.1957374] |
| [0.745,0.755] | [0.9537744,1.0594486] | [1.0486862,1.1559528] |

Displays are outward rounded; rational records govern acceptance. The added
gate-transfer payment is below 0.000555 in either normalized endpoint moment.
The much wider total intervals include conservative complete source-cell
ranges as well as that small extra approximation payment.

The separate Fraction replay rederives all source-cell enclosures with the
same authenticated derivative helper and evaluates the rational kernels with
its own arithmetic. It imports none of the new primary fixed-point or moment
code. All 104 signs and both normalized gate lower bounds are reproduced,
with overlapping interval endpoints. Independence concerns rational-kernel
postprocessing, not the source helper or an independent source evaluation.

The existing intermediate-coefficient loss U_N is NOT recalculated here. Its
fully paid parent upper bounds, after the same normalization, may be combined
with the new gate lower bounds. They give lower bounds for the old surplus
above 1.0780 and 1.0417 in normalized units, equivalently above 45.0050 and
43.4906 in original-W units. These are weaker new enclosures of the SAME
finite surplus, not larger physical margins or new selected heights.

## 8. What the next unbounded comparison now asks for

Retain Utilde_N=(2*s_d/N^(3/2))*U_N, the full remaining intermediate loss.
The unchanged selection surplus has normalized expression

    Stilde_N = mathcal M_N-Utilde_N
             = c_*/2 + Q_N-Utilde_N+o(1).                (8.1)

A sufficient next theorem is

    limsup_N max_nu [Utilde_N-Q_N] < c_*/2.               (8.2)

A compatible strict comparison on an unbounded selected family also suffices
for the corresponding selection conclusion. Equality in the limiting
threshold does not settle finite signs; lower-order terms then matter.

The finite positivity of every K_(64,k) does not prove (8.2), or their signs at
other cutoffs or scales. Their explicit rational form offers another way to
attack the gate rather than reintroducing a growing RMS payment. The source
phases and both numerator/denominator must remain at the SAME height.

Even unbounded full-width cap selection still leaves the established winding,
multiplicity and absolute initial-count obligations. No part of those is reset.

## 9. Computation and reproducibility

The parent archive authenticates 21/21 manifest-listed members. Its saved source
nodes and derivative helper are copied byte-identically. No higher-cutoff scan,
new special-function evaluation, auxiliary contour integral or zeta/count call
is performed. The old pin audit is not rerun.

The new suite has 36 passing tests, including full primary and separate replay,
all 104 signed moment checks, errors and scale guards, preserved source geometry,
input hashes, denominator rejection, and no-overwrite behavior. Ten symbolic
identities independently check the endpoint harmonics, normalization and basic
rational identities. These are implementation controls, not formal verification
of the all-height limits or a sampled proof of uniform approximation.

The primary accepts from just its program plus the authenticated source-node
file and derivative-helper file. It does not read parent results. The separate
replay additionally reads the new result to check parameter and ledger agreement;
it recomputes the source-cell bounds and moments rather than accepting those
saved signs. The summary's subtraction of inherited U_N is explicitly separate.

All new artifacts have stage/date/version names. No laptop, desktop, repository,
bookmark or historical certificate is changed. Clean extraction and byte-rebuild
receipts are produced outside the sealed archive to avoid circular sealing.

## Sources and attribution

[S1] NIST DLMF 1.8(iv), especially 1.8.14, Poisson summation and its hypotheses:
https://dlmf.nist.gov/1.8#iv . The sech transform and explicit error used here
are derived in Section 4, not asserted as an undocumented software result.

[S2] NIST DLMF 3.3(i), Lagrange interpolation with its real derivative remainder:
https://dlmf.nist.gov/3.3#i . Applied to smooth W, X_N and Y_N before the
nonlinear kernel operations.

[S3] NIST DLMF 25.6(i), zeta(2)=pi^2/6:
https://dlmf.nist.gov/25.6#i . Only an absolutely convergent positive series is
involved in the endpoint norm.

[S4] Included unchanged RH_Signed_Endpoint_Resonance_2026-09-15_v1.zip and its
full derivation: source definitions, paid endpoint approximation, ratio-phase
upper estimates, existing signed resonance c_*, source nodes, and finite U_N.
Its exact SHA-256 and member verification are in the input receipt. Earlier
source bounds and counting results retain their original meanings.

Written analytic proofs plus executed exact arithmetic are not proof-assistant
formalization. No novelty-priority claim or general reuse permission is made.
Third-party mathematical attribution is retained.
