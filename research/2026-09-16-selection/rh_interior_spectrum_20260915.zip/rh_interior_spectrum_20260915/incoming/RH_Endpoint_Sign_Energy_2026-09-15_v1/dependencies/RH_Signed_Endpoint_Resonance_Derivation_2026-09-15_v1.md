# A positive signed centre–endpoint resonance, with the gate correction retained

**15 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Result and what is not being inferred

The latest saved checkpoint rebases the same positive-central surplus as

\[
 S_N=\langle Pm\rangle_W=M_N-U_N,\qquad
 M_N=\langle PZ_d\rangle_W,\quad
 U_N=\langle P(Z_d-m)\rangle_W,\quad P=(Z_0)_+.
\]

Here m is the minimum of all the normalized Bernstein coefficient tests. The
question is to obtain a SIGNED lower bound, not to mistake an upper L2 bound
for a positive contribution. This companion proves a signed arithmetic
asymptotic for a component of M_N, then retains the additional gate correction.

Define the ordinary bilinear mixed moment and the negative-central correction

\[
 \mathcal C_N=\langle Z_0Z_d\rangle_W,\qquad
 \mathcal D_N=\langle(-Z_0)_+Z_d\rangle_W.
\]

Exactly,

\[
 \boxed{M_N=\mathcal C_N+\mathcal D_N,\qquad
 S_N=\mathcal C_N+\mathcal D_N-U_N.}                     \tag{1}
\]

### New analytic statement

For the original two window families, logarithmic degree, source-sized scales
and complete source shift, uniformly in the window index,

\[
 \boxed{
 \frac{2s_d}{N^{3/2}}\mathcal C_N
 =c_*+O\!\left(N^{-1/12}(1+\log N)^{3/2}\right),
 \qquad
 c_* =\cos(\pi/8)\left[\frac12\sum_{n\ge1}n^{-3/2}+\frac1{12}\right]>0.
 }                                                        \tag{2}
\]

The absolutely convergent series is the usual constant zeta(3/2), not an
assumption concerning the nontrivial zeros. A rational finite-sum plus
integral-tail calculation encloses c_* between

    1.283749908859766 and 1.283750129119729.

Thus the ordinary SIGNED bilinear contribution is positive for every
sufficiently large cutoff. No effective starting cutoff is supplied. The
proof estimates the complete actual shared-height sums; there is no
random-prime model and no diagonal-only lower-bound assumption.

This does NOT prove that M_N itself is positive eventually: its extra term
mathcal D_N is signed and remains to be bounded. It also does not prove that
S_N is positive. The exact outstanding comparison is stated in Section 9.
The fixed-weight obstruction, earlier finite certificates and all winding,
initial-count and multiplicity obligations remain unchanged.

### New finite calculation

The unchanged N=64 source data give, with outward-rounded displays:

| Window | Ordinary mixed moment mathcal C | Signed gate correction mathcal D | Residual U |
|---|---:|---:|---:|
| [0.245,0.255] | [47.95382652,48.07028332] | [-0.26114435,-0.22052004] | [0.60823859,0.68492076] |
| [0.745,0.755] | [49.91102737,50.03132488] | [-4.01287605,-3.96018815] | [0.21288538,0.28901892] |

In particular the gate correction is actually negative in BOTH finite windows.
Its sign has not been assumed helpful. The three-term expression (1) gives
surplus lower bounds >47.0077 and >45.6091. Direct net integration gives
>47.0301 and >45.6491; different valid enclosures need not have identical
endpoints. These are enclosures of the same historical finite surplus, not
new physical margins, weights, good heights or zero counts.

## 2. Unchanged arithmetic quantities and inherited source inputs

For an integer N>=64 put

\[
 J=\lfloor(N/64)^{1/3}\rfloor,\quad M=N-J-1,\quad
 a=N+r,\quad t=2\pi a^2,\quad d=\lceil\log(N+1)\rceil.
\]

The two windows have centres (1+2 nu)/4, half-width 1/[100(J+1)], and
length ell=1/[50(J+1)] comparable to N^(-1/3). In particular every r lies
in [0.24,0.76]. Set

\[
 \theta=2\pi a^2\log a-\pi a^2-\pi/8,\quad
 e^{i\chi}=(-1)^{N+\nu}e^{i\theta},\quad W=(1+\cos\chi)^2.
\]

E_I denotes ordinary normalized window integration; angle brackets divide
E_I(W f) by Z_W=E_I W. This is the original probability measure, not the
positive-central probability measure. The latter is unchanged as well.

Let

\[
 D_k=\Re\sum_{n\le M}\sqrt{a/n}\,e^{i(\chi-t\log n)}
       \frac{(\log(a/n)+i\pi/4)^{2k}}{4^k(2k)!},
\]

\[
 B_{d,j}(z)=\sum_{k\le j}\frac{\binom jk}{\binom dk}
                       \frac{z^{2k}}{4^k(2k)!},\quad
 s_j=B_{d,j}(d),\quad
 \beta_j=\sum_{k\le j}\frac{\binom jk}{\binom dk}D_k.
\]

Write c_N=H_J-E_N for the physical coefficient shift, to distinguish it
from the NEW mixed moment mathcal C_N. The inherited estimates are

\[
 H_J=\frac23(J+1)-\frac{503}{1000},\quad
 E_N=\frac{e^2}{9}N^{-\kappa}+\frac{\log N+2}{4\pi N},\quad
 \kappa=\log16-\frac52>\frac14.
\]

Thus c_N=O(N^(1/3)), uniformly over the cell. Set Z_j=(beta_j+c_N)/s_j,
m=min_j Z_j. The prior source theorem converts m>0 into the sufficient
full-width real-part sign condition. No new implication about the exact
source is obtained merely by rescaling its sufficient coefficients.

Two consequences of the already proved logarithmic approximation rule are
needed below. With delta=pi/8 and

\[
 A(t)=\sum_{n\le M}n^{-1/2}e^{-it\log n},\quad
 B(t)=\sum_{n\le M}n^{-1}e^{-it\log n},\quad
 C(t)=\sum_{n\le M}e^{-it\log n},
\]

one has

\[
 D_0=\sqrt a\,\Re(e^{i\chi}A),                             \tag{3}
\]

\[
 \beta_d=\frac12\Re\{e^{i\chi}[a e^{i\delta}B+e^{-i\delta}C]\}
                  +O(N^{-\kappa}).                       \tag{4}
\]

The error in (4) is UNIFORM on both windows. It comes from the paid
transverse polynomial endpoint tail, not differentiation of a pointwise
remainder. Formula (4) follows by expanding the two terms of cosh at the
outer endpoint before summing. The exact auxiliary remainder still belongs
to the inherited tail support H_J, which is not removed by (4).

Finally

\[
 s_d=\sum_{k=0}^{d}\frac{(d/2)^{2k}}{(2k)!}
       =\left(\frac12+o(1)\right)e^{d/2}\asymp\sqrt N.      \tag{5}
\]

The omitted positive cosh tail is at most
(16/15)(e/4)^(2d+2); this is an estimate of an explicit series. The ceiling
in d need not converge modulo one, so this paper does NOT assert that
mathcal C_N/N has a single limit. Keeping s_d in (2) avoids that mistake.
It follows from (2) and (5) that

\[
 \liminf\min_\nu\frac{\mathcal C_N}{N}\ge\frac{c_*}{\sqrt e}>0,
 \qquad
 \limsup\max_\nu\frac{\mathcal C_N}{N}\le c_*.
\]

These are asymptotic bounds, not finite lower bounds at N=64.

## 3. Oscillatory estimate and complete L2 upper bounds

Let L=1+log N. For a fixed integer h and fixed X>0 the actual phase is

\[
 \Phi_{h,X}=h\chi-t\log X,\qquad
 \Phi'_{h,X}=4\pi a\log(a^h/X),
\]

\[
 \Phi''_{h,X}=4\pi[h\log a-\log X+h],\quad
 \Phi'''_{h,X}=4\pi h/a.
\]

The derivative has at most two monotone pieces. If its modulus is at least
lambda>0, integration by parts bounds the ordinary average of exp(i Phi)
by min(1,6/(ell lambda)). This follows from endpoint contributions and
integral |Phi''|/|Phi'|^2 on the monotone pieces. For a slowly varying
amplitude use its supremum plus total variation. All constants below are
absolute and uniform over the two windows. The phase derivative is kept
linked to the same r in every term.

Write H_n=sum_(k<=n)1/k. The weight mass is

\[
 Z_W=3/2+O(N^{-2/3}/L),                                    \tag{6}
\]

because theta' has modulus at least a constant times N log N and W has
only four nonconstant harmonics. In particular division by Z_W is uniformly
safe eventually. Also 0<=W<=4; thus ordinary L2 upper bounds transfer to
weighted ones with an absolute constant.

For a ratio n/m with n>m,
log(n/m)>=(n-m)/n. Paying all off-diagonal terms yields

\[
 \|A\|_{L^2(W)}^2=O(N^{1/3}L).                            \tag{7}
\]

For completeness, the near range m>=n/2 contributes at most a constant
times sum_(n<=N) H_n=O(NL) to
sum_(m<n)1/[sqrt(mn)log(n/m)]. On the far range log(n/m)>=log2 and summing
1/sqrt(mn) gives O(N). Multiplication by 1/(N ell), plus the diagonal
H_M, proves (7). No full mean-square equality is assumed.

Let K=floor(sqrt N), and B_K=sum_(m<=K)m^-1 exp(-it log m). The tail obeys

\[
 \|B-B_K\|_{L^2(W)}^2
     =O\left(K^{-1}+\frac{L^2}{N\ell}\right).             \tag{8}
\]

Indeed its diagonal is at most 1/K. The entire off-diagonal sum is bounded
by H_N^2, since

\[
 \frac1{mn\log(n/m)}\le\frac1{m(n-m)}\quad(n>m).
\]

The same argument gives ||B||_2=O(1). For the unweighted finite sum,

\[
 \|C/N\|_{L^2(W)}^2
       =O\left(N^{-1}+\frac{L}{N\ell}\right).             \tag{9}
\]

Here sum_(m<n)1/log(n/m)<=sum_n n H_(n-1)=O(N^2 L), and the diagonal
is at most 1/N. These are upper bounds in their valid direction.

Combining (7)-(8) by Cauchy--Schwarz shows

\[
 \big|\langle\Re(e^{i\chi}A)\Re(e^{i\chi+i\delta}(B-B_K))\rangle_W\big|
 =O\left(N^{-1/12}L^{1/2}+N^{-1/6}L^{3/2}\right).          \tag{10}
\]

Equation (7) with (9) likewise makes every mixed A,C/N contribution
O(N^(-1/6)L), hence negligible. Importantly (10) also holds when the first
real factor is replaced by its positive or negative part: the L2 norm can
only decrease. This supplies a quantitative endpoint truncation for the
still-unsolved gated term; it does not give that term a positive sign.

## 4. Exact mixed harmonic expansion

Put X=Re(e^{i chi}A), Y_K=Re(e^{i chi+i delta}B_K),
R=e^(-i delta) A conjugate(B_K), and T=e^(i delta) A B_K.
Direct multiplication gives

\[
\begin{aligned}
 WXY_K={}&\frac34\Re R
  +\frac12\Re[(e^{i\chi}+e^{-i\chi})R]
  +\frac18\Re[(e^{2i\chi}+e^{-2i\chi})R]\\
 &+\frac34\Re(e^{2i\chi}T)
  +\frac12\Re[(e^{3i\chi}+e^{i\chi})T]
  +\frac18\Re[(e^{4i\chi}+1)T].                         \tag{11}
\end{aligned}
\]

The first index n runs through ALL n<=M in every product. Only the
outer 1/m endpoint sum is temporarily truncated to K, with its complete
tail paid in (10). There are exactly two constant-phase contributions:

* ratio harmonic h=0, n=m<=K:
  (3/4) cos(delta) sum_(m<=K)m^(-3/2);
* product harmonic h=0, n=m=1:
  (1/8) cos(delta).

The remaining terms have not been declared to average to zero. Section 5
bounds their actual finite-window integrals. In particular the product
harmonic h=1 can have nm close to N and requires special treatment.

## 5. Bounds for every nonconstant mixed term

All amplitudes in (11) have magnitude n^(-1/2)m^(-1), with n<=M and m<=K.
They are constant in r; the phase variation is handled entirely by Section 3.
The unweighted amplitude sum is O(sqrt N L).

### 5.1 Ratio harmonic zero away from the diagonal

On n in [m/2,2m], the response sum before the common factor 1/(N ell) is
O(sum_(m<=K)m^(-1/2) H_(2m))=O(sqrt K L). Off that range the log ratio has
modulus at least log2, so the corresponding sum is O(sqrt N L). Thus the
whole non-diagonal contribution is O(N^(-1/6)L).

### 5.2 Other ratio harmonics

For h=-1,-2 or h=2, the ratios n/m<=N and m/n<=K imply a derivative lower
bound of order N log N. For h=1 with m>=2 use n/m<=N/2 and a derivative
lower bound of order N. These groups cost at most O(N^(-1/6)L).

For h=1,m=1 split n at N/2. The low portion is covered by the N bound.
For the high portion,

    a log(a/n) >= a-n >= N-n >= J+1.

Each amplitude is O(N^(-1/2)). The normalized integral sum is bounded by
C N^(-1/2) ell^(-1) sum_(k=J+1)^N 1/k=O(N^(-1/6)L).

### 5.3 Product harmonics except h=1

For h>=2, nm<=NK<=N^(3/2), whereas a^2>=N^2. The phase derivative is
therefore bounded below by c N log N eventually. For h=0, remove nm=1;
every remaining product has log(nm)>=log2. These terms again contribute
at most O(N^(-1/6)L). There is no unhandled product near a^2: truncating
B to K excludes it, and (10) already paid the discarded endpoint tail.

### 5.4 Product h=1 near nm=N

Outside nm in [N/2,2N], use the derivative lower bound of order N.
Inside that range the amplitude is at most C/(sqrt N sqrt m).
For an integer p=nm and every r in the windows,

    |N+r-p| >= (1+|N-p|)/10.

Together with the logarithmic derivative and the trivial integral bound,
the response is at most

    C/(sqrt N sqrt m) * min(1,B/(1+|nm-N|)),   B=C/ell.

For each fixed m, the products nm form an arithmetic progression of step m.
The nearest point on each side costs at most one; successive distances on
that side are at least m,2m,... . Hence

\[
 \sum_{n:N/2\le nm\le2N}\min(1,B/(1+|nm-N|))
       \le2+\frac{2B}{m}H_{2N+1}.                         \tag{12}
\]

Multiplying by m^(-1/2)/sqrt N and summing m<=K gives

\[
 O\left(N^{-1/2}\sqrt K+N^{-1/2}\ell^{-1}L\right)
        =O(N^{-1/4}+N^{-1/6}L).                            \tag{13}
\]

This includes exact products nm=N and every slowly varying term. No
random sign or unproved cancellation is used to pay them.

### 5.5 Complete collected result

Equations (11)-(13) prove

\[
 \mathbb E_I(WXY_K)
  =\cos\delta\left[\frac34\sum_{m\le K}m^{-3/2}+\frac18\right]
                  +O(N^{-1/6}L).                         \tag{14}
\]

Divide by (6). The missing diagonal tail is O(K^(-1/2))=O(N^(-1/4)).
Thus

\[
 \langle XY_K\rangle_W
  =\cos\delta\left[\frac12\sum_{m\ge1}m^{-3/2}+\frac1{12}\right]
                  +O(N^{-1/6}L).                         \tag{15}
\]

Restoring B-B_K with (10) yields c_*+O(N^(-1/12)L^(3/2)). The proof has
not inferred this equality from a diagonal of a full/full mean square.
It paid the tail first, then every mixed ratio and product contribution.

## 6. Transfer to the actual normalized coefficients

By (3), (4),

\[
 \frac{2s_d}{N^{3/2}}\mathcal C_N
 =\left\langle \frac{D_0+c_N}{\sqrt N}
          \frac{2(\beta_d+c_N)}{N}\right\rangle_W.
\]

Here D_0/sqrt N=sqrt(a/N) X and

\[
 \frac{2\beta_d}{N}
  =\Re\{e^{i\chi}[(a/N)e^{i\delta}B+e^{-i\delta}C/N]\}
       +O(N^{-1-\kappa}).
\]

The factor (a/N)^(3/2)=1+O(1/N) is uniform. Its discrepancy costs at most
O(N^(-5/6)L^(1/2)) by (7) and ||B||_2=O(1). The C/N contribution is
O(N^(-1/6)L) by (7),(9). Terms containing c_N/sqrt N cost O(N^(-1/6))
when paired with the bounded endpoint norm; terms containing c_N/N and X
are smaller. The endpoint polynomial error is smaller still. These bounds
can alternatively be obtained by direct expansion and Cauchy--Schwarz;
no sign of the correction is assigned.

Every discrepancy is absorbed by O(N^(-1/12)L^(3/2)). This proves (2).
The constants do not depend on nu or d: the endpoint identity (4), with
its degree-uniform error, was used before doing the mixed-moment analysis.

## 7. The gate correction and residual are separate arithmetic obligations

Let Q_- =(-Z_0)_+. Since (Z_0)_+=Z_0+Q_-, identity (1) follows pointwise.
One may further split

\[
 \mathcal D_N=\mathcal G_N-\mathcal V_N,\quad
 \mathcal G_N=\langle Q_-(Z_d)_+\rangle_W,\quad
 \mathcal V_N=\langle Q_-(-Z_d)_+\rangle_W.
\]

Both G and V are nonnegative but their difference has no predetermined sign.
Thus

\[
 \boxed{S_N=\mathcal C_N+\mathcal G_N-(\mathcal V_N+U_N).}  \tag{16}
\]

This is the SAME gate and same surplus, not a new probability weight.
The negative-central gate discards a positive contribution to the ordinary
product whenever Z_0 and Z_d are both negative. Conversely it discards a
negative ordinary product when Z_0<0<Z_d. The two effects remain in (16).

Positive ordinary covariance alone is insufficient. As an exact control,
give vectors (Z_0,Z_d)=(-2,-10) and (1,-1) equal probability. Then
E(Z_0 Z_d)=19/2>0 but E((Z_0)_+ Z_d)=-1/2. Similarly, a single coefficient
vector (1,-2,3) has a positive gated endpoint but negative common-minimum
surplus. These controls are included in the tests; they are not source models.

For finite N=64 the new arithmetic ledger gives, rounded outward:

| Window | G: removed negative products | V: removed positive products | U: remaining coefficient loss |
|---|---:|---:|---:|
| First | [0.98336393,1.01286107] | [1.23059305,1.24727617] | [0.60823859,0.68492076] |
| Second | [0.80635404,0.83829555] | [4.79490119,4.82279291] | [0.21288538,0.28901892] |

All interval uncertainties are retained. The sign of D=G-V is certified
negative in both windows, but no asymptotic sign for D is inferred.

## 8. Complete finite quadrature and independent check

The source nodes are the unchanged 80-digit arithmetic dataset of the original
whole-window package. They describe 1,025 nodes on each window, enclosing W and
D_0,...,D_6. This stage uses only D_0,...,D_5, degree five, the same exact
source-sized scales, and the same outward payment 0.271900134725. No sampled
zero locations or new source values enter the calculation.

### Primary extension

The byte-identical independent affine module from the positive-central package
supplies interval operations and a direct product-rule bound for the SECOND
derivatives of the explicit finite sums. The new builder adds the moments in
(1) and (16). It does not alter or rerun a different mathematical test.

On each original cell of length h, exact endpoint intervals plus
h^2 sup|f''|/8 enclose the error of the smooth affine interpolants for W,Z_j.
All intersections of the six affine coefficients, the zero of the central
coefficient, and the zero of the outer coefficient are inserted. On every
piece, the selected minimum and both signs are checked at both ends; affine
linearity justifies the entire branch. The polynomial products are integrated
exactly. Identity (1) and both decompositions in (16) hold exactly for the
piece integrals and are checked without decimal tolerances.

The positive and negative parts are 1-Lipschitz, as is the pointwise minimum.
For a product W F G with model w f g and errors e_w,e_f,e_g, a valid bound is

\[
 e_w(U_f+e_f)(U_g+e_g)
  +U_w[e_f(U_g+e_g)+U_f e_g].                              \tag{17}
\]

For the residual Z_d-min Z, its error is at most e_d+max_j e_j. Every mixed
error term is included. The source-error payment inside Z_j is a constant
and is not differentiated. All 2,048 original cells are retained. Known
nonnegative integral quantities can be intersected with [0,infinity); signed
moments are not clipped.

### Separate whole-cell implementation

A second standalone program imports neither the primary builder nor any
parent interval or acceptance code. It reconstructs the scales, source
nodes and second-derivative majorants directly. On each complete cell it
bounds the actual smooth function by the hull of its endpoint intervals
plus the interpolation remainder, then performs the positive-part, minimum
and product interval operations on the WHOLE cell. These are coarser bounds,
not sampled values or a repeated affine arrangement.

It confirms positive bilinear and gated surplus in both windows. Its
three-term surplus bounds are >43.9350 and >42.1352; its direct net bounds
are >45.2821 and >43.9515. It also certifies D<0 in both windows. It does
not reproduce the primary tighter numerical bounds. The two implementations
share the arithmetic source data and written error theorems, not the new
acceptance code.

## 9. A precise remaining same-height comparison

Define the signed residual relative to the new positive component by

\[
 \mathcal R_N=U_N-\mathcal D_N
             =U_N+\mathcal V_N-\mathcal G_N.
\]

Then S_N=mathcal C_N-mathcal R_N EXACTLY. The unresolved sufficient
asymptotic condition can now be stated with an explicit positive constant:

\[
 \boxed{
 \limsup_{N\to\infty}\max_{\nu\in\{0,1\}}
       \frac{2s_d}{N^{3/2}}\mathcal R_N < c_*.
 }                                                        \tag{18}
\]

It would imply S_N>0 in both families for all sufficiently large N. A
suitable unbounded subsequence with a strict compatible comparison would
also suffice for the corresponding selection statement. Formula (18) is
NOT proved here. In particular an absolute norm upper bound for M_N or
for mathcal D_N does not establish the required signed lower contribution.
The finite values cannot be extrapolated.

The new result provides a positive arithmetic baseline rather than another
unproved positive-marginal assumption. The new quantitative endpoint
truncation (10) is also valid with the gate retained, and can be used to
analyze the remaining signed correction with an endpoint sum through
floor(sqrt N). The central sum and every intermediate coefficient remain
complete; no estimate for their joint loss is supplied by this truncation.

Even unbounded selection would still leave the existing winding, full
critical-line multiplicity census and absolute initial-count closure.
No new zero-free region, zero count, RH conclusion or novelty priority is
asserted. The theorem is a written analytic argument awaiting independent
review, not proof-assistant formalization.

## 10. Verification and provenance

The original 17-member positive-central archive is authenticated unchanged.
Its source-node gzip and independent affine helper are copied byte-for-byte
as declared runtime dependencies. All new files have distinct names. The
main result is supported by exact finite ledger checks and a separate
whole-cell implementation; tests do NOT establish (2) by sampling cutoffs.
No new high-cutoff source scan or elementary source quadrature is run.

The constant c_* is enclosed by summing 16,384 elementary n^(-3/2) terms
with rational square-root bounds. The unsummed tail lies between
2/sqrt(16385) and 2/sqrt(16384). Pi and cosine use convergent rational
series. An exploratory display-only mpmath evaluation of zeta(3/2) was
used while planning; it supplies no accepted constant or source input.
There are no new evaluations of the critical-strip zeta source or a
zero-count routine.

The latest checkpoint REPORT.md and DERIVATION.md were read via the laptop
connector at

    C:/Users/ollet/Documents/Codex/2026-07-03/l/work/rh_compute/tmp/
    rh_gated_endpoint_budget_20260915/delivery/rh_gated_endpoint_budget_20260915/

They are read dependencies, not newly authenticated laptop archives. This
stage does not claim a replay of the user's 766 pins. No laptop process,
file write, desktop change, repository update or bookmark edit was started.
The external clean-extraction receipt records actual runs and hashes.

## References

1. Included unchanged RH_Positive_Central_Weight_2026-09-15_v1.zip:
   source definitions, normalized coefficients, gate and error payment,
   original nodes and whole-cell interpolation proof.
2. Latest user checkpoint, rh_gated_endpoint_budget_20260915/DERIVATION.md,
   read in full: endpoint identity, degree-uniform endpoint bound and exact
   endpoint-surplus decomposition. The needed statements are restated above.
3. NIST DLMF 2.3(i), integration by parts:
   https://dlmf.nist.gov/2.3 . The specific short-window and mixed-term
   estimates are proved in Sections 3–6, not attributed to this reference.
4. NIST DLMF 25.2(i), absolutely convergent Dirichlet series for zeta(s)
   when Re(s)>1: https://dlmf.nist.gov/25.2 . Used only to name the positive
   constant sum n^(-3/2); no nontrivial-zero fact is needed for it.
5. NIST DLMF 3.3(i), real interpolation remainder:
   https://dlmf.nist.gov/3.3 . Applied to smooth arithmetic quantities,
   never directly to a nonsmooth positive part or minimum.

Third-party attribution is retained. No general reuse permission is granted.
