# Signed endpoint energy: only one half of the endpoint square can clip the gate

**15 September 2026 · Version 1**  
**Martin Ollett / TWO HANDS NETWORK LTD**  
**Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.**

## 1. Result, unchanged inputs, and scope

The latest coefficient-shape checkpoint splits the same normalized surplus into
a signed endpoint contribution, endpoint clipping, and the defect of an interior
coefficient below both endpoints. Its uniform clipping allowance uses the full
endpoint second moment. The pointwise inequality actually needs only the
POSITIVE endpoint square. This note determines that one-sided moment on the
actual cutoff-window families.

No source, gate, weight, coefficient normalization, approximation degree,
remainder payment, or interior-defect definition is changed.

The new asymptotic theorem is, uniformly in the two original window families,

    <(Y_N)_+^2>_W -> v_+,
    <(-Y_N)_+^2>_W -> v_-,

where

    v_++v_-=v_* = pi^2/12 + cos(pi/4)/12,
    v_+ = v_*/2 + [8 cos(pi/8)/(9 pi)] H,
    v_- = v_*/2 - [8 cos(pi/8)/(9 pi)] H,

and the positive convergent arithmetic product is

    H = product_p sum_(k>=0)
                 (2k+1)*binom(2k,k)^2 / (16^k*p^(2k)).

Rigorous rational bounds give

    0.8221428107245155 < v_+ < 0.8221428107282163,
    0.0592497877947760 < v_- < 0.0592497877984766.

The endpoint's negative square makes a genuinely nonzero limiting contribution
to v_*. It cannot cause endpoint clipping and need not be charged to that cost.

Consequently the asymptotic allowance for the still-unbounded signed quantity
R_N-Q_N increases from c_*/2-v_*/4 to

    mu_+ = c_*/2-v_+/4 > 0.4363.

On the explicit integer subsequence N_m=floor(exp(m)), m>=5, retaining the
unchanged degree rule and scale gives the sharper allowance

    mu_edge = c_*/2-v_+/(4 sqrt(e)) > 0.5172.

These numbers are SUFFICIENT TARGETS, not proved upper bounds for R_N-Q_N.
No unbounded selection or zero-count closure follows from this note. There is
no explicit onset for the asymptotic limits. The finite N=64 calculation below
replays the existing one-sided clipping bound; it is not an enlarged region or
a higher-cutoff scan.

## 2. Definitions and the exact scalar clipping identity

For N>=64 retain

    J=floor((N/64)^(1/3)), M=N-J-1, d=ceil(log(N+1)),
    I_(N,nu)=[(1+2nu)/4-1/(100(J+1)),
              (1+2nu)/4+1/(100(J+1))], nu=0,1,
    a=N+r, t=2*pi*a^2,
    exp(i chi)=(-1)^(N+nu) exp(i theta0(t)),
    W=(1+cos chi)^2, <f>_W=mean_I(Wf)/mean_I(W).

All coefficients and phases use this same r. Let

    s_j=B_(d,j)(d), Z_j=(beta_j+c_N)/s_j,
    c_N=H_J-E_N, H_J=(2/3)(J+1)-503/1000,
    E_N=(e^2/9) N^(-(log16-5/2))+(log N+2)/(4*pi*N).

The logarithmic approximation and source remainder bounds are inherited,
including the whole source shift c_N. Define

    X=Z_0/sqrt(N), V_j=(2s_d/N)Z_j, Y=V_d,
    kappa_N=2s_d/sqrt(N), V_0=kappa_N X, P=X_+,
    E_end=min(V_0,Y),
    Delta=max(0,max_(1<=j<d)(E_end-V_j)),
    R_N=<P Delta>_W, Q_N=<|X|Y>_W/2,
    C_N^clip=<P(Y-kappa_N X)_+>_W.

The symbol Q_N in this note is the EXACT absolute-value correlation. Its
previous rational approximation has its separately proved vanishing transfer
error; it is not declared identical to the exact correlation.

The pointwise identity is

    min_j V_j=Y-(Y-kappa_N X)_+-Delta.

Thus the original normalized surplus satisfies exactly

    S_tilde_N=<X_+ min_j V_j>_W
             =<XY>_W/2+Q_N-C_N^clip-R_N.                 (1)

For all real x,y and kappa>0,

    0<=x_+(y-kappa*x)_+ <= y_+^2/(4*kappa).               (2)

If either x<=0 or y<=0 the left side is zero. In the remaining nonzero region,

    x(y-kappa*x)=y^2/(4*kappa)-kappa*(x-y/(2*kappa))^2.

The constant is sharp at x=y/(2*kappa)>0. This note does not replace it by
a smaller source-independent scalar constant. It determines the asymptotic
mean of its correct numerator y_+^2.

## 3. Endpoint approximation and the justified order of limits

Set delta=pi/8. The inherited uniform endpoint identity is

    Y_N=Re{exp(i chi)[(a/N) exp(i delta) B_N
                         +exp(-i delta) C_N^0/N]}
          +2c_N/N+O(N^(-1-kappa_0)),
    B_N=sum_(n<=M)n^-1 exp(-it log n),
    C_N^0=sum_(n<=M)exp(-it log n),
    kappa_0=log16-5/2>1/4.

The uniform polynomial error is retained. The coefficient shift is O(N^(1/3)).
For every FIXED integer K, define

    Y_(K,N)=Re(exp(i chi+i delta) B_K),
    B_K=sum_(n<=K)n^-1 exp(-it log n).

The complete ratio-phase estimates imply

    limsup_N ||Y_N-Y_(K,N)||_(L2(W)) <= sqrt(8/(3K)).       (3)

They pay every endpoint tail index, every off-diagonal ratio, C_N^0/N, the
a/N normalization, c_N/N, and the polynomial endpoint error. They imply
uniform boundedness of the endpoint L2 norms. Their derivation is reproduced
in the bundled predecessor references [D1,D2]; it is not inferred from a
numerical second moment or a diagonal-only lower bound.

For real u,v,

    |u_+^2-v_+^2| <= |u-v|(|u|+|v|).

Cauchy--Schwarz therefore gives

    |<Y_N,+^2>-<Y_(K,N),+^2>|
       <= ||Y_N-Y_(K,N)||_2 (||Y_N||_2+||Y_(K,N)||_2).     (4)

The same estimate holds for the negative parts. Hence (3) controls both
one-sided second moments, not merely the ordinary second moment.

For fixed K, every prime appearing in B_K is in a fixed finite set. The
joint height variables (chi, exp(-it log p)) have the following testing limit:
each FIXED trigonometric monomial has the normalized torus average in the
limit N->infinity. Its phase is h*theta0-t*log Q for fixed integer h and
fixed positive rational Q. Its derivative is

    4*pi*(N+r)*(h*log(N+r)-log Q).

Unless h=0,Q=1, its modulus is eventually bounded below by a constant times
N (or N log N for h!=0). Integrating by parts on at most two monotone pieces
gives decay since N*|I| is of order N^(2/3). Constant modes are kept exactly.
The parity factor has modulus one and does not affect the estimates.

The functions (Re(exp(i chi+i delta) B_K))_+^2 are CONTINUOUS bounded
functions on this fixed torus. Finite Fejer means approximate them uniformly:
positivity and unit mass of the product Fejer kernel, together with uniform
continuity, give uniform approximation. One first fixes an approximation and
then takes N->infinity. Its uniform error bounds the height and torus
integrals. No derivative of the nonsmooth positive part is used.

Multiplication by the continuous weight W and division by mean_I(W)->3/2
therefore justify the finite-torus limit for these one-sided quantities.
Only AFTER that fixed-K limit is taken does (3)-(4) allow K->infinity.

This is a limit of integrals on the ACTUAL height windows. It does not replace
the source at any fixed height by freely chosen prime angles. It does not
justify a growing-support nonlinear central gate by a fixed-support argument.

## 4. Exact integration of the common endpoint angle

For a fixed complex number B, put C=exp(i delta)B. If B!=0, write
C=|B|exp(i alpha) and change variable u=chi+alpha. The positive part is
supported on -pi/2<u<pi/2 modulo 2pi. Direct integration gives

    mean (cos u)_+^2 = 1/4,
    mean cos(u)*(cos u)_+^2 = 2/(3*pi),
    mean cos(2u)*(cos u)_+^2 = 1/8,

and both corresponding sine integrals vanish. Using
W=3/2+2cos chi+(1/2)cos 2chi and dividing by 3/2 yields

    mean_chi[ W (Re(exp(i chi+i delta)B))_+^2 ]/(3/2)
     = |B|^2/4
       +[8/(9*pi)] |B| Re(exp(i delta)B)
       +Re(exp(2i delta)B^2)/24.                          (5)

At B=0 both sides vanish, so no phase singularity is introduced.

For the negative part the middle term reverses sign, while the other two
terms remain unchanged. In particular the two sides add to the known
ordinary second-moment angular formula. The mean of |Y| or of Y_+ is not
being substituted for its squared mean.

## 5. The arithmetic modulus correlation has a convergent product

On any finite prime torus, unique factorization makes q_n mutually
orthogonal characters. Hence

    integral |B_K|^2 = sum_(n<=K)n^-2,
    integral B_K^2 = 1.                                  (6)

To evaluate the remaining correlation define, for a finite prime set P,

    A_P(q)=product_(p in P) (1-q_p/p)^-1.

For every fixed finite P this is an absolutely and uniformly convergent
sum over P-smooth integers. If P contains all primes <=K, then all n<=K
appear in that sum, and orthogonality gives

    ||A_P-B_K||_2^2
      =sum_(n>K, P-smooth) n^-2 <= 1/K,
    ||A_P||_2,||B_K||_2 <= sqrt(zeta(2)).                 (7)

The nonlinear map z -> |z|z obeys

    ||z|z-|w|w| <= (|z|+|w|)|z-w|.

Thus the corresponding integrals differ by at most 2sqrt(zeta(2))/sqrt(K),
uniformly over all such finite P. This is an L2-controlled passage, not a
formal Euler product at a boundary where absolute convergence fails.

For each fixed P, the correlation factors exactly:

    integral |A_P|A_P
      =product_(p in P) integral
           (1-q/p)^(-3/2)(1-conjugate(q)/p)^(-1/2).       (8)

The binomial series for each factor converges absolutely because 1/p<1.
Taking its constant Fourier coefficient gives the real positive factor

    h(p^-2)=sum_(k>=0)
             ( (3/2)_k (1/2)_k / (k!)^2 ) p^(-2k)
           =sum_(k>=0)
             (2k+1) binom(2k,k)^2 /(16^k p^(2k)).         (9)

The local coefficients satisfy

    a_0=1,
    a_(k+1)/a_k=1-1/[4(k+1)^2] < 1.

Thus h(x)=1+O(x) on 0<=x<=1/4, and product_p h(p^-2) converges to a finite
positive H since sum_p p^-2 converges. Equations (7)-(9) prove

    lim_K integral |B_K|B_K = H.                         (10)

No use of an Euler product for zeta at real part one or one half is made.
All products used as functions are finite-prime products; the constant
product in (10) has absolutely summable local deviations.

Combining (3)-(6),(10), and sum n^-2=pi^2/6 proves

    v_+ = pi^2/24+cos(2delta)/24 +8cos(delta)H/(9pi),
    v_- = pi^2/24+cos(2delta)/24 -8cos(delta)H/(9pi).        (11)

This establishes the new one-sided moment theorem. The common shift,
normalizer, and source approximation errors disappear only through the
paid endpoint L2 approximation in Section 3.

## 6. Rigorous evaluation of the constant product

The primary constant calculation uses primes p<=4096 and orders k<=32
in (9), with directed rational arithmetic. The local unsummed tail is at most

    next_term/(1-p^-2).

For a rapid certified bound on the prime tail, factor out its first-order
contribution:

    H=zeta(2)^(3/4)
           product_p [ h(p^-2)(1-p^-2)^(3/4) ].           (12)

The equality follows from the absolutely convergent Euler product for
zeta(2), not one at the critical-line exponent.

For 0<=x<=1/4, the decreasing positive coefficients give

    1+3x/4 <= h(x) <= 1+3x/4+(45/64)x^2/(1-x).

Using log(1+u)>=u-u^2/2, log(1+u)<=u,
and the positive series for -log(1-x), one obtains

    -(25/32)x^2
       <= log h(x)+(3/4)log(1-x)
       <= (9/16)x^2.

In particular its absolute value is <=x^2. Therefore

    |sum_(p>B) log[h(p^-2)(1-p^-2)^(3/4)]|
       <=sum_(n>B)n^-4 <=1/(3B^3).                       (13)

The code encloses the exponential of that tail by
[1-eps,1/(1-eps)], eps=1/(3B^3). Quarter powers in (12) are enclosed with
nested integer-square-root bounds; pi comes from Machin's arctangent identity
and alternating rational-series tails. No hypergeometric evaluator is used.

The independent implementation uses p<=2048, orders k<=30, the closed
binomial formula rather than the primary coefficient recurrence, and its
own exact interval arithmetic. Its wider enclosure contains the primary
one. Both pay the analytic prime tail.

The existing c_* constant is re-enclosed by 16,384 rational square-root
bounds for n^-3/2 and a positive integral tail. This is an evaluation of an
absolutely convergent real constant, not a zeta-height oracle.

Resulting conservative intervals are:

    H in [1.459219741835677, 1.459219741849835],
    mu_+ in [0.436339251747828, 0.436339361878736],
    mu_edge in [0.517211249087636, 0.517211359218180].

The widths in the latter two intervals are mostly from the inherited-style
simple tail enclosure of sum n^-3/2. Full rational endpoints are saved.

## 7. The improved clipping budget and the unchanged remaining inequality

The earlier signed baseline and endpoint limits give

    <XY>_W=c_*+o(1), <Y_+^2>_W=v_++o(1).

The original degree rule implies kappa_N>1 for every N>=64. A direct check:
if T_d=cosh(d/2)-s_d, the positive even tail satisfies

    T_d<(16/15)(e/4)^(2d+2),
    2 T_d exp(d/2)<(121/120)(605/768)^d<1.

Here e<11/4 and sqrt(e)<5/3 suffice. Thus 2s_d>exp(d/2) and

    kappa_N>sqrt((N+1)/N)>1.                              (14)

From (1)-(2),

    S_tilde_N >= c_*/2+Q_N-R_N-v_+/(4kappa_N)+o(1).        (15)

The o(1) is uniform in the two windows; division by kappa_N>=1 preserves
it. Therefore a sufficient all-cutoff comparison is

    limsup_N max_nu (R_N-Q_N) < mu_+=c_*/2-v_+/4.          (16)

The conservative target 0.4363 can replace 0.4215. It is an enlarged allowed
budget for an UNPROVED signed combination. It is not a newly established
bound on that combination. The exact rational representation of Q can be
substituted only with its inherited paid transfer error.

The improvement in the permitted limit is exactly v_-/4, enclosed between
0.0148124469486940 and 0.0148124469496192. No positivity is inferred for Q,
and the interior defect is not declared zero or concave.

## 8. A declared unbounded cutoff subsequence uses the scale already present

The bound (15) keeps kappa_N rather than replacing it by its worst-case lower
bound one. Without changing any scale, degree, window or source, take

    N_m=floor(exp(m)), integer m>=5.

Then m<log(N_m+1)<m+1, so d_(N_m)=m+1. Also
N_m/exp(m)->1 and the explicit positive cosh-tail estimate gives

    kappa_(N_m)=2s_(m+1)/sqrt(N_m) -> sqrt(e).              (17)

Hence along BOTH windows of this particular unbounded sequence, (15) has
the limiting allowance

    mu_edge=c_*/2-v_+/(4sqrt(e)) >0.5172.                  (18)

The subsequence is selected from the known degree ceiling only, before any
source-sign evaluation. No source value at these cutoffs was calculated.
It gives another sufficient target, NOT existence of favorable coefficients
there:

    limsup_m max_nu (R_(N_m,nu)-Q_(N_m,nu)) <0.5172        (19)

would suffice for the corresponding selection statement. The requirement
(19) remains unproved. Winding, multiplicity, boundary compatibility and
absolute initial-count closure would still follow as separate obligations.

This subsequence restriction changes the cutoffs on which a future theorem
would be needed; it does not by itself make the signed remainder favorable.
No interpolation between those cutoffs is claimed.

## 9. Finite replay: same source bounds, no replacement by asymptotic constants

The primary and separate programs read a compact export of the SAME 2,048
closed source cells used in the incoming joint-rational packet. Each cell
retains W, X, all six V_j, and exact rational height endpoints. The source
is N=64, d=5 with complete payment 0.271900134725. No measured function,
new source node, zero catalogue, old acceptance threshold or rational-tree
output is used to determine the new finite aggregates.

The exact scale is kappa_64=2s_5/8. For each cell the programs evaluate:

    Y_+^2, Y_-^2,
    clipping cap Y_+^2/(4kappa_64),
    P(Y-kappa_64 X)_+,
    P max(0,min(V_0,Y)-V_j : 1<=j<5).

They integrate entire image intervals, not endpoint samples. Their source
interpolation errors are inherited in those images. Summing the same closed
cell cover and using a separately positive weight-mass enclosure gives

| Window | Positive endpoint square | Negative endpoint square | Interior loss upper | Fully paid one-sided-cap surplus lower |
|---|---|---|---|---|
| First | [0.78200244,0.84798440] | [0.02313903,0.02879249] | 0.000003538 | >0.9678 |
| Second | [0.85738379,0.92742132] | [0.06650400,0.07912578] | 0.000076525 | >0.9139 |

These reproduce the latest finite coefficient-shape component bounds.
They are NOT new or stronger physical finite certificates. In particular
the constants v_+ and v_- are NEVER substituted for finite N=64 moments.
Every cell, including its adverse signs and interior indices, is retained.
No concavity or unimodality assumption is used.

The primary is directed rational arithmetic; the independent replay uses
unrounded Fraction arithmetic for the finite sums and its own operations.
They share the inherited source-cell enclosures and the written source
bounds, not a second evaluation of the source.

## 10. Reproduction and exact meaning of verification

The builder produces the constant enclosure and finite ledger separately.
A second program rederives the constants from a different finite product and
reconstructs the finite cell arithmetic without importing the primary code.
Named unit tests exercise the exact angular constants, local binomial series,
prime-tail bounds, one-sided cap including its equality cases, the degree-edge
subsequence, exact scale roster, all cell boundaries, and input tamper guards.

The new analytic theorem rests on Sections 3-8, not on a finite sample of
large cutoffs. No numerical onset, proof-assistant formalization, unbounded
sign for Q or R-Q, new zero census or RH proof is claimed.

Only new files in the assistant's working container are written. The laptop
was used to read the two latest reports and derivations. No laptop process,
desktop change, repository edit, bookmark update or historical-pin audit
was performed. The inherited source archive was authenticated; source
integrations and old test suites were not rerun.

## References and attribution

[D1] Included exact predecessor: RH_Rational_Gate_Derivation_2026-09-15_v1.md,
Sections 2-3. Endpoint approximation, fixed-K L2 transfer, weight mass and
ordinary second-moment limit. It does not already contain theorem (11).

[D2] Included exact predecessor: RH_Signed_Endpoint_Resonance_Derivation_2026-09-15_v1.md.
Signed ordinary baseline c_*, complete actual-phase ratio bounds and source shifts.

[D3] User's REPORT.md and DERIVATION.md in
C:/Users/ollet/Documents/Codex/2026-07-03/l/work/rh_compute/tmp/rh_coefficient_shape_20260915/delivery/rh_coefficient_shape_20260915/
read in full. Source of the exact clipping/interior split, its verified finite
bounds, and the rejected concavity/unimodality shortcuts. Its archive and pins
were not reaudited in this continuation.

[D4] User's REPORT.md and DERIVATION.md in
.../rh_joint_complex_transport_20260915/delivery/rh_joint_complex_transport_20260915/
read in full. Its complex-domain and polynomial-average approximation conclusions
remain unchanged; no giant polynomial is built here.

[S1] NIST DLMF 4.6(ii), binomial expansion:
https://dlmf.nist.gov/4.6 .
[S2] NIST DLMF 27.4, absolutely convergent Euler products:
https://dlmf.nist.gov/27.4 .
[S3] NIST DLMF 25.6(i), zeta(2)=pi^2/6:
https://dlmf.nist.gov/25.6 .
[S4] NIST DLMF 1.8, Fourier series/Fejer means:
https://dlmf.nist.gov/1.8 .
[S5] NIST DLMF 25.2(i), the absolutely convergent real series for zeta(3/2):
https://dlmf.nist.gov/25.2 .

The source-specific one-sided limit and its constants are derived above,
not attributed to these general reference pages. The binomial and Euler products
are used only within their stated convergence domains. No novelty priority or
general reuse permission is asserted; third-party attribution is retained.
