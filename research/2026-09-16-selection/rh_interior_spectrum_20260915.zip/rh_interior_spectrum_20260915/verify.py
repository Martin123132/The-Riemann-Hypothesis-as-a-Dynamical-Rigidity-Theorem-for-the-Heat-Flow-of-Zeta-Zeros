"""Exact algebra, incoming provenance and interval replay checks."""
from fractions import Fraction as F
from math import comb,factorial
from itertools import product
from pathlib import Path
import gzip,json,sys
from intake import HERE,sha,write

def load(name):return json.loads((HERE/name).read_text())
def interval(x):return list(map(F,x['interval'] if isinstance(x,dict) else x))
def overlap(a,b):
    a=interval(a);b=interval(b);return max(a[0],b[0])<=min(a[1],b[1])
def f(s):return s/2+4*s*s-2*s**3
checks=[];counts={}
def check(name,ok):
    assert ok,name;checks.append(name)

def recursive_overlap(a,b):
    if isinstance(a,dict):
        if 'interval' in a:
            assert overlap(a,b);return 1
        return sum(recursive_overlap(v,b[k]) for k,v in a.items() if k not in ['digits','display'])
    if isinstance(a,list):
        assert len(a)==len(b);return sum(recursive_overlap(x,y) for x,y in zip(a,b))
    assert a==b,(a,b);return 0

def main():
    inp=HERE/'incoming/RH_Endpoint_Sign_Energy_2026-09-15_v1'
    manifest=json.loads((inp/'RH_Endpoint_Sign_Manifest_2026-09-15_v1.json').read_text())['files']
    check('incoming_21_members_unchanged',len(manifest)==21 and all(sha(inp/p)==h for p,h in manifest.items()))
    compact=json.loads(gzip.decompress((inp/'RH_Endpoint_Sign_Cell_Input_2026-09-15_v1.json.gz').read_bytes()))
    original=json.loads(gzip.decompress((HERE/'inputs/joint.json.gz').read_bytes()))
    same=all(compact[k]==original[k] for k in ['N','degree','scales','source_payment'])
    for a,b in zip(compact['windows'],original['windows']):
        same= same and all(a[k]==b[k] for k in ['nu','r']) and len(a['cells'])==len(b['cells'])
        same= same and all(all(c[k]==e[k] for k in ['i','r','W','X','V']) for c,e in zip(a['cells'],b['cells']))
    check('all_2048_source_cells_match_previous_sealed_ledger',same)
    check('incoming_tests_and_byte_replay',load('INCOMING_REPLAY.json')['passed'])
    check('first_calculation_preserved_identically',sha(HERE/'SPECTRUM_70.json')==sha(HERE/'SPECTRUM_70_R1.json'))
    check('separate_calculation_preserved_identically',sha(HERE/'INDEPENDENT_CONSTANTS.json')==sha(HERE/'INDEPENDENT_CONSTANTS_R1.json'))

    n=0
    for d in range(1,41):
        for j in range(d+1):
            weights=[F(comb(j,k),comb(d,k))*F(d**(2*k),4**k*factorial(2*k)) for k in range(j+1)]
            ratios=[]
            for k in range(j):
                r=F((j-k)*d*d,(d-k)*4*(2*k+1)*(2*k+2))
                assert weights[k+1]/weights[k]==r;ratios.append(r);n+=1
            assert all(a>b for a,b in zip(ratios,ratios[1:]))
            for z in [F(-1,3),F(1,2),F(2)]:
                exact=sum((F(comb(j,k),comb(d,k))*(d+z)**(2*k)/F(4**k*factorial(2*k)) for k in range(j+1)),F(0))
                prob=sum((w*(1+z/d)**(2*k) for k,w in enumerate(weights)),F(0))
                assert exact==prob
    counts['exact_consecutive_ratios']=n
    check('positive_ratio_and_polynomial_identity',True)
    check('energy_threshold',f(F(1,6))==F(5,27))
    check('gated_threshold',f(F(1,3))==F(29,54))
    check('upper40percent_margin',f(F(7,20))==F(2317,4000)<F(3,5))
    check('gated_first_decay_exponent',F(5,12)-F(17,40)==-F(1,120))
    check('gated_second_decay_exponent',F(5,6)-F(17,20)==-F(1,60))
    check('weaker_prime_tail_valid',F(9,32)+F(3,8)/(1-F(1,2))==F(33,32)<2 and F(45,64)/(1-F(1,2))-F(3,8)==F(33,32))

    n=0
    for values in product(map(F,[-2,-1,0,1,2]),repeat=4):
        for shifts in product(map(F,[-1,0,1]),repeat=2):
            updated=list(values);updated[2]+=shifts[0];updated[3]+=shifts[1]
            assert abs(min(values)-min(updated))<=max(map(abs,shifts));n+=1
    counts['minimum_transport_cases']=n
    check('full_minimum_lipschitz_transport',True)
    check('vanishing_error_not_free_under_growing_gate',F(100)*F(1,100)==1)

    a=load('SPECTRUM_70_R1.json');b=load('SPECTRUM_100.json')
    counts['spectral_overlap_fields']=recursive_overlap(a,b)
    check('all_spectral_precision_fields_overlap',True)
    rows={r['s']:r for r in b['rows']}
    indep=load('INDEPENDENT_CONSTANTS_R1.json')
    check('independent_fraction_constants_overlap',all(overlap(rows['1/4'][k],v) for k,v in indep['values'].items()))
    endpoint=json.loads((inp/'RH_Endpoint_Sign_Constants_2026-09-15_v1.json').read_text())['values']
    check('endpoint_energy_agrees_with_incoming',overlap(rows['1/2']['positive_energy'],endpoint['endpoint_positive_energy']) and overlap(rows['1/2']['negative_energy'],endpoint['endpoint_negative_energy']))
    check('three_interior_energy_gaps_strictly_positive',all(interval(rows[s]['mean_square_endpoint_difference'])[0]>0 for s in ['1/5','1/4','1/3']))
    check('negative_energies_retained',all(interval(r['negative_energy'])[0]>0 for r in rows.values()))
    check('n1_floors_positive',all(interval(rows[s]['first_mode_difference_floor'])[0]>0 for s in ['1/5','1/4','1/3']))
    check('known_endpoint_exact_difference_zero_enclosed',interval(rows['1/2']['mean_square_endpoint_difference'])[0]<=0<=interval(rows['1/2']['mean_square_endpoint_difference'])[1])
    for r in rows.values():
        lo1,hi1=interval(r['positive_energy']);lo2,hi2=interval(r['negative_energy'])
        assert overlap([lo1+lo2,hi1+hi2],r['total_energy'])
    check('one_sided_energies_sum_to_total',True)
    covariance={(v['s'],v['t']):v['value'] for v in b['covariance']}
    check('covariance_symmetric',all(covariance[(s,t)]==covariance[(t,s)] for s,t in covariance))

    a=load('FINITE_TRANSPORT_70.json');b=load('FINITE_TRANSPORT_100.json')
    counts['finite_overlap_fields']=recursive_overlap(a,b)
    check('all_finite_precision_fields_overlap',True)
    check('finite_exact_roster_preserved',sum(len(w['rows']) for w in b['windows'])==2048 and all(all(r['r']==c['r'] and r['i']==c['i'] for r,c in zip(w['rows'],old['cells'])) for w,old in zip(b['windows'],compact['windows'])))
    check('finite_shortening_keeps_complete_minimum',b['first_shortened_index']==3 and b['cutoff']==8)
    check('finite_paid_margins_positive',interval(b['windows'][0]['moments']['restored'])[0]>F('0.4706') and interval(b['windows'][1]['moments']['restored'])[0]>F('0.8927'))
    check('finite_costs_not_replaced_by_zero',all(interval(w['moments']['error_cap'])[0]>0 for w in b['windows']))
    check('scope_no_sign_claim',not load('SPECTRUM_100.json')['scope']['joint_R_minus_Q_bounded'])
    write(HERE/'VERIFICATION.json',dict(passed=True,named_checks=len(checks),checks=checks,counts=counts,
        formal_proof=False,new_auxiliary_evaluations=0,whole_cell_arithmetic_recomputed=True))
    print(json.dumps(dict(passed=True,checks=len(checks),counts=counts)))

if __name__=='__main__':main()
