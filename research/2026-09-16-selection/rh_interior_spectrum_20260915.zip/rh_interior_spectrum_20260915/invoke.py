"""Run unchanged source with explicit LF text serialization on Windows."""
import io
from pathlib import Path
import runpy
import sys

original=io.open
def lf_open(file,mode='r',buffering=-1,encoding=None,errors=None,newline=None,closefd=True,opener=None):
    if 'b' not in mode and any(c in mode for c in 'wax') and newline is None:newline='\n'
    return original(file,mode,buffering,encoding,errors,newline,closefd,opener)
io.open=lf_open
script=Path(sys.argv[1]).resolve()
sys.argv=sys.argv[1:]
sys.path.insert(0,str(script.parent))
runpy.run_path(str(script),run_name='__main__')
