# Retained engineering iterations

The first 70-digit computation completed and wrote SPECTRUM_70.json. Its
controller then failed to write the receipt spectrum_70.json because those
names coincide on Windows. The numerical output and spectrum_70.log are
retained unchanged. This was receipt packaging, not a numerical failure.
The successor uses compute_70/compute_100 receipt names and distinct output
paths. It reruns the same mathematics; no semantic correction was made.

The same receipt/output case collision recurred for INDEPENDENT_CONSTANTS.json.
That completed result and its log are also retained. The wrapper is now
corrected generically: all new process receipts go in receipts/, physically
separate from result artifacts. The pre-correction wrapper is worker_initial.py.
Both retained successful computations are checked against their replay.
