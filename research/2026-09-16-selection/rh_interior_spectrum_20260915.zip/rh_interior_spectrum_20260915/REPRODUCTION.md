# Reproduce without changing the package

Requires Python 3.10+ and mpmath. Independent constants also use an entirely
separate standard-library Fraction implementation. No installation or
network access is performed by these programs.

    python -B reproduce.py --output /absolute/path/to/a/new/output/directory

The output directory must not exist and must lie outside the sealed package.
The runner authenticates the manifest, copies inputs to the new directory,
rebuilds the 70-digit spectral result, 70-digit complete-cell transport, and
independent Fraction constants, then reruns the exact verification and
supplementary point-algebra checks. Five result files must match byte-for-byte.
The 100-digit records are authenticated and compared, not recomputed in this
clean replay. Historical defining-contour integrations are not rerun.

The original incoming builder/tests are preserved under incoming/ and were
executed separately during this turn. The endpoint product uses only constant
series, not critical-strip zeta evaluations. The new finite run reevaluates
elementary finite arithmetic on the same 2,048 closed cells.

The written infinite estimates in DERIVATION.md require mathematical review;
the finite tests do not formalize them or certify a numerical onset.

All rights reserved, TWO HANDS NETWORK LTD. No external publication authorized.
