import json,zipfile
from pathlib import PurePosixPath
from intake import HERE,sha,write
from worker import run

receipt=json.loads((HERE/'SEAL_RECEIPT.json').read_text());assert sha(receipt['archive_path'])==receipt['archive_sha256']
out=HERE/'clean_extraction';out.mkdir()
with zipfile.ZipFile(receipt['archive_path']) as z:
    items=z.infolist();names=[i.filename for i in items]
    assert len(names)==len(set(names))==len({n.casefold() for n in names})
    assert all(n.startswith('rh_interior_spectrum_20260915/') and '..' not in PurePosixPath(n).parts and ':' not in n and '\\' not in n for n in names)
    assert sum(i.file_size for i in items)<128*1024**2
    assert all((i.external_attr>>16)&0o170000!=0o120000 for i in items)
    z.extractall(out)
package=out/'rh_interior_spectrum_20260915'
assert sha(package/'PACKAGE_MANIFEST.json')==receipt['seal']
run(package/'reproduce.py',['--output',HERE/'clean_reproduced'],'clean_reproduction')
check=json.loads((HERE/'clean_reproduced/CLEAN_RECEIPT.json').read_text());assert check['passed']
write(HERE/'CLEAN_REPLAY.json',check);print(json.dumps(check))
