"""Whole-cell finite cost of the upper-block transport on the same N64 windows."""
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial,isqrt,ceil
import argparse,gzip,json,hashlib
from mpmath import iv
from spectrum import rat,pack,bounds

def read(z):return iv.mpf([rat(z[0]).a,rat(z[1]).b])
def minimum(xs):return iv.mpf([min(x.a for x in xs),min(x.b for x in xs)])
def maximum(xs):return iv.mpf([max(x.a for x in xs),max(x.b for x in xs)])
def positive(x):return iv.mpf([max(iv.mpf(0),x.a),max(iv.mpf(0),x.b)])

def build(source,digits):
    iv.dps=digits
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
    src=json.loads(gzip.decompress(raw));assert src['N']==64 and src['degree']==5
    n=64;d=5;kmax=isqrt(n);j0=ceil(F(3,5)*d)
    scales=list(map(F,src['scales']));scale=2*rat(scales[-1])/n
    shift=rat(F(2491,3000)-F(src['source_payment']))
    windows=[]
    for win in src['windows']:
        totals={name:iv.mpf(0) for name in ['original','shortened','error_cap','restored']}
        mass=iv.mpf(0);rows=[]
        for cell in win['cells']:
            r=read(cell['r']);a=n+r
            theta0=2*iv.pi*a*a*(iv.log(a)-rat(F(1,2)))-iv.pi/8
            prefix=[iv.mpf(0) for _ in range(d+1)]
            for m in range(1,kmax+1):
                z=iv.log(a/m)+iv.j*iv.pi/4
                phase=2*iv.pi*a*a*(iv.log(a/m)-rat(F(1,2)))-iv.pi/8
                term=(-1)**(n+win['nu'])*iv.sqrt(a/m)*iv.exp(iv.j*phase)
                for k in range(d+1):
                    prefix[k]+=(term*z**(2*k)/rat(4**k*factorial(2*k))).real
            original=[read(v) for v in cell['V']];short=list(original)
            for j in range(j0,d+1):
                beta=sum((rat(F(comb(j,k),comb(d,k)))*prefix[k] for k in range(j+1)),iv.mpf(0))
                short[j]=scale*(beta+shift)/rat(scales[j])
            p=positive(read(cell['X']));w=read(cell['W'])
            w=iv.mpf([max(iv.mpf(0),w.a),min(iv.mpf(4),w.b)])
            cap=p*maximum([abs(original[j]-short[j]) for j in range(j0,d+1)])
            old=p*minimum(original);new=p*minimum(short)
            values=dict(original=old,shortened=new,error_cap=cap,restored=new-cap)
            for key,v in values.items():totals[key]+=w*v
            mass+=w
            rows.append(dict(i=cell['i'],r=cell['r'],error_cap=pack(cap),shortened=pack(new)))
        assert mass.a>0
        windows.append(dict(nu=win['nu'],moments={k:pack(v/mass) for k,v in totals.items()},rows=rows))
    return dict(kind='finite_upper_block_transport',N=n,degree=d,cutoff=kmax,first_shortened_index=j0,
        digits=digits,windows=windows,input_sha256=hashlib.sha256(raw).hexdigest(),
        scope=dict(original_cells=2048,new_heights=False,complete_arithmetic_cell_enclosures=True,
                   asymptotic_constant_used_at_N64=False,shortened_function_not_equal_to_source=True))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True)
    p.add_argument('--digits',type=int,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=build(a.source,a.digits)
    with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(r,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps([dict(nu=w['nu'],moments={k:v['display'] for k,v in w['moments'].items()}) for w in r['windows']]))
