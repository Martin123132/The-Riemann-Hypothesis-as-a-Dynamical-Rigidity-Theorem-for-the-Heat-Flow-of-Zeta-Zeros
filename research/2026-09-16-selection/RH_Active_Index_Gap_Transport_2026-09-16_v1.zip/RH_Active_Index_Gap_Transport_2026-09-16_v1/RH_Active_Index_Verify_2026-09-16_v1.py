"""Verify the sealed package and rebuild both outputs in an isolated directory."""
from pathlib import Path
import argparse,hashlib,json,zipfile,tempfile,subprocess,sys,os

PREFIX='RH_Active_Index'
MANIFEST='RH_Active_Index_Manifest_2026-09-16_v1.json'
PARENT='RH_Active_Index_Parent_Archive_2026-09-16_v1.zip'
FULL='RH_Active_Index_Full_Source_2026-09-16_v1.json.gz'
PILOT='RH_Active_Index_Pilot_Source_2026-09-16_v1.json.gz'
BUILDER='RH_Active_Index_Builder_2026-09-16_v1.py'
INDEPENDENT='RH_Active_Index_Independent_2026-09-16_v1.py'
PRIMARY_OUT='RH_Active_Index_Results_2026-09-16_v1.json.gz'
INDEPENDENT_OUT='RH_Active_Index_Independent_Results_2026-09-16_v1.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(root):
    root=Path(root).resolve();m=json.loads((root/MANIFEST).read_text())
    expected=set(m['files'])|{MANIFEST}
    actual={p.name for p in root.iterdir() if p.is_file()}
    if actual!=expected:raise ValueError('unexpected or missing sealed files')
    for n,h in m['files'].items():
        if sha((root/n).read_bytes())!=h:raise ValueError('file hash mismatch: '+n)
    with zipfile.ZipFile(root/PARENT) as z:
        mn=next(n for n in z.namelist() if 'Manifest' in n and n.endswith('.json'))
        pm=json.loads(z.read(mn));base=mn.rsplit('/',1)[0]+'/'
        for name,h in pm['files'].items():
            if sha(z.read(base+name))!=h:raise ValueError('parent member mismatch')
        if z.read(base+'RH_Central_Energy_Cell_Input_2026-09-15_v1.json.gz')!=(root/FULL).read_bytes():raise ValueError('full source provenance')
        if z.read(base+'RH_Central_Energy_Short_80d_2026-09-15_v1.json.gz')!=(root/PILOT).read_bytes():raise ValueError('pilot provenance')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    tests=subprocess.run([sys.executable,str(root/'RH_Active_Index_Tests_2026-09-16_v1.py')],cwd=root,env=env,text=True,capture_output=True,timeout=40)
    if tests.returncode:raise RuntimeError(tests.stdout+tests.stderr)
    hashes={}
    with tempfile.TemporaryDirectory(prefix='rh_active_isolated_') as td:
        d=Path(td)
        for n in [FULL,PILOT,BUILDER,INDEPENDENT]:(d/n).write_bytes((root/n).read_bytes())
        for code,out in [(BUILDER,PRIMARY_OUT),(INDEPENDENT,INDEPENDENT_OUT)]:
            run=subprocess.run([sys.executable,code,'--full',FULL,'--pilot',PILOT,'--output',out],cwd=d,env=env,capture_output=True,text=True,timeout=40)
            if run.returncode:raise RuntimeError(run.stdout+run.stderr)
            if (d/out).read_bytes()!=(root/out).read_bytes():raise ArithmeticError('replay not byte-identical: '+out)
            hashes[out]=sha((d/out).read_bytes())
    return {'date':'2026-09-16','verified_manifest_members':len(m['files']),
            'parent_manifest_members':len(pm['files']),'source_files_match_parent_bytes':True,
            'named_tests_passed':36,'test_exit_code':tests.returncode,
            'isolated_runtime_files':4,'byte_identical_rebuilt_results':hashes,
            'new_source_evaluations':0,'historical_pin_audit':False,'remote_writes':False,
            'scope':'Shared source enclosures; independent new exact aggregation, not independent source evaluation.',
            'test_tail':tests.stderr.splitlines()[-5:]}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default=str(Path(__file__).parent));p.add_argument('--receipt',required=True);a=p.parse_args()
    out=Path(a.receipt)
    if out.exists():raise FileExistsError(out)
    out.write_text(json.dumps(verify(a.root),indent=2,sort_keys=True)+'\n')
