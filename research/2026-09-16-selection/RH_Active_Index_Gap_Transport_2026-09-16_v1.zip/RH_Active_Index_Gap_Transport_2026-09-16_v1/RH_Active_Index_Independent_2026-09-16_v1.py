"""Separate tuple/Fraction acceptance; shared source data, no primary imports.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import json,gzip,hashlib,argparse

EXPECTED=('f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161',
          '5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4')
def iv(z):
    if isinstance(z,(tuple,list)):
        a,b=map(F,z)
        if a>b:raise ValueError('interval reversed')
        return a,b
    a=F(z);return a,a
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return min(v),max(v)
def div(a,b):
    if b[0]<=0<=b[1]:raise ValueError('zero divisor')
    return mul(a,(1/b[1],1/b[0]))
def pos(a):return max(F(0),a[0]),max(F(0),a[1])
def pack(a):return list(map(str,a))
def mmin(v):return min(x[0] for x in v),min(x[1] for x in v)
def mmax(v):return max(x[0] for x in v),max(x[1] for x in v)
def check_source(a,b):
    if a['N']!=64 or a['degree']!=5 or F(a['source_payment'])!=F(10876005389,40000000000):raise ValueError('full contract')
    ss=[sum((F(comb(j,k)*5**(2*k),comb(5,k)*4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    if list(map(F,a['scales']))!=ss:raise ValueError('scales')
    if b['N']!=64 or b['d']!=5 or b['K']!=8 or b['upper_indices']!=[2,3,4,5] or b['input_sha256']!=EXPECTED[0] or not b['whole_cell_evaluation']:raise ValueError('short contract')
    if len(a['windows'])!=2 or len(b['windows'])!=2:raise ValueError('window count')

def run(full,pilot):
    docs=[]
    for i,path in enumerate([full,pilot]):
        raw=Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=EXPECTED[i]:raise ValueError('input hash')
        docs.append(json.loads(gzip.decompress(raw)))
    a,b=docs;check_source(a,b)
    out={'scope':'independent exact aggregation and regret calculation on shared complete source cells','new_source_evaluations':0,'windows':[]}
    for nu in range(2):
        aw,bw=a['windows'][nu],b['windows'][nu]
        lo=F(49+100*nu,200);hi=F(51+100*nu,200)
        if aw['nu']!=nu or bw['nu']!=nu or list(map(F,aw['r']))!=[lo,hi] or len(aw['cells'])!=1024 or len(bw['cells'])!=1024:raise ValueError('window geometry')
        totals={};counts={j:0 for j in range(2,6)};selectors=[];conditional={j:iv(0) for j in range(2,6)}
        for k,(c,t) in enumerate(zip(aw['cells'],bw['cells'])):
            target=[lo+F(k,102400),lo+F(k+1,102400)]
            if c['i']!=k or t['i']!=k or list(map(F,c['r']))!=target or list(map(F,t['r']))!=target:raise ValueError('cell gap')
            if len(c['V'])!=6 or len(t['Vshort'])!=4:raise ValueError('coefficient count')
            v=list(map(iv,c['V']));q=list(map(iv,t['Vshort']));x,w=iv(c['X']),iv(c['W']);p=pos(x)
            if w[0]<0 or w[1]>4:raise ValueError('weight bounds')
            chosen=2+min(range(4),key=lambda j:(q[j][0]+q[j][1],j))
            counts[chosen]+=1;selectors.append(chosen)
            selected=v[chosen];lower=mmin(v[:2]);upper=mmin(v[2:]);pair=mmin([lower,selected]);truth=mmin(v)
            # Separate interval route: effective loss is min(upper-regret,
            # positive excess of the lower block above the full upper minimum).
            other=mmin([v[j] for j in range(2,6) if j!=chosen])
            ru=pos(sub(selected,other))
            loss=mmin([ru,pos(sub(lower,upper))])
            uterms={j:sub(v[j],q[j-2]) for j in range(2,6)}
            gaps={j:sub(q[j-2],q[chosen-2]) for j in range(2,6) if j!=chosen}
            gap_bound=max([F(0)]+[uterms[chosen][1]-uterms[j][0]-gaps[j][0] for j in gaps])
            if loss[1]>gap_bound:loss=(loss[0],gap_bound)
            if loss[0]>loss[1]:raise ArithmeticError('incompatible regret bounds')
            weighted=lambda z:mul(w,z)
            records={'mass':w,'selected_gated':weighted(mul(p,selected)),
              'selected_signed':weighted(mul(x,selected)),
              'negative_central_correction':weighted(mul(pos(neg(x)),selected)),
              'lower_block_loss':weighted(mul(p,pos(sub(selected,lower)))),
              'policy_net':weighted(mul(p,pair)),
              'selection_regret':weighted(mul(p,loss)),
              'restored':weighted(mul(p,sub(pair,loss))),
              'gap_only_regret_allowance':weighted(mul(p,iv(gap_bound))),
              'gap_only_restored':weighted(mul(p,sub(pair,iv(gap_bound)))),
              'direct_reference':weighted(mul(p,truth))}
            conditional[chosen]=add(conditional[chosen],records['selected_signed'])
            for key,z in records.items():totals[key]=add(totals.get(key,iv(0)),z)
        den=totals['mass']
        if den[0]<=0:raise ValueError('mass not positive')
        moments={key:div(z,den) for key,z in totals.items() if key!='mass'}
        if moments['restored'][0]<=0 or moments['gap_only_restored'][0]<=0:raise ArithmeticError('selection failed')
        out['windows'].append({'nu':nu,'cells':1024,'selector_counts':{str(j):n for j,n in counts.items()},'selector_sha256':hashlib.sha256(bytes(selectors)).hexdigest(),
            'moments':{key:pack(z) for key,z in moments.items()},
            'conditional_signed_by_index':{str(j):pack(div(conditional[j],den)) for j in range(2,6)},
            'restored_positive':moments['restored'][0]>0})
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--pilot',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    dst=Path(a.output)
    if dst.exists():raise FileExistsError(dst)
    dst.write_text(json.dumps(run(a.full,a.pilot),sort_keys=True,indent=2)+'\n')
