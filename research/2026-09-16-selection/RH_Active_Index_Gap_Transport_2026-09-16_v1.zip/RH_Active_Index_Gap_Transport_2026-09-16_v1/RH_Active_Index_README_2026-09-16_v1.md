# Active-index and coefficient-gap transport

Private research for Martin Ollett / TWO HANDS NETWORK LTD.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.

The derivation is `RH_Active_Index_Gap_Derivation_2026-09-16_v1.md`.
The compact summary is `RH_Active_Index_Summary_2026-09-16_v1.json`.

Requirements: Python 3.10 or later; standard library only.
No network, external service, special-function library, or user-machine access
is required. Do not overwrite historical output paths. Both builders refuse
to overwrite an existing requested output.

From the extracted directory, run:

```text
python RH_Active_Index_Tests_2026-09-16_v1.py

python RH_Active_Index_Builder_2026-09-16_v1.py --full RH_Active_Index_Full_Source_2026-09-16_v1.json.gz --pilot RH_Active_Index_Pilot_Source_2026-09-16_v1.json.gz --output new_active_index_result.json.gz

python RH_Active_Index_Independent_2026-09-16_v1.py --full RH_Active_Index_Full_Source_2026-09-16_v1.json.gz --pilot RH_Active_Index_Pilot_Source_2026-09-16_v1.json.gz --output new_independent_active_index_result.json
```

The primary complete ledger is compressed JSON with all 2,048 source-cell
records. Exact numbers are fraction strings; `display` entries are conveniences
only. The independent output is a separate acceptance result, not a copy of the
primary ledger. Both calculations share the inherited source enclosures.

The manifest excludes itself. A separate clean-extraction receipt is delivered
outside the ZIP. It records actual rebuilds and byte comparisons, not a promise
of future verification. No historical integrity-pin count is asserted here.

Scope: finite acceptance on the SAME N=64 windows; an exact gap-localized regret
lemma; a conditional quantitative adaptive-index transfer using the parent's
bounds. The unbounded signed-selector inequality, and the original winding and
absolute-count closure, remain unproved.
