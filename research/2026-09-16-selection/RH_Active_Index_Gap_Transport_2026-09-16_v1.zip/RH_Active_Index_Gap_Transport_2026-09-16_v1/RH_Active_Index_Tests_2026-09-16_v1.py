"""Exact implementation controls; they supplement, not formalize, the proof."""
import unittest,importlib.util,sys,json,gzip,hashlib,copy,tempfile
from pathlib import Path
from fractions import Fraction as F

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('active',ROOT/'RH_Active_Index_Builder_2026-09-16_v1.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
spec=importlib.util.spec_from_file_location('independent',ROOT/'RH_Active_Index_Independent_2026-09-16_v1.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
FULL=ROOT/'RH_Active_Index_Full_Source_2026-09-16_v1.json.gz'
PILOT=ROOT/'RH_Active_Index_Pilot_Source_2026-09-16_v1.json.gz'
OUT=ROOT/'RH_Active_Index_Results_2026-09-16_v1.json.gz'
IND=ROOT/'RH_Active_Index_Independent_Results_2026-09-16_v1.json'
B=a.Ball

def overlap(x,y):return max(F(x[0]),F(y[0]))<=min(F(x[1]),F(y[1]))
class AnalyticControls(unittest.TestCase):
    def test_gap_regret_all_rational_vectors(self):
        import itertools
        for q in itertools.product(range(-1,2),repeat=3):
            sel=min(range(3),key=lambda i:(q[i],i));g=min(q[j]-q[sel] for j in range(3) if j!=sel)
            for e in itertools.product(range(-2,3),repeat=3):
                v=[F(q[j]+e[j]) for j in range(3)];om=max(e)-min(e);reg=v[sel]-min(v)
                self.assertLessEqual(reg,max(0,om-g))
    def test_quadratic_gap_bound(self):
        for g in (F(1,7),F(1),F(3),F(11,2)):
            for om in (F(0),F(1,7),g,2*g,10*g):
                self.assertLessEqual(max(F(0),om-g),om*om/(4*g))
    def test_quadratic_constant_attained(self):
        q=[F(0),F(1)];e=[F(1),F(-1)];v=[q[i]+e[i] for i in range(2)]
        self.assertEqual(v[0]-min(v),F(1));self.assertEqual((max(e)-min(e))**2/(4*(q[1]-q[0])),F(1))
    def test_signed_gap_approximate_selector(self):
        q=[F(2),F(0)];sel=0;e=[F(0),F(0)]
        g=q[1]-q[0];reg=q[0]-min(q)
        self.assertEqual(reg,max(F(0),max(e)-min(e)-g))
        self.assertLess(g,0)
    def test_positive_gap_required_for_quadratic(self):
        g=F(-2);om=F(0)
        self.assertGreater(max(F(0),om-g),0)
    def test_ties_retained(self):
        q=[F(0),F(0)];e=[F(1),F(-1)]
        self.assertEqual(q[0]+e[0]-min(q[i]+e[i] for i in range(2)),F(2))
    def test_common_tail_cancels_from_index_regret(self):
        for shift in (F(-100),F(0),F(1000)):
            e=[F(1)+shift,F(-1)+shift,F(3)+shift]
            self.assertEqual(max(e)-min(e),4)
    def test_lower_block_screens_wrong_upper(self):
        lower=F(-10);v=[F(2),F(-2)]
        self.assertGreater(v[0]-min(v),0)
        self.assertEqual(min(lower,v[0])-min(lower,min(v)),0)
    def test_block_identity_complete_controls(self):
        import itertools
        for x,lower,v0,v1 in itertools.product(range(-2,3),repeat=4):
            p=max(0,x);u=min(v0,v1);pol=min(lower,v0);reg=pol-min(lower,u)
            self.assertEqual(p*min(lower,u),p*v0-p*max(0,v0-lower)-p*reg)
    def test_gate_identity_retains_adverse_correction(self):
        for x,y in [(F(-2),F(-10)),(F(1),F(-1)),(F(0),F(3))]:
            self.assertEqual(max(F(0),x)*y,x*y+max(F(0),-x)*y)
    def test_individual_positive_correlations_not_selection(self):
        rows=[(1,[2,-2,10]),(1,[2,10,-2])]
        self.assertEqual(sum(x*v[1] for x,v in rows)/2,4)
        self.assertEqual(sum(x*v[2] for x,v in rows)/2,4)
        self.assertEqual(sum(max(0,x)*min(v) for x,v in rows)/2,-2)
    def test_covariance_partition_identity(self):
        rows=[(F(1,3),F(2),[F(1),F(3)],0),(F(2,3),F(-1),[F(-2),F(4)],1)]
        means=[sum(w*x*v[j] for w,x,v,s in rows) for j in range(2)]
        ps=[sum(w for w,x,v,s in rows if s==j) for j in range(2)]
        selected=sum(w*x*v[s] for w,x,v,s in rows)
        covariance=sum(sum(w*x*v[j] for w,x,v,s in rows if s==j)-ps[j]*means[j] for j in range(2))
        self.assertEqual(selected,sum(ps[j]*means[j] for j in range(2))+covariance)
    def test_mixture_inherits_uniform_lower_bound(self):
        for p in (F(0),F(1,7),F(1,2),F(1)):
            self.assertGreaterEqual(p*3+(1-p)*5,3)
    def test_unchanged_truncation_rate(self):
        beta=F(7,10)
        self.assertEqual((F(1,2)-beta)/2,F(-1,10))
        self.assertEqual(F(2,3)-beta,F(-1,30))
    def test_selector_has_deterministic_tie(self):
        self.assertEqual(a.choose([B(0),B(0),B(1),B(2)]),2)
    def test_selector_uses_only_pilot(self):
        q=[B(2),B(1),B(-1),B(0)];decision=a.choose(q)
        for full in ([B(-100)]*4,[B(100)]*4):
            self.assertEqual(a.choose(q),decision)
    def test_interval_rejection(self):
        with self.assertRaises(ValueError):B(2,1)
        with self.assertRaises(ValueError):B(1)/B(-1,1)
        with self.assertRaises(ValueError):a.minimum([])

class SourceAndReplay(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.full=a.read(FULL,a.FULL_HASH);cls.pilot=a.read(PILOT,a.PILOT_HASH)
        cls.res=a.read(OUT);cls.ind=a.read(IND)
    def test_source_contract(self):a.validate(self.full,self.pilot)
    def test_missing_cell_rejected(self):
        z=copy.deepcopy(self.full);z['windows'][0]['cells'].pop()
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_duplicate_cell_rejected(self):
        z=copy.deepcopy(self.full);z['windows'][0]['cells'][1]=z['windows'][0]['cells'][0]
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_error_payment_change_rejected(self):
        z=copy.deepcopy(self.full);z['source_payment']='0'
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_scale_change_rejected(self):
        z=copy.deepcopy(self.full);z['scales'][2]='1'
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_pilot_index_change_rejected(self):
        z=copy.deepcopy(self.pilot);z['upper_indices']=[1,2,3,4]
        with self.assertRaises(ValueError):a.validate(self.full,z)
    def test_pilot_cutoff_change_rejected(self):
        z=copy.deepcopy(self.pilot);z['K']=16
        with self.assertRaises(ValueError):a.validate(self.full,z)
    def test_weight_sign_rejected(self):
        z=copy.deepcopy(self.full);z['windows'][0]['cells'][0]['W']=['-1','0']
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_window_change_rejected(self):
        z=copy.deepcopy(self.full);z['windows'][1]['r'][1]='1'
        with self.assertRaises(ValueError):a.validate(z,self.pilot)
    def test_all_cells_and_indices_retained(self):
        self.assertEqual([w['nu'] for w in self.res['windows']],[0,1])
        for w in self.res['windows']:
            self.assertEqual(len(w['rows']),1024);self.assertEqual(sum(w['selector_counts'].values()),1024)
            self.assertEqual([r['i'] for r in w['rows']],list(range(1024)))
            self.assertTrue(all(r['chosen_index'] in [2,3,4,5] for r in w['rows']))
    def test_positive_lower_bounds_both_calculations(self):
        for nu in (0,1):
            for records in [self.res,self.ind]:
                m=records['windows'][nu]['moments']
                self.assertGreater(F(m['restored'][0]),F('1.0845') if nu==0 else F('1.0523'))
                self.assertGreater(F(m['gap_only_restored'][0]),F('1.0666') if nu==0 else F('1.0352'))
    def test_retained_wrong_choices_with_positive_gate(self):
        self.assertEqual([w['classification_counts']['strict_gate_and_wrong_choice'] for w in self.res['windows']],[97,25])
    def test_selected_negative_source_contribution(self):
        for records in [self.res,self.ind]:
            val=records['windows'][0]['by_index']['4']['selected_signed'] if 'by_index' in records['windows'][0] else records['windows'][0]['conditional_signed_by_index']['4']
            self.assertLess(F(val[1]),F('-0.000076'))
        self.assertGreater(F(self.res['windows'][0]['moments']['fixed_signed_4'][0]),F('1.27'))
    def test_all_independent_overlaps(self):
        for w,v in zip(self.res['windows'],self.ind['windows']):
            self.assertEqual(w['selector_counts'],v['selector_counts'])
            self.assertEqual(hashlib.sha256(bytes(row['chosen_index'] for row in w['rows'])).hexdigest(),v['selector_sha256'])
            for key,y in v['moments'].items():self.assertTrue(overlap(w['moments'][key],y),(w['nu'],key))
    def test_no_coefficient_erased_by_mask(self):
        for w in self.res['windows']:
            self.assertEqual(set(w['by_index']),{'2','3','4','5'})
            for key in ['selected_signed','negative_central_correction','selected_gated','policy_net','selection_regret']:
                lo=sum(F(w['by_index'][j][key][0]) for j in w['by_index']);hi=sum(F(w['by_index'][j][key][1]) for j in w['by_index'])
                self.assertLessEqual(lo,F(w['moments'][key][1]));self.assertGreaterEqual(hi,F(w['moments'][key][0]))
    def test_scope_flags_not_global(self):
        self.assertFalse(self.res['all_height_signed_selector_bound_proved']);self.assertEqual(self.res['new_source_evaluations'],0)
    def test_primary_complete_rebuild(self):self.assertEqual(a.build(FULL,PILOT),self.res)
    def test_independent_complete_rebuild(self):self.assertEqual(b.run(FULL,PILOT),self.ind)
    def test_overwrite_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json';a.save(p,{'x':1})
            with self.assertRaises(FileExistsError):a.save(p,{'x':2})

if __name__=='__main__':unittest.main(verbosity=2)
