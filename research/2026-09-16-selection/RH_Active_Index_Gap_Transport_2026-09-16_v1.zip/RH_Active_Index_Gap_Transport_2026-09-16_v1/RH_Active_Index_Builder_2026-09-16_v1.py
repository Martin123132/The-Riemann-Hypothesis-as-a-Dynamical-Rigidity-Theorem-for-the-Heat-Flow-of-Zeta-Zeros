"""Active-index selection on complete certified source cells.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
No special-function evaluation or historical acceptance input is used.
"""
from __future__ import annotations
import argparse, gzip, hashlib, json
from fractions import Fraction as F
from pathlib import Path
from math import comb, factorial

FULL_HASH='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
PILOT_HASH='5c0d1208f817390a54cfab4ed9ca57bb0e200a632e8d159507e4c5a15c57aaa4'
UPPER=(2,3,4,5)
class Ball:
    __slots__=('lo','hi')
    def __init__(self, lo=0, hi=None):
        if isinstance(lo,Ball): self.lo,self.hi=lo.lo,lo.hi; return
        self.lo=F(lo); self.hi=F(lo if hi is None else hi)
        if self.lo>self.hi: raise ValueError('reversed interval')
    def __add__(self,v):
        v=Ball(v);return Ball(self.lo+v.lo,self.hi+v.hi)
    __radd__=__add__
    def __neg__(self):return Ball(-self.hi,-self.lo)
    def __sub__(self,v):return self+-Ball(v)
    def __rsub__(self,v):return Ball(v)+-self
    def __mul__(self,v):
        v=Ball(v); a=(self.lo*v.lo,self.lo*v.hi,self.hi*v.lo,self.hi*v.hi);return Ball(min(a),max(a))
    __rmul__=__mul__
    def __truediv__(self,v):
        v=Ball(v)
        if v.lo<=0<=v.hi:raise ValueError('zero denominator')
        return self*Ball(1/v.hi,1/v.lo)
    def positive(self):return Ball(max(F(0),self.lo),max(F(0),self.hi))
    def magnitude(self):return max(abs(self.lo),abs(self.hi))
    def dump(self):return [str(self.lo),str(self.hi)]
    def display(self):return [float(self.lo),float(self.hi)]

def minimum(xs):
    xs=list(xs)
    if not xs:raise ValueError('empty minimum')
    return Ball(min(x.lo for x in xs),min(x.hi for x in xs))
def maximum(xs):
    xs=list(xs)
    if not xs:raise ValueError('empty maximum')
    return Ball(max(x.lo for x in xs),max(x.hi for x in xs))
def intersect(x,y):
    a,b=max(x.lo,y.lo),min(x.hi,y.hi)
    if a>b:raise ArithmeticError('disjoint valid enclosures')
    return Ball(a,b)
def read(path,expected=None):
    b=Path(path).read_bytes()
    if expected and hashlib.sha256(b).hexdigest()!=expected:raise ValueError('input bytes changed')
    return json.loads(gzip.decompress(b) if str(path).endswith('.gz') else b)
def save(path,obj):
    p=Path(path)
    if p.exists():raise FileExistsError(p)
    b=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
    p.write_bytes(gzip.compress(b,mtime=0) if str(p).endswith('.gz') else b)
def scales():
    return [sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
def choose(pilot):
    """Only four shortened source intervals enter this function."""
    if len(pilot)!=4:raise ValueError('pilot needs exactly four upper indices')
    return min(range(4),key=lambda i:((pilot[i].lo+pilot[i].hi)/2,i))+2

def validate(full,pilot):
    if full['N']!=64 or full['degree']!=5:raise ValueError('source contract')
    if list(map(F,full['scales']))!=scales():raise ValueError('scale contract')
    if F(full['source_payment'])!=F('0.271900134725'):raise ValueError('error contract')
    if (pilot['N'],pilot['d'],pilot['K'])!=(64,5,8) or pilot['upper_indices']!=list(UPPER):raise ValueError('pilot contract')
    if pilot['input_sha256']!=FULL_HASH or not pilot['whole_cell_evaluation']:raise ValueError('pilot binding')
    if [w['nu'] for w in full['windows']]!=[0,1] or [w['nu'] for w in pilot['windows']]!=[0,1]:raise ValueError('window roster')
    for nu,(fw,sw) in enumerate(zip(full['windows'],pilot['windows'])):
        ends=[F(49+100*nu,200),F(51+100*nu,200)]
        if list(map(F,fw['r']))!=ends or len(fw['cells'])!=1024 or len(sw['cells'])!=1024:raise ValueError('window geometry')
        for i,(c,h) in enumerate(zip(fw['cells'],sw['cells'])):
            r=[ends[0]+F(i,102400),ends[0]+F(i+1,102400)]
            if c['i']!=i or h['i']!=i or list(map(F,c['r']))!=r or list(map(F,h['r']))!=r:raise ValueError('cell gap/order')
            if len(c['V'])!=6 or len(h['Vshort'])!=4:raise ValueError('missing coefficient')
            W=Ball(*c['W']);Ball(*c['X'])
            if W.lo<0 or W.hi>4:raise ValueError('weight range')
            for v in c['V']+h['Vshort']:Ball(*v)
    return full,pilot

def cell_calculation(c,h):
    X,W=Ball(*c['X']),Ball(*c['W']);P=X.positive()
    V=[Ball(*v) for v in c['V']];pilot=[Ball(*v) for v in h['Vshort']]
    a=choose(pilot);Va=V[a];U=minimum(V[2:]);L=minimum(V[:2]);T=minimum([L,Va]);m=minimum(V)
    # Selecting an upper source does not remove the unshortened lower block.
    regret_terms=[minimum([L-V[j],Va-V[j]]) for j in UPPER if j!=a]
    regret=maximum([Ball(0)]+regret_terms).positive()
    upper_regret=maximum([Ball(0)]+[Va-V[j] for j in UPPER if j!=a]).positive()
    regret=intersect(regret,Ball(0,upper_regret.hi))
    gaps={j:pilot[j-2]-pilot[a-2] for j in UPPER if j!=a}
    gap=minimum(gaps.values())
    tails={j:V[j]-pilot[j-2] for j in UPPER}
    max_tail=max(v.magnitude() for v in tails.values())
    tail_oscillation=max(t.hi for t in tails.values())-min(t.lo for t in tails.values())
    pair_gap_bound=max([F(0)]+[tails[a].hi-tails[j].lo-gaps[j].lo for j in UPPER if j!=a])
    uniform_gap_bound=max(F(0),2*max_tail-gap.lo)
    oscillation_gap_bound=max(F(0),tail_oscillation-gap.lo)
    gap_regret=min(pair_gap_bound,uniform_gap_bound,oscillation_gap_bound)
    regret=intersect(regret,Ball(0,gap_regret))
    selected_negative_loss=W*P*(-Va).positive()
    vals={
      'mass':W,'positive_gate_mass':W*P,
      'selected_signed':W*X*Va,'negative_central_correction':W*(-X).positive()*Va,
      'selected_gated':W*P*Va,'selected_positive_energy':W*P*Va.positive(),
      'selected_negative_energy':selected_negative_loss,
      **{'fixed_signed_'+str(j):W*X*V[j] for j in UPPER},
      'lower_block_loss':W*P*(Va-L).positive(),
      'policy_net':W*P*T,
      'selection_regret':W*P*regret,
      'upper_selection_regret':W*P*upper_regret,
      'restored':W*P*(T-regret),
      'gap_only_regret_allowance':W*P*gap_regret,
      'gap_only_restored':W*P*(T-gap_regret),
      'direct_reference':W*P*m,
      'adverse_old_transfer':W*P*maximum([Ball(0)]+[(pilot[j-2]-V[j]).positive() for j in UPPER]),
    }
    # Identity and endpoint comparisons are algebraically proved in the report;
    # this rational control catches implementation sign/index mistakes.
    xx=(X.lo+X.hi)/2;vs=[(v.lo+v.hi)/2 for v in V];pp=max(F(0),xx)
    ll=min(vs[:2]);uu=min(vs[2:]);tt=min(ll,vs[a]);mm=min(vs)
    rr=max(F(0),tt-uu)
    if pp*mm!=pp*vs[a]-pp*max(F(0),vs[a]-ll)-pp*rr:raise ArithmeticError('selector identity')
    if not regret.lo<=rr<=regret.hi:raise ArithmeticError('model regret outside interval')
    row={'i':c['i'],'r':c['r'],'chosen_index':a,'pilot_gap':gap.dump(),
      'full_upper_minimum_certified':all(Va.hi<=V[j].lo for j in UPPER if j!=a),
      'pilot_minimum_certified':gap.lo>=0,
      'strict_full_wrong_choice_certified':upper_regret.lo>0,
      'strict_gate_and_wrong_choice':X.lo>0 and upper_regret.lo>0,
      'gate_inactive':X.hi<=0,
      'effective_regret_zero_certified':regret.hi==0,
      'gap_regret_bound':str(gap_regret),'max_tail_bound':str(max_tail),
      'tail_oscillation_bound':str(tail_oscillation),
      'oscillation_gap_regret_bound':str(oscillation_gap_bound),
      'integrands':{k:v.dump() for k,v in vals.items()}}
    return vals,row

def build(fullpath,pilotpath):
    full,pilot=validate(read(fullpath,FULL_HASH),read(pilotpath,PILOT_HASH))
    result={'stage':'same-height active-index calibration with exact regret',
       'N':64,'degree':5,'source_payment':full['source_payment'],'upper_indices':list(UPPER),'lower_indices':[0,1],
       'K':8,'selector_uses_full_upper':False,'whole_cells':2048,
       'source_hashes':{'full':FULL_HASH,'pilot':PILOT_HASH},
       'all_height_signed_selector_bound_proved':False,'new_source_evaluations':0,'windows':[]}
    for fw,sw in zip(full['windows'],pilot['windows']):
        sums={};rows=[];by={j:{} for j in UPPER};hist={j:0 for j in UPPER}
        for c,h in zip(fw['cells'],sw['cells']):
            vals,row=cell_calculation(c,h);rows.append(row);a=row['chosen_index'];hist[a]+=1
            for k,v in vals.items():sums[k]=sums.get(k,Ball(0))+v
            for k in ['mass','positive_gate_mass','selected_signed','negative_central_correction','selected_gated','policy_net','selection_regret']:
                by[a][k]=by[a].get(k,Ball(0))+vals[k]
        den=sums['mass']
        if den.lo<=0:raise ValueError('nonpositive weight mass')
        moments={k:v/den for k,v in sums.items() if k!='mass'}
        split=moments['selected_gated']-moments['lower_block_loss']-moments['selection_regret']
        rawsplit=moments['selected_signed']+moments['negative_central_correction']-moments['lower_block_loss']-moments['selection_regret']
        mixture=sum(((by[j].get('mass',Ball(0))/den)*moments['fixed_signed_'+str(j)] for j in UPPER),Ball(0))
        selection_covariance=moments['selected_signed']-mixture
        histcounts={key:sum(int(r[key]) for r in rows) for key in ['pilot_minimum_certified','full_upper_minimum_certified','strict_full_wrong_choice_certified','strict_gate_and_wrong_choice','gate_inactive','effective_regret_zero_certified']}
        # Two proofs of the same restored quantity: aggregate decomposition,
        # and the sharper cellwise signed lower integrand.
        wr={'nu':fw['nu'],'r':fw['r'],'selector_counts':{str(j):n for j,n in hist.items()},'classification_counts':histcounts,
            'weight_mean':(den/1024).dump(),'moments':{k:v.dump() for k,v in moments.items()},
            'display':{k:v.display() for k,v in moments.items()},'separate_three_term_lower':str(split.lo),
            'separate_four_term_lower':str(rawsplit.lo),
            'fixed_moment_mixture':mixture.dump(),
            'selection_covariance':selection_covariance.dump(),
            'by_index':{str(j):{k:(by[j].get(k,Ball(0))/den).dump() for k in ['mass','positive_gate_mass','selected_signed','negative_central_correction','selected_gated','policy_net','selection_regret']} for j in UPPER},
            'restored_positive':moments['restored'].lo>0,'rows':rows}
        result['windows'].append(wr)
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full',required=True);p.add_argument('--pilot',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();save(a.output,build(a.full,a.pilot))
