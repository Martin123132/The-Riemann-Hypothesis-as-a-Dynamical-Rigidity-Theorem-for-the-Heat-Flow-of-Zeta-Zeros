"""Named finite controls. They do not formally verify an asymptotic theorem."""
import unittest, importlib.util, gzip, json, hashlib, tempfile, itertools
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial
HERE=Path(__file__).resolve().parent

def module(name,file):
    spec=importlib.util.spec_from_file_location(name,HERE/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
B=module('main_ledger','RH_Central_Energy_Builder_2026-09-15_v1.py')
D=module('other_ledger','RH_Central_Energy_Independent_2026-09-15_v1.py')
INPUT=HERE/'RH_Central_Energy_Cell_Input_2026-09-15_v1.json.gz'
S50=HERE/'RH_Central_Energy_Short_50d_2026-09-15_v1.json.gz'
S80=HERE/'RH_Central_Energy_Short_80d_2026-09-15_v1.json.gz'

class TestSourceAwareJoint(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=B.load(INPUT);cls.r=B.build(INPUT,S50);cls.ind=D.build(INPUT,S50)
    def test_01_source_hash(self):self.assertEqual(hashlib.sha256(INPUT.read_bytes()).hexdigest(),B.INPUT_HASH)
    def test_02_source_geometry(self):self.assertIs(B.validate(self.a),self.a)
    def test_03_both_complete_windows(self):self.assertEqual([len(w['cells']) for w in self.r['windows']],[1024,1024])
    def test_04_new_upper_roster(self):self.assertEqual(B.load(S50)['upper_indices'],[2,3,4,5])
    def test_05_same_precision_mathematics(self):
        a,b=B.load(S50),B.load(S80);a.pop('precision');b.pop('precision');self.assertEqual(a,b)
    def test_06_all_upper_mixed_positive(self):self.assertTrue(all(w['all_upper_bilinears_positive'] for w in self.r['windows']))
    def test_07_full_surplus_positive(self):self.assertTrue(all(w['direct_surplus_positive'] for w in self.r['windows']))
    def test_08_restored_one_sided_positive(self):
        for w in self.r['windows']:self.assertGreater(F(w['means']['restored_one_sided'][0]),F(0))
    def test_09_restored_absolute_positive(self):
        for w in self.r['windows']:self.assertGreater(F(w['means']['restored_absolute'][0]),F(0))
    def test_10_weight_mass_positive(self):
        for w in self.r['windows']:self.assertGreater(F(w['weight_mean'][0]),F(0))
    def test_11_no_finite_asymptotic_constant(self):self.assertFalse(self.r['asymptotic_bounds_used_as_finite_constants'])
    def test_12_limit_not_finite_floor(self):
        self.assertLess(F(self.r['windows'][0]['signed_mixed'][5][1]),F('1.2837'))
    def test_13_independent_intervals_overlap(self):
        for w,v in zip(self.r['windows'],self.ind['windows']):
            for aa,bb in zip(w['signed_mixed'],v['mixed']):
                self.assertLessEqual(max(F(aa[0]),F(bb[0])),min(F(aa[1]),F(bb[1])))
            for key,other in [('net','net'),('restored_one_sided','restored'),('restored_absolute','absolute_restored')]:
                aa,bb=w['means'][key],v['means'][other]
                self.assertLessEqual(max(F(aa[0]),F(bb[0])),min(F(aa[1]),F(bb[1])))
    def test_14_independent_positive(self):self.assertTrue(all(w['restored_positive'] for w in self.ind['windows']))
    def test_15_rebuild_same(self):self.assertEqual(self.r,B.load(HERE/'RH_Central_Energy_Transport_50d_2026-09-15_v1.json.gz'))
    def test_16_source_error_payment(self):self.assertEqual(F(self.a['source_payment']),F('0.271900134725'))
    def test_17_exact_scale(self):self.assertEqual(B.scales(5),list(map(F,self.a['scales'])))
    def test_18_weight_not_changed(self):
        self.assertEqual([(w['nu'],w['r']) for w in self.a['windows']],[(0,['49/200','51/200']),(1,['149/200','151/200'])])
    def test_19_bridge_constant(self):self.assertLess(F(self.r['analytic_controls']['central_bridge_constant_upper']),1)
    def test_20_external_exponent_gap(self):self.assertEqual(F(2,3)-2*F(131,416),F(23,624))
    def test_21_spectral_threshold(self):
        s=F(1,6);self.assertEqual(s/2+4*s*s-2*s**3,F(5,27))
    def test_22_quarter_admissibility(self):
        s=F(1,5);self.assertEqual(s/2+4*s*s-2*s**3,F(61,250));self.assertLess(F(61,250),F(1,4))
    def test_23_sqrt_exponents(self):
        b=F(7,10);self.assertEqual(F(1,2)*(F(1,2)-b),-F(1,10));self.assertEqual(F(2,3)-b,-F(1,30))
    def test_24_polylog_exponent(self):self.assertEqual(1+6*(F(1,2)-F(7,10)),-F(1,5))
    def test_25_spectrum_monotonic_polynomial(self):
        for i in range(101):
            s=F(i,200);self.assertGreater(F(1,2)+8*s-6*s*s,0)
    def test_26_block_identity(self):
        for v in itertools.product(range(-2,3),repeat=4):
            ll,uu=min(v[:2]),min(v[2:]);self.assertEqual(min(v),uu-max(0,uu-ll))
    def test_27_one_sided_transport(self):
        for v in itertools.product(range(-1,2),repeat=4):
            for sv in itertools.product(range(-1,2),repeat=2):
                a=max(0,sv[0]-v[2],sv[1]-v[3]);self.assertGreaterEqual(min(v),min(v[:2]+sv)-a)
    def test_28_positive_mixed_not_minimum(self):
        states=[(1,[2,-2,10]),(1,[2,10,-2])]
        self.assertEqual(sum(x*v[1] for x,v in states)/2,4)
        self.assertEqual(sum(x*v[2] for x,v in states)/2,4)
        self.assertEqual(sum(max(0,x)*min(v) for x,v in states)/2,-2)
    def test_29_reversed_interval_rejected(self):
        with self.assertRaises(ValueError):B.I(2,1)
    def test_30_zero_divisor_rejected(self):
        with self.assertRaises(ValueError):B.I(1)/B.I(-1,1)
    def test_31_missing_cell_rejected(self):
        a=json.loads(json.dumps(self.a));a['windows'][0]['cells'].pop()
        with self.assertRaises(ValueError):B.validate(a)
    def test_32_duplicate_window_rejected(self):
        a=json.loads(json.dumps(self.a));a['windows'][1]['nu']=0
        with self.assertRaises(ValueError):B.validate(a)
    def test_33_error_changed_rejected(self):
        a=json.loads(json.dumps(self.a));a['source_payment']='0'
        with self.assertRaises(ValueError):B.validate(a)
    def test_34_overwrite_refusal(self):
        with tempfile.TemporaryDirectory() as dd:
            p=Path(dd)/'out.json';B.save(p,{'x':1})
            with self.assertRaises(FileExistsError):B.save(p,{'x':2})
    def test_35_source_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as dd:
            p=Path(dd)/'bad.gz';p.write_bytes(INPUT.read_bytes()+b' ')
            with self.assertRaises(ValueError):B.build(p)
    def test_36_kernel_positive_scales(self):
        for d in range(1,20):self.assertTrue(all(x>=1 for x in B.scales(d)))

if __name__=='__main__':unittest.main(verbosity=2)
