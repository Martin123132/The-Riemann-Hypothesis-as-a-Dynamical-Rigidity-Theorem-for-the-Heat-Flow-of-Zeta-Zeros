"""Source-aware central energy: exact finite joint ledgers and asymptotic controls.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
The infinite statements are proved in the accompanying derivation, not by tests.
"""
from __future__ import annotations
import argparse, gzip, hashlib, json
from fractions import Fraction as F
from pathlib import Path
from math import comb, factorial

INPUT_HASH='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
class I:
    __slots__=('lo','hi')
    def __init__(self, lo=0, hi=None):
        if isinstance(lo,I): self.lo,self.hi=lo.lo,lo.hi;return
        self.lo=F(lo);self.hi=F(lo if hi is None else hi)
        if self.lo>self.hi:raise ValueError('reversed interval')
    def __add__(self,b):
        b=I(b);return I(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,b):return self+-I(b)
    def __rsub__(self,b):return I(b)+-self
    def __mul__(self,b):
        b=I(b);p=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi];return I(min(p),max(p))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=I(b)
        if b.lo<=0<=b.hi:raise ValueError('division through zero')
        return self*I(1/b.hi,1/b.lo)
    def square(self):
        return I(0 if self.lo<=0<=self.hi else min(self.lo*self.lo,self.hi*self.hi), max(self.lo*self.lo,self.hi*self.hi))
    def pos(self):return I(max(0,self.lo),max(0,self.hi))
    def absolute(self):return I(0 if self.lo<=0<=self.hi else min(abs(self.lo),abs(self.hi)),max(abs(self.lo),abs(self.hi)))
    def dump(self):return [str(self.lo),str(self.hi)]
    def display(self):return [float(self.lo),float(self.hi)]

def imin(v):
    v=list(v)
    if not v:raise ValueError('empty minimum')
    return I(min(x.lo for x in v),min(x.hi for x in v))
def imax(v):
    v=list(v)
    if not v:raise ValueError('empty maximum')
    return I(max(x.lo for x in v),max(x.hi for x in v))
def load(path):
    b=Path(path).read_bytes();return json.loads(gzip.decompress(b) if str(path).endswith('.gz') else b)
def save(path,obj):
    p=Path(path)
    if p.exists():raise FileExistsError(p)
    raw=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
    p.write_bytes(gzip.compress(raw,mtime=0) if str(p).endswith('.gz') else raw)
def scales(d):
    return [sum((F(comb(j,k),comb(d,k))*F(d**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(d+1)]
def validate(a):
    if a['N']!=64 or a['degree']!=5:raise ValueError('unexpected source N or degree')
    if list(map(F,a['scales']))!=scales(5):raise ValueError('scales changed')
    if F(a['source_payment'])!=F('0.271900134725'):raise ValueError('source payment changed')
    if [w['nu'] for w in a['windows']]!=[0,1]:raise ValueError('window roster')
    for nu,w in enumerate(a['windows']):
        ends=[F(49+100*nu,200),F(51+100*nu,200)]
        if list(map(F,w['r']))!=ends or len(w['cells'])!=1024:raise ValueError('window geometry')
        for k,c in enumerate(w['cells']):
            if c['i']!=k or list(map(F,c['r']))!=[ends[0]+F(k,102400),ends[0]+F(k+1,102400)]:raise ValueError('cell gap or duplicate')
            if len(c['V'])!=6:raise ValueError('coefficient missing')
            for key in ['X','W']:
                I(*c[key])
            if I(*c['W']).lo<0 or I(*c['W']).hi>4:raise ValueError('weight outside analytic range')
            for row in c['V']:I(*row)
    return a

def analytic_controls():
    spec=lambda s:s/F(2)+4*s*s-2*s*s*s
    bridge=F(33,64)+F(251,2000)+F(1,3)+F(11,8192)
    gap=F(2,3)-2*F(131,416)
    return {'central_bridge_constant_upper':str(bridge),'central_bridge_constant_below_one':bridge<1,
      'mean_square_power_gap_N':str(gap),'gap_positive':gap>0,
      'weighted_central_energy_limsup_coefficient':'4/3',
      'window_energy_requires_unconditional_external_theorem':True,
      'spectral_threshold_lambda':str(spec(F(1,6))),
      'quarter_block_beta':'7/10','lambda_at_sigma_7_10':str(spec(F(1,5))),
      'quarter_block_strictly_admissible':spec(F(1,5))<F(1,4),
      'sqrt_cutoff_error_exponents':['-1/10','-1/30'],
      'log_power_cutoff':6,'polylog_max_error_exponent':'-1/5',
      'remaining_power_error_exponent':'-1/30',
      'theorem_scope':{'positive_joint_surplus_all_heights':False,'uniform_signed_bilinear_upper_block_limit':True,'RH_assumed':False,'effective_onset':False}}

def build(inputpath, shortpath=None):
    bb=Path(inputpath).read_bytes()
    if hashlib.sha256(bb).hexdigest()!=INPUT_HASH:raise ValueError('input hash mismatch')
    a=validate(load(inputpath)); short=load(shortpath) if shortpath else None
    if short:
        if short['input_sha256']!=INPUT_HASH or short['upper_indices']!=[2,3,4,5] or short['K']!=8:raise ValueError('shortened source contract')
        if len(short['windows'])!=2:raise ValueError('short window roster')
    out={'stage':'source-aware central energy and common-height signed upper spectrum','analytic_controls':analytic_controls(),
         'source_input_sha256':INPUT_HASH,'windows':[],'new_source_value_oracle_calls':0,'asymptotic_bounds_used_as_finite_constants':False}
    for nu,w in enumerate(a['windows']):
        totals={k:I(0) for k in ['mass','X2','gate_upper','lower_block_loss','net','positive_gate_mass','gate_correction_upper']}
        mixed=[I(0) for _ in range(6)];gated=[I(0) for _ in range(6)]
        logs=[]; failure_nodes=0
        if short:
            sw=short['windows'][nu]
            if sw['nu']!=nu or len(sw['cells'])!=1024:raise ValueError('short cell roster')
            for key in ['short_surplus','transport_absolute','transport_adverse','restored_absolute','restored_one_sided']:totals[key]=I(0)
        for idx,c in enumerate(w['cells']):
            X,W=I(*c['X']),I(*c['W']);V=[I(*v) for v in c['V']];P=X.pos();L=imin(V[:2]);U=imin(V[2:]);m=imin(V)
            vals={'mass':W,'X2':W*X.square(),'gate_upper':W*P*U,'lower_block_loss':W*P*(U-L).pos(),
                  'net':W*P*m,'positive_gate_mass':W*P,'gate_correction_upper':W*(-X).pos()*U}
            for j in range(6):mixed[j]=mixed[j]+W*X*V[j];gated[j]=gated[j]+W*P*V[j]
            record={'i':idx,'r':c['r'],'joint_net':vals['net'].dump()}
            # Verify the exact pointwise identities on the rational central model.
            xx=(X.lo+X.hi)/2;vv=[(v.lo+v.hi)/2 for v in V];pp=max(0,xx)
            ll=min(vv[:2]);uu=min(vv[2:]);mm=min(vv)
            if pp*mm!=pp*uu-pp*max(0,uu-ll):raise ArithmeticError('block identity')
            if short:
                sc=sw['cells'][idx]
                if sc['i']!=idx or list(map(F,sc['r']))!=list(map(F,c['r'])):raise ValueError('short grid mismatch')
                sv=[I(*v) for v in sc['Vshort']]
                if len(sv)!=4:raise ValueError('short coefficient missing')
                mh=imin(V[:2]+sv)
                differences=[sv[j]-V[j+2] for j in range(4)]
                ta=imax([x.absolute() for x in differences]);to=imax([I(0)]+[x.pos() for x in differences])
                vals.update(short_surplus=W*P*mh,transport_absolute=W*P*ta,transport_adverse=W*P*to,
                            restored_absolute=W*P*(mh-ta),restored_one_sided=W*P*(mh-to))
                record.update(short_min=mh.dump(),absolute_cost=(P*ta).dump(),adverse_cost=(P*to).dump(),restored=vals['restored_one_sided'].dump())
            for key,val in vals.items():totals[key]=totals[key]+val
            logs.append(record)
        mass=totals['mass']/1024
        if mass.lo<=0:raise ValueError('zero weight mass')
        means={k:(v/1024/mass) for k,v in totals.items() if k!='mass'}
        mc=[v/1024/mass for v in mixed];gc=[v/1024/mass for v in gated]
        bsep=means['gate_upper']-means['lower_block_loss']
        wr={'nu':nu,'r':w['r'],'cells':logs,'weight_mean':mass.dump(),'means':{k:v.dump() for k,v in means.items()},
            'means_display':{k:v.display() for k,v in means.items()},'signed_mixed':[v.dump() for v in mc],
            'signed_mixed_display':[v.display() for v in mc],'gated_mixed':[v.dump() for v in gc],
            'all_upper_bilinears_positive':all(v.lo>0 for v in mc[2:]),'separate_block_surplus':bsep.dump(),
            'direct_surplus_positive':means['net'].lo>0,
            'finite_shortened_passed':means.get('restored_one_sided',I(-1)).lo>0 if short else None}
        out['windows'].append(wr)
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--short');ap.add_argument('--output',required=True)
    ar=ap.parse_args();save(ar.output,build(ar.input,ar.short))
