"""Symbolic identities and direct-phase finite controls (not asymptotic verification)."""
import argparse, gzip, json
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial
import sympy as sp
from mpmath import iv

def symbolic():
    a,n=sp.symbols('a n',positive=True);s=sp.symbols('s',real=True)
    phi=2*sp.pi*a*a*sp.log(a/n)-sp.pi*a*a-sp.pi/8
    checks={
      'phase_first':sp.simplify(sp.diff(phi,a)-4*sp.pi*a*sp.log(a/n))==0,
      'phase_second':sp.simplify(sp.diff(phi,a,2)-4*sp.pi*(sp.log(a/n)+1))==0,
      'phase_third':sp.simplify(sp.diff(phi,a,3)-4*sp.pi/a)==0,
      'spectral_derivative':sp.diff(s/2+4*s*s-2*s**3,s)==sp.Rational(1,2)+8*s-6*s*s,
      'spectral_threshold':(s/2+4*s*s-2*s**3).subs(s,sp.Rational(1,6))==sp.Rational(5,27),
      'quarter_profile':(s/2+4*s*s-2*s**3).subs(s,sp.Rational(1,5))==sp.Rational(61,250),
      'external_gap':sp.Rational(2,3)-2*sp.Rational(131,416)==sp.Rational(23,624),
      'sqrt_cutoff_power':sp.Rational(1,2)*(sp.Rational(1,2)-sp.Rational(7,10))==-sp.Rational(1,10),
      'polylog_cutoff_power':1+6*(sp.Rational(1,2)-sp.Rational(7,10))==-sp.Rational(1,5)}
    z=sp.symbols('z',nonzero=True);ar,ai,br,bi=sp.symbols('ar ai br bi',real=True)
    A=ar+sp.I*ai;Ac=ar-sp.I*ai;B=br+sp.I*bi;Bc=br-sp.I*bi
    W=sp.Rational(3,2)+z+1/z+(z*z+z**-2)/4
    cc=sp.expand(W*(z*A+Ac/z)*(z*B+Bc/z)/4).coeff(z,0)
    target=sp.Rational(3,4)*(ar*br+ai*bi)+sp.Rational(1,8)*(ar*br-ai*bi)
    checks['mixed_constant_harmonic']=sp.simplify(cc-target)==0
    if not all(checks.values()):raise ArithmeticError(checks)
    return checks

def direct_checks(root):
    cells=json.loads(gzip.decompress((root/'RH_Central_Energy_Short_80d_2026-09-15_v1.json.gz').read_bytes()))
    iv.dps=70
    def ivq(x):
        x=F(x);return iv.mpf(x.numerator)/x.denominator
    def q(t):
        sg,m,e,_=t;return F(m*(1-2*sg))*(2**e if e>=0 else F(1,2**(-e)))
    ss=[sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    c=F(2491,3000)-F('0.271900134725');ans=[]
    for win in cells['windows']:
        eps=(-1)**win['nu']
        for idx in (0,511,1023):
            row=win['cells'][idx];mid=(F(row['r'][0])+F(row['r'][1]))/2;a=64+ivq(mid);t=2*iv.pi*a*a
            theta=t*iv.ln(t/(2*iv.pi))/2-t/2-iv.pi/8
            for j in range(2,6):
                total=iv.mpf(0)
                for nn in range(1,9):
                    zz=iv.ln(a/nn)+1j*iv.pi/4
                    poly=sum((ivq(F(comb(j,k),comb(5,k)*4**k*factorial(2*k)))*zz**(2*k) for k in range(j+1)),iv.mpc(0))
                    phase=theta-t*iv.ln(nn)
                    total+=(iv.sqrt(a/nn)*(iv.cos(phase)+1j*iv.sin(phase))*poly).real
                val=ivq(2*ss[5]/64)*(eps*total+ivq(c))/ivq(ss[j])
                lo,hi=map(q,val._mpi_);outer=list(map(F,row['Vshort'][j-2]));ok=outer[0]<=lo<=hi<=outer[1]
                if not ok:raise ArithmeticError((win['nu'],idx,j))
                ans.append({'nu':win['nu'],'cell':idx,'j':j,'whole_cell_contains_independent_direct_midpoint':True})
    return ans
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();dst=Path(a.output)
    if dst.exists():raise FileExistsError(dst)
    root=Path(__file__).resolve().parent;obj={'symbolic':symbolic(),'direct_phase_controls':direct_checks(root),
      'scope':'algebra and finite direct-phase controls; not proof-assistant or infinite verification'}
    dst.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
    print('10 symbolic identities and 24 independent-expression point controls passed')
