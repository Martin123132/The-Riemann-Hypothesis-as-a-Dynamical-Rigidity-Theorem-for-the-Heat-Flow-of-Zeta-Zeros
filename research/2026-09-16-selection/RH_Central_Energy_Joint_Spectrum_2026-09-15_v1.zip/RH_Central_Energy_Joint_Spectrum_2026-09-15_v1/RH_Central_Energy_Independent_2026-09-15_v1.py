"""Independent tuple/Fraction accumulation of the complete finite cell ledger.
No imports from the primary acceptance or source generator.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import argparse, gzip, json, hashlib
from pathlib import Path
from fractions import Fraction as Q
H='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
def inter(t):
    v=tuple(map(Q,t))
    if len(v)!=2 or v[0]>v[1]:raise ValueError('bad interval')
    return v
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    q=[x*y for x in a for y in b];return min(q),max(q)
def div(a,b):
    if not b[0]>0:raise ValueError('positive mass required')
    return mul(a,(1/b[1],1/b[0]))
def positive(a):return max(Q(0),a[0]),max(Q(0),a[1])
def absolute(a):
    return (Q(0) if a[0]<=0<=a[1] else min(abs(t) for t in a),max(abs(t) for t in a))
def sq(a):
    b=absolute(a);return b[0]*b[0],b[1]*b[1]
def minimum(xs):return min(x[0] for x in xs),min(x[1] for x in xs)
def maximum(xs):return max(x[0] for x in xs),max(x[1] for x in xs)
def dump(a):return list(map(str,a))
def read(p):
    b=Path(p).read_bytes();return json.loads(gzip.decompress(b) if str(p).endswith('.gz') else b)
def build(src,short):
    if hashlib.sha256(Path(src).read_bytes()).hexdigest()!=H:raise ValueError('source hash')
    a,b=read(src),read(short);output={'method':'independent rational tuple ledger','windows':[]}
    if b['K']!=8 or b['upper_indices']!=[2,3,4,5] or b['input_sha256']!=H:raise ValueError('truncation contract')
    if [w['nu'] for w in a['windows']]!=[0,1] or [w['nu'] for w in b['windows']]!=[0,1]:raise ValueError('window ids')
    for wi,(w,sw) in enumerate(zip(a['windows'],b['windows'])):
        if len(w['cells'])!=1024 or len(sw['cells'])!=1024:raise ValueError('cover size')
        accum={name:(Q(0),Q(0)) for name in ['mass','central_energy','net','short','adverse','restored','absolute_restored','upper','interface']}
        mixed=[(Q(0),Q(0)) for _ in range(6)]
        for k,(row,srow) in enumerate(zip(w['cells'],sw['cells'])):
            coords=[Q(49+wi*100,200)+Q(k,102400),Q(49+wi*100,200)+Q(k+1,102400)]
            if row['i']!=k or srow['i']!=k or list(map(Q,row['r']))!=coords or list(map(Q,srow['r']))!=coords:raise ValueError('gap in cover')
            x,weight=inter(row['X']),inter(row['W']);v=list(map(inter,row['V']));sv=list(map(inter,srow['Vshort']))
            if len(v)!=6 or len(sv)!=4:raise ValueError('missing coefficients')
            p=positive(x);pp=mul(p,weight);low,up=minimum(v[:2]),minimum(v[2:]);full=minimum(v);ms=minimum(v[:2]+sv)
            diffs=[sub(sv[j],v[j+2]) for j in range(4)];adv=maximum([positive(t) for t in diffs]);absolute_cost=maximum([absolute(t) for t in diffs])
            terms={'mass':weight,'central_energy':mul(weight,sq(x)),'net':mul(pp,full),'short':mul(pp,ms),
                   'adverse':mul(pp,adv),'restored':mul(pp,sub(ms,adv)),'absolute_restored':mul(pp,sub(ms,absolute_cost)),
                   'upper':mul(pp,up),'interface':mul(pp,positive(sub(up,low)))}
            for name,val in terms.items():accum[name]=add(accum[name],val)
            for j in range(6):mixed[j]=add(mixed[j],mul(mul(weight,x),v[j]))
        mass=accum.pop('mass');means={k:dump(div(v,mass)) for k,v in accum.items()}
        output['windows'].append({'nu':wi,'means':means,'mixed':[dump(div(v,mass)) for v in mixed],
                                 'restored_positive':Q(means['restored'][0])>0})
    return output
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--short',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    dest=Path(a.output)
    if dest.exists():raise FileExistsError(dest)
    dest.write_text(json.dumps(build(a.input,a.short),indent=2,sort_keys=True)+'\n')
