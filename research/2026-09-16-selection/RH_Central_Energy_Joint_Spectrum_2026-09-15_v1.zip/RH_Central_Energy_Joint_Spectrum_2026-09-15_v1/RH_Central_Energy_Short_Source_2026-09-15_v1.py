"""Direct interval enclosure of eight-term upper coefficient sums on full cells.
No zeta, Gamma, auxiliary-function, or zero-count evaluator is called.
Copyright (c) 2026 TWO HANDS NETWORK LTD. All rights reserved.
"""
import argparse, gzip, hashlib, json, time
from pathlib import Path
from fractions import Fraction as F
from math import comb,factorial
from mpmath import iv
HASH='f82e15db6b56b04debe6fd418bc8ff47c910721738bc08cea5062c8a76f86161'
GRID=10**28

def f_iv(x):
    x=F(x);return iv.mpf(x.numerator)/x.denominator

def asfraction(q):
    s,m,e,_=q;v=F(m*(1-2*s))
    return v*2**e if e>=0 else v/F(2**(-e))

def expout(x):
    lo,hi=map(asfraction,x._mpi_)
    fl=(lo*GRID).numerator//(lo*GRID).denominator
    ch=-((-hi*GRID).numerator//(-hi*GRID).denominator)
    return [str(F(fl,GRID)),str(F(ch,GRID))]

def run(inputpath,digits):
    raw=Path(inputpath).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=HASH:raise ValueError('input changed')
    a=json.loads(gzip.decompress(raw));assert a['N']==64 and a['degree']==5
    iv.dps=digits;pi=iv.pi;c=pi/4
    scales=[sum((F(comb(j,k),comb(5,k))*F(5**(2*k),4**k*factorial(2*k)) for k in range(j+1)),F()) for j in range(6)]
    assert [F(s) for s in a['scales']]==scales
    shift=F(2491,3000)-F(a['source_payment']);fac=f_iv(2*scales[5]/64)
    coeff={j:[f_iv(F(comb(j,k),comb(5,k)*4**k*factorial(2*k))/scales[j]) for k in range(j+1)] for j in range(2,6)}
    logs=[None]+[iv.ln(n) for n in range(1,9)]
    out={'N':64,'d':5,'K':8,'upper_indices':[2,3,4,5],'input_sha256':HASH,'precision':digits,'whole_cell_evaluation':True,'windows':[]}
    for nu,w in enumerate(a['windows']):
        rows=[];epsilon=1 if nu==0 else -1
        for cc in w['cells']:
            l,h=map(F,cc['r']);mid=(l+h)/2;ac=f_iv(64+mid);u=iv.mpf([f_iv(l-mid).a,f_iv(h-mid).b]);aa=ac+u
            loga=iv.ln(aa);acc={j:iv.mpf(0) for j in range(2,6)}
            for n in range(1,9):
                lc=iv.ln(ac)-logs[n]
                ph0=2*pi*ac**2*lc-pi*ac**2-pi/8
                ph1=4*pi*ac*lc
                ph2=2*pi*(lc+1)
                err=(2*pi/(3*f_iv(64+l)))*f_iv((h-l)/2)**3
                phase=ph0+ph1*u+ph2*u**2+iv.mpf([-err.b,err.b])
                term=iv.sqrt(aa/n)*(iv.cos(phase)+1j*iv.sin(phase))
                zz=(loga-logs[n])+1j*c;zz2=zz*zz
                for j in range(2,6):
                    poly=iv.mpc(0)
                    for co in reversed(coeff[j]):poly=poly*zz2+co
                    acc[j]+=epsilon*(term*poly).real
            v=[expout(fac*(acc[j]+f_iv(shift/scales[j]))) for j in range(2,6)]
            rows.append({'i':cc['i'],'r':cc['r'],'Vshort':v})
        out['windows'].append({'nu':nu,'cells':rows})
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--digits',type=int,required=True);p.add_argument('--output',required=True);a=p.parse_args()
    dest=Path(a.output)
    if dest.exists():raise FileExistsError(dest)
    obj=run(a.input,a.digits);dest.write_bytes(gzip.compress((json.dumps(obj,sort_keys=True,indent=2)+'\n').encode(),mtime=0))
    print('Complete: 2048 whole cells, 16384 eight-term phase evaluations, 8192 coefficient enclosures')
